from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).absolute().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).absolute().parent))

from controller_evidence_audit import audit, render_markdown, CONTROLLER, STUDENT, SDK
from safe_io import AuditInputError, decode_json, read_input, write_reports
from fixtures import fixture


class ExcerptTests(unittest.TestCase):
    def setUp(self):
        self.data = fixture()

    _UNSET = object()

    def bad(self, data=_UNSET):
        report = audit(self.data if data is self._UNSET else data)
        self.assertEqual(report["overall_status"], "invalid_or_out_of_scope_excerpt")
        self.assertEqual(report["exit_code"], 1)
        self.assertTrue(report["errors"])
        self.assertNotIn("checks", report)

    def test_synthetic_consistent_excerpt_is_explicitly_limited(self):
        report = audit(self.data)
        self.assertEqual(report["overall_status"], "limited_consistency_confirmed")
        self.assertEqual(report["exit_code"], 2)
        self.assertFalse(report["original_artifacts_reverified"])
        self.assertFalse(report["complete_experiment_verification"])
        self.assertFalse(report["general_success_rate_estimated"])

    def test_voice_absence_is_not_null_or_zero(self):
        voice = audit(self.data)["checks"]["per_case_excerpt_consistency"][2]["detail"]
        self.assertEqual(set(voice["top_level_field_presence"].values()), {"absent_in_excerpt"})
        self.assertNotIn("reported_policy_decisions", voice)

    def test_visible_link_count_is_one_not_reported_ten(self):
        detail = audit(self.data)["checks"]["per_case_excerpt_consistency"][0]["detail"]
        self.assertEqual(detail["visible_adjacent_nominal_links_checked"], 1)
        self.assertFalse(detail["all_reported_links_independently_recomputed"])

    def test_diagnostic_counterexample_not_eligible(self):
        row = audit(self.data)["checks"]["diagnostic_counterexample"]
        self.assertFalse(row["eligible_as_task_success"])
        self.assertIsNone(row["reported_task_success"])

    def test_actual_changed_files_not_sdk_adapter(self):
        report = audit(self.data)["checks"]
        statuses = {item["path"]: item["same_reported_digest_across_cases"] for item in report["code_fingerprints"]}
        self.assertFalse(statuses[CONTROLLER])
        self.assertFalse(statuses[STUDENT])
        self.assertTrue(statuses[SDK])
        self.assertFalse(report["single_final_code_revision_bundle"])

    def test_root_missing_or_unknown_fields(self):
        for key in fixture():
            data = fixture()
            del data[key]
            with self.subTest(key=key):
                self.bad(data)
        self.data["new_real_world_success"] = True
        self.bad()

    def test_malformed_root_types(self):
        for value in (None, [], 1, True, "bad"):
            with self.subTest(value=value):
                self.bad(value)

    def test_missing_case(self):
        self.data["latest_completed_cases"].pop()
        self.bad()

    def test_duplicated_case(self):
        self.data["latest_completed_cases"][1] = deepcopy(self.data["latest_completed_cases"][0])
        self.bad()

    def test_voice_top_level_fabricated_fields(self):
        for key, value in (("termination", None), ("seed", None), ("policy_decisions", 0), ("previous_target_links", {"checked": 0, "equal": 0})):
            data = fixture()
            data["latest_completed_cases"][2][key] = value
            with self.subTest(key=key):
                self.bad(data)

    def test_all_case_required_fields(self):
        for index, case in enumerate(fixture()["latest_completed_cases"]):
            for key in case:
                data = fixture()
                del data["latest_completed_cases"][index][key]
                with self.subTest(index=index, key=key):
                    self.bad(data)

    def test_type_bool_not_numeric_samples(self):
        self.data["latest_completed_cases"][0]["assessment"]["samples"] = True
        self.bad()

    def test_type_bool_not_numeric_angles(self):
        self.data["latest_completed_cases"][0]["first_two_decisions"][0]["requested_target_deg"][0] = True
        self.bad()

    def test_nonfinite_angle(self):
        for value in (float("nan"), float("inf"), float("-inf")):
            data = fixture()
            data["latest_completed_cases"][0]["first_two_decisions"][0]["requested_target_deg"][0] = value
            with self.subTest(value=value):
                self.bad(data)

    def test_missing_disclosure(self):
        self.data["scope"] = "All originals verified."
        self.bad()

    def test_missing_independent_initialization(self):
        self.data["extraction_notes"][5] = "one continuous run"
        self.bad()

    def test_policy_hash_mismatch(self):
        key = next(iter(self.data["latest_completed_cases"][0]["model_sha256"]))
        self.data["latest_completed_cases"][0]["model_sha256"][key] = "f" * 64
        self.bad()

    def test_bad_digest_shape(self):
        self.data["latest_completed_cases"][0]["sha256"] = "XYZ"
        self.bad()

    def test_false_hash_verification_flag(self):
        self.data["learned_policy_verification"]["fresh_model_byte_hash_matches"] = False
        self.bad()

    def test_model_loading_out_of_scope(self):
        self.data["learned_policy_verification"]["model_loaded_during_review"] = True
        self.bad()

    def test_diagnostic_promotion_is_rejected(self):
        self.data["earlier_diagnostic_counterexample"]["task_success"] = True
        self.bad()

    def test_diagnostic_flag_erasure_is_rejected(self):
        self.data["earlier_diagnostic_counterexample"]["assessment"]["diagnostic_only"] = False
        self.bad()

    def test_hardware_connected_out_of_scope(self):
        self.data["latest_completed_cases"][0]["sdk_hardware_connected"] = True
        self.bad()

    def test_physical_success_is_not_inferred(self):
        for value in (True, False, 0):
            data = fixture()
            data["latest_completed_cases"][1]["physical_success"] = value
            with self.subTest(value=value):
                self.bad(data)

    def test_voice_device_scope(self):
        self.data["latest_completed_cases"][2]["configuration"]["physical_device_or_microphone_used"] = True
        self.bad()

    def test_counterexample_not_reported_completed(self):
        self.data["earlier_diagnostic_counterexample"]["termination"] = "model_done"
        self.bad()

    def test_standard_model_done_required(self):
        self.data["latest_completed_cases"][0]["termination"] = "end_unconfirmed"
        self.bad()

    def test_nested_voice_completion_required(self):
        for field, value in (("end_confirmed", False), ("model_done", False), ("termination", "end_unconfirmed"), ("error", "error")):
            data = fixture()
            data["latest_completed_cases"][2]["transfer_results"][0][field] = value
            with self.subTest(field=field):
                self.bad(data)

    def test_empty_nested_transfer_not_silent(self):
        self.data["latest_completed_cases"][2]["transfer_results"] = []
        self.bad()

    def test_retarget_nested_status(self):
        self.data["latest_completed_cases"][2]["execution"]["retarget"]["status"] = "pending"
        self.bad()

    def test_source_return_status(self):
        self.data["latest_completed_cases"][2]["source_return_summary"]["status"] = "interrupted"
        self.bad()

    def test_nominal_link_corruption(self):
        self.data["latest_completed_cases"][0]["first_two_decisions"][1]["previous_student_target_deg"][0] += 1
        self.bad()

    def test_control_reference_link_corruption(self):
        self.data["latest_completed_cases"][0]["first_two_decisions"][1]["previous_control_reference_deg"][0] += 1
        self.bad()

    def test_nominal_target_not_applied_target(self):
        row = self.data["latest_completed_cases"][0]["first_two_decisions"][0]
        row["student_nominal_target_deg"] = row["applied_target_deg"][:]
        self.bad()

    def test_reported_counts_corruption(self):
        for field, value in (("equal", 9), ("checked", 11), ("equal", True)):
            data = fixture()
            data["latest_completed_cases"][0]["previous_target_links"][field] = value
            with self.subTest(field=field, value=value):
                self.bad(data)

    def test_examples_missing(self):
        self.data["latest_completed_cases"][0]["first_two_decisions"].pop()
        self.bad()

    def test_claim_single_code_revision_rejected(self):
        for key in (CONTROLLER, STUDENT):
            self.data["latest_completed_cases"][2]["code_sha256"][key] = self.data["latest_completed_cases"][0]["code_sha256"][key]
        self.bad()

    def test_sdk_adapter_difference_not_invented(self):
        self.data["latest_completed_cases"][2]["code_sha256"][SDK] = "f" * 64
        self.bad()

    def test_source_digest_disagreement(self):
        first = next(iter(self.data["source_text_checks"].values()))
        first["sha256"] = "f" * 64
        self.bad()

    def test_source_label_traversal(self):
        self.data["latest_completed_cases"][0]["source"] = "../stack_memory_sdk_v5.json"
        self.bad()

    def test_future_source_timestamp(self):
        self.data["latest_completed_cases"][0]["last_write_utc"] = "2099-01-01T00:00:00+00:00"
        self.bad()

    def test_naive_timestamp(self):
        self.data["cutoff_utc"] = "2026-11-11T14:11:33"
        self.bad()

    def test_markdown_has_no_aggregate_result_claim(self):
        result = render_markdown(audit(self.data))
        self.assertNotIn("3/3", result)
        self.assertNotIn("100%", result)
        self.assertIn("remaining links were not independently checked", result)
        self.assertIn("Native Windows support is not established", result)


class SafeIOTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=ROOT)
        self.root = Path(self.temp.name)
        self.input = self.root / "input.json"
        self.input.write_text('{"value": 1}', encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def test_read_does_not_change_input_bytes(self):
        before = hashlib.sha256(self.input.read_bytes()).hexdigest()
        self.assertEqual(decode_json(read_input(self.input)), {"value": 1})
        self.assertEqual(before, hashlib.sha256(self.input.read_bytes()).hexdigest())

    def test_symlink_input_rejected(self):
        link = self.root / "link.json"
        link.symlink_to(self.input)
        with self.assertRaises((AuditInputError, OSError)):
            read_input(link)

    def test_symlink_input_ancestor_rejected(self):
        link = self.root / "linkdir"
        link.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises((AuditInputError, OSError)):
            read_input(link / "input.json")

    def test_input_parent_traversal_rejected(self):
        with self.assertRaises(AuditInputError):
            read_input(str(self.root) + "/../anything.json")

    def test_npz_extension_rejected(self):
        with self.assertRaises(AuditInputError):
            read_input(self.root / "model.npz")

    def test_nonregular_file_rejected(self):
        fifo = self.root / "fifo.json"
        os.mkfifo(fifo)
        with self.assertRaises(AuditInputError):
            read_input(fifo)

    def test_input_size_limit(self):
        self.input.write_bytes(b" " * (5 * 1024 * 1024 + 1))
        with self.assertRaises(AuditInputError):
            read_input(self.input)

    def test_duplicate_keys_rejected(self):
        with self.assertRaises(AuditInputError):
            decode_json(b'{"task_success": false, "task_success": true}')

    def test_invalid_encoding_or_json(self):
        for value in (b"\xff", b"{"):
            with self.subTest(value=value), self.assertRaises(AuditInputError):
                decode_json(value)

    def test_nonstandard_json_numbers_rejected(self):
        for value in (b"NaN", b"Infinity", b"-Infinity"):
            with self.subTest(value=value), self.assertRaises(AuditInputError):
                decode_json(value)

    def test_float_overflow_rejected(self):
        with self.assertRaises(AuditInputError):
            decode_json(b'{"value": 1e999}')

    def test_huge_integer_parse_error_is_classified(self):
        # Python versions with an integer conversion limit must not crash the CLI.
        if hasattr(sys, "get_int_max_str_digits") and sys.get_int_max_str_digits():
            with self.assertRaises(AuditInputError):
                decode_json(b"1" * (sys.get_int_max_str_digits() + 1))

    def test_excessive_nesting_is_classified(self):
        with self.assertRaises(AuditInputError):
            decode_json(b"[" * 2000 + b"0" + b"]" * 2000)

    def test_fresh_reports_only_and_never_overwrite(self):
        output = write_reports(self.root, "run", {"limited": True}, "bounded")
        before = (output / "report.json").read_bytes()
        with self.assertRaises(AuditInputError):
            write_reports(self.root, "run", {"altered": True}, "changed")
        self.assertEqual((output / "report.json").read_bytes(), before)
        self.assertEqual((output / "report.md").read_text(), "bounded")

    def test_report_name_path_escape_rejected(self):
        for name in ("../escape", "/tmp/escape", "a/b", ".", "..", "", "a\\b"):
            with self.subTest(name=name), self.assertRaises(AuditInputError):
                write_reports(self.root, name, {}, "")

    def test_symlink_reports_directory_rejected(self):
        (self.root / "reports").symlink_to(self.root, target_is_directory=True)
        with self.assertRaises((AuditInputError, OSError)):
            write_reports(self.root, "run", {}, "")

    def test_symlink_root_ancestor_rejected(self):
        link = self.root / "linkdir"
        link.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises((AuditInputError, OSError)):
            write_reports(link, "run", {}, "")


if __name__ == "__main__":
    unittest.main()
