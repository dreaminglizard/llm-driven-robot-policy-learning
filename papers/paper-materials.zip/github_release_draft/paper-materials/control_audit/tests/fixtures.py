"""Synthetic, in-memory fixtures. These are not new robot/experiment results."""
from copy import deepcopy
from hashlib import sha256

from controller_evidence_audit import CASE_FILES, CONTROLLER, HARNESS, MEMORY, POLICY_PATH, RUNTIME, SDK, STUDENT, VOICE


def h(label):
    return sha256(label.encode()).hexdigest()


def fixture():
    policy = h("synthetic-policy")
    code = {key: h(key) for key in (RUNTIME, CONTROLLER, STUDENT, SDK, VOICE, HARNESS)}
    standard_configuration = {
        "controller_profile": "configs/app.hardware.json", "travel_z_mm": 130,
        "runtime_source_return": True, "mock_grasp_and_nominal_corrections": False,
        "arrival_correction_enabled": True,
        "experimental_pregrasp_nominal_lowering_mm": {"level1": 0, "level2": 0},
        "pregrasp_scope": "experimental runtime-command wrapper; not enabled in the product app",
        "controller_backend_label": "sdk-shaped configuration; virtual worker only",
        "simulated_worker": True, "speed_model_deg_per_sim_s": 12, "acceleration": 1,
        "checked_waypoint_compaction": True, "virtual_blended_path": False,
        "memory_sdk_host_encoder_with_virtual_delivery": True, "release_setdown_enabled": True,
        "noslip_iterations": 3, "gripper_report_delay_wall_s": 0.2,
        "gripper_report_is_not_grasp_evidence": True,
        "warning_and_collision": "assumed quiet; no sensor modeled",
        "virtual_stop_models": {
            "reset_servo_to_measured": "cancel simulated motion and reset servo targets to observed angles",
            "hold_servo_target": "cancel simulated motion while retaining the last simulated servo targets"},
        "matched_start": True,
        "matched_start_method": "virtual physics paused during setup until first student command",
        "real_sdk_stop_equivalence_verified": False,
        "active_motion_interruption_tested": False,
    }
    voice_configuration = {
        "acceleration": 1, "grasp_depth_mm": 0,
        "grasp_depth_is_experimental_wrapper_not_product": False,
        "profile_waypoint_compaction": False, "noslip_iterations": 3,
        "virtual_blended_worker_capability": False,
        "memory_sdk_host_encoder_with_virtual_delivery": True,
        "voice_harness_explicit_runtime_retarget": False,
        "demo_service_default_runtime_retarget": True, "quiet_diagnostics_assumed": True,
        "physical_device_or_microphone_used": False, "sdk_host_encoder_used_in_memory": True,
    }
    assessment = {"samples": 501, "diagnostic_only": False, "success": True, "checks_all_true": True, "failed_checks": []}
    cases = []
    for index, filename in enumerate(CASE_FILES):
        voice = index == 2
        case = {
            "source": "artifacts/synthetic/" + filename, "bytes": 1234,
            "sha256": h(filename), "last_write_utc": "2026-11-11T12:00:00+00:00",
            "input_files_unchanged": True, "model_sha256": {POLICY_PATH: policy},
            "code_sha256": {key: code[key] for key in (RUNTIME, CONTROLLER, STUDENT, SDK)},
            "case": "single_3_to_1" if index == 0 else "single_1_to_3",
            "initial_layout": [[1], [2], [3], [4]] if index == 0 else [[1, 3], [2], [], [4]],
            "initial_layout_source": "case_default" if index == 0 else "explicit_test_layout",
            "initial_state_sha256": h("stack-state" if index == 0 else "unstack-state"),
            "policy_initial_state_sha256": h("stack-policy-state" if index == 0 else "unstack-policy-state"),
            "task_success": True, "physical_success": None, "assessment": deepcopy(assessment),
            "sdk_hardware_connected": False,
            "npz": {"sha256": h("npz-" + filename), "bytes": 4321, "matches_reported_hash": True},
            "configuration": deepcopy(voice_configuration if voice else standard_configuration),
        }
        if not voice:
            decisions = []
            for n in range(2):
                nominal = [1.0 + n, 2.0 + n, 3.0 + n, 4.0 + n]
                applied = [v + 0.1 for v in nominal]
                decisions.append({
                    "index": n, "action": "move", "result": "command_applied", "transmitted": True,
                    "proposed_target_deg": [v - 0.01 for v in nominal],
                    "requested_target_deg": [v - 0.01 for v in nominal],
                    "quantized_target_deg": nominal[:], "applied_target_deg": applied[:],
                    "previous_student_target_deg": [0.0] * 4 if n == 0 else decisions[0]["student_nominal_target_deg"][:],
                    "student_policy_target_deg": nominal[:], "student_nominal_target_deg": nominal[:],
                    "nominal_arrival_confirmed": True,
                    "previous_control_reference_deg": [0.0] * 4 if n == 0 else decisions[0]["applied_target_deg"][:],
                    "previous_control_reference_source": "stationary_observation" if n == 0 else "controller_confirmed_move",
                    "control_reference_deg": applied[:], "control_reference_source": "controller_confirmed_move",
                    "source_return_lift": None, "interrupted_effective_target_deg": None,
                })
            case.update({"seed": 620028, "virtual_stop_model": "hold_servo_target", "termination": "model_done", "policy_decisions": 11, "previous_target_links": {"checked": 10, "equal": 10}, "first_two_decisions": decisions})
        else:
            case["model_sha256"][MEMORY] = h("synthetic-memory")
            case["code_sha256"].update({VOICE: code[VOICE], HARNESS: code[HARNESS], CONTROLLER: h("voice-controller"), STUDENT: h("voice-student")})
            case.update({
                "execution": {"status": "retargeted_expected", "retarget": {"status": "completed_expected", "applied": True, "source_slot": 1, "destination_slot": 1, "activation_decision_index": 4, "physical_success": None}},
                "retarget_received_during_closed_move": True,
                "transfer_results": [{"termination": "model_done", "model_done": True, "end_confirmed": True, "error": None, "end_error": None, "previous_termination": None}],
                "symbolic_plan": {"event": "symbolic_plan", "steps": 1, "planner": "scoped_breadth_first_search_not_learned", "goal_source": "explicit_task", "planned_goal": [[1], [2], [3], [4]], "active_slots": [1, 3]},
                "source_return_summary": {"status": "model_done", "source_slot": 1, "activation_decision_index": 4, "lift_status": "applied", "return_move_confirmed": True, "open_after_switch": True},
            })
        cases.append(case)
    diagnostic = deepcopy(assessment)
    diagnostic["diagnostic_only"] = True
    return {
        "schema": "manipulation-controller-development-evidence.v1", "source_id": "P11",
        "cutoff_utc": "2026-11-11T14:11:33+00:00",
        "scope": "Full original JSON, NPZ and model files are not included. No simulation, model loading, device or microphone operation was performed for this review.",
        "extraction_notes": [
            "Original digests identify the source, not this derived extract.",
            "Assessment details are read-time summaries.",
            "Missing top-level fields are not observed null or zero.",
            "physical_success means no real-world verdict.",
            "Artifacts were never deserialized.",
            "Cases were initialized separately; shared seed does not establish a shared continuous world.",
            "No success rate is estimated."],
        "learned_policy_verification": {"selected_policy_sha256": policy, "stored_before_after_hash_matches": True, "fresh_model_byte_hash_matches": True, "model_loaded_during_review": False},
        "latest_completed_cases": cases,
        "earlier_diagnostic_counterexample": {"source": "artifacts/synthetic/unstack_memory_sdk_v3.json", "bytes": 1000, "sha256": h("counterexample"), "last_write_utc": "2026-11-11T11:00:00+00:00", "termination": "end_unconfirmed", "task_success": None, "physical_success": None, "assessment": diagnostic, "sdk_hardware_connected": False},
        "source_text_checks": {
            RUNTIME: {"sha256": code[RUNTIME], "lines": "synthetic 1", "finding": "A new CustomSlotsSceneMotionSim is constructed per run."},
            VOICE: {"sha256": code[VOICE], "lines": "synthetic 2", "finding": "Synthetic audio fixtures only."},
            HARNESS: {"sha256": code[HARNESS], "lines": "synthetic 3", "finding": "There is no real microphone or ASR tested."},
        },
    }
