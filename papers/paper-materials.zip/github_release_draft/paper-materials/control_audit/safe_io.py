"""Local read-only input / exclusive confined output helpers (POSIX tested only).

No traversal of symlinks, no overwrite, no network, no imported project code.
Each filesystem walk uses directory descriptors, not a check-then-open path.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
import re
import stat


MAX_INPUT_BYTES = 5 * 1024 * 1024


class AuditInputError(ValueError):
    """Invalid or unsupported input, not an audit success."""


def require_secure_io() -> None:
    if os.name != "posix" or not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY"):
        raise AuditInputError("Secure descriptor-based I/O is available only on supported POSIX systems. Native Windows support is not claimed.")
    if os.open not in os.supports_dir_fd or os.mkdir not in os.supports_dir_fd:
        raise AuditInputError("This platform lacks required directory-descriptor support.")


def _parts(path: str | Path) -> tuple[str, ...]:
    raw = os.fspath(path)
    if not raw or "\x00" in raw:
        raise AuditInputError("Empty or NUL-containing path is forbidden.")
    # Reject lexical traversal before pathlib would normalize it away.
    if ".." in raw.split("/"):
        raise AuditInputError("Parent traversal is forbidden.")
    absolute = Path(os.path.abspath(raw))
    return absolute.parts[1:]


def open_directory(path: str | Path) -> int:
    require_secure_io()
    parts = _parts(path)
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in parts:
            next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = next_fd
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_input(path: str | Path) -> bytes:
    parts = _parts(path)
    if not parts or Path(parts[-1]).suffix.lower() != ".json":
        raise AuditInputError("Only a JSON excerpt input is accepted; no NPZ or model loading is implemented.")
    parent = Path("/", *parts[:-1])
    directory_fd = open_directory(parent)
    try:
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory_fd)
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode):
                raise AuditInputError("Input must be a regular, non-symlink file.")
            if info.st_size > MAX_INPUT_BYTES:
                raise AuditInputError("Input exceeds the bounded JSON size limit.")
            with os.fdopen(fd, "rb", closefd=False) as stream:
                raw = stream.read(MAX_INPUT_BYTES + 1)
            if len(raw) > MAX_INPUT_BYTES:
                raise AuditInputError("Input grew beyond the bounded JSON size limit.")
            return raw
        finally:
            os.close(fd)
    except OSError as exc:
        raise AuditInputError(f"Input cannot be read safely: {exc.strerror}.") from exc
    finally:
        os.close(directory_fd)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise AuditInputError(f"Duplicate JSON key: {key!r}.")
        result[key] = value
    return result


def decode_json(raw: bytes):
    def reject_constant(value):
        raise AuditInputError(f"Non-finite JSON constant is forbidden: {value}.")
    def finite_float(value):
        result = float(value)
        if not math.isfinite(result):
            raise AuditInputError("JSON number overflowed the finite numeric range.")
        return result
    try:
        result = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object, parse_constant=reject_constant, parse_float=finite_float)
        pending = [(result, 0)]
        while pending:
            value, depth = pending.pop()
            if depth > 32:
                raise AuditInputError("JSON exceeds the supported nesting depth of 32.")
            if isinstance(value, dict):
                pending.extend((child, depth + 1) for child in value.values())
            elif isinstance(value, list):
                pending.extend((child, depth + 1) for child in value)
        return result
    except AuditInputError:
        raise
    except (UnicodeDecodeError, ValueError, RecursionError) as exc:
        raise AuditInputError(f"Malformed UTF-8 JSON: {exc}.") from exc


def write_reports(root: Path, run_name: str, report: dict, markdown: str) -> Path:
    """Write two new reports under root/reports/run_name using anchored fds.

    The CLI sets root to its own directory. No caller-provided output path exists.
    A run directory collision is an error, never a request to overwrite.
    """
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,95}", run_name):
        raise AuditInputError("Report name must be a simple 1–96 character identifier, without path separators.")
    json_bytes = (json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    md_bytes = markdown.encode("utf-8")
    root_fd = open_directory(root)
    reports_fd = None
    run_fd = None
    try:
        try:
            os.mkdir("reports", 0o700, dir_fd=root_fd)
        except FileExistsError:
            pass
        reports_fd = os.open("reports", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root_fd)
        os.mkdir(run_name, 0o700, dir_fd=reports_fd)
        run_fd = os.open(run_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=reports_fd)
        for filename, data in (("report.json", json_bytes), ("report.md", md_bytes)):
            fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=run_fd)
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
        return root / "reports" / run_name
    except OSError as exc:
        raise AuditInputError(f"Exclusive confined report creation failed: {exc.strerror}. Existing files were not overwritten; partial new output may remain.") from exc
    finally:
        for fd in (run_fd, reports_fd, root_fd):
            if fd is not None:
                os.close(fd)
