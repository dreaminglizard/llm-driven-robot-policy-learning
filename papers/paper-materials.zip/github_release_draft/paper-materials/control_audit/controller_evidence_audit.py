#!/usr/bin/env python3
"""Audit only a supplied derived controller-evidence excerpt, using stdlib.

Never imports the official project, opens referenced artifacts, deserializes a
model/NPZ, runs a simulator, contacts a network, or accesses devices.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import math
from pathlib import Path, PurePosixPath
import sys
import uuid

from safe_io import AuditInputError, decode_json, read_input, write_reports

SCHEMA = "manipulation-controller-development-evidence.v1"
POLICY_PATH = "artifacts/architecture_research/astra_close_reproduction_three_seeds_20261106_v1/seed_20261030/candidate.pt"
RUNTIME = "scripts/research_runtime_controller_mujoco.py"
CONTROLLER = "raccoon_control/controller.py"
STUDENT = "raccoon_memory/native_physical_student.py"
SDK = "raccoon_control/sdk_adapter.py"
VOICE = "scripts/experiment_voice_runtime_mujoco.py"
HARNESS = "tests/voice_runtime_harness.py"
MEMORY = "artifacts/architecture_research/astra_terra_weight_repair_v1/gru128_decoder_margin_repair_v1/model.pt"
CASE_FILES = ("stack_memory_sdk_v5.json", "unstack_memory_sdk_v5.json", "voice_return_memory_sdk_v3.json")
COMMON = set("source bytes sha256 last_write_utc input_files_unchanged model_sha256 code_sha256 case initial_layout initial_layout_source initial_state_sha256 policy_initial_state_sha256 task_success physical_success assessment sdk_hardware_connected npz configuration".split())
STANDARD = set("seed virtual_stop_model termination policy_decisions previous_target_links first_two_decisions".split())
VOICE_FIELDS = set("execution retarget_received_during_closed_move transfer_results symbolic_plan source_return_summary".split())
VECTORS = tuple("proposed_target_deg requested_target_deg quantized_target_deg applied_target_deg previous_student_target_deg student_policy_target_deg student_nominal_target_deg previous_control_reference_deg control_reference_deg".split())
LIMITATIONS = [
    "Only the derived excerpt's schema, field relationships and reported fingerprints are checked. Full original JSON, NPZ, model and source-script bytes are not bundled or re-read.",
    "Reported original-file SHA-256 values and before/after or fresh-hash-match flags are declarations in the excerpt, not hashes recomputed by this audit. Only the supplied excerpt bytes are hashed here.",
    "The first two displayed decisions provide one visible adjacent nominal-target link per non-voice case. Reported checked=10 and equal=10 are checked only for arithmetic consistency with 11 policy decisions; the other links are unavailable.",
    "Voice completion is checked only at its nested execution, transfer_results and source_return_summary fields. Absent top-level termination, seed and decision/link fields remain absent, not observed null or zero.",
    "Separate initialization is a reported extraction/source-summary claim. Equal seeds or initial-state hashes do not demonstrate a continuous world or a sequential physical run.",
    "Diagnostic sample outcomes are not task outcomes. physical_success=null means no real-world verdict, not measured hardware failure. Hardware is reported disconnected.",
    "The selected configuration labels gripper reports as non-evidence of grasp, assumes quiet diagnostics without modeled sensors, and reports real/virtual SDK stop equivalence and active-motion interruption as unverified. SDK-shaped virtual delivery is not physical SDK behavior validation.",
    "No new experiment, training, simulation, model loading, official-project import, motor/microphone operation, network request or publication is performed. No aggregate/general success rate, causal improvement, held-out result or continuous real-world result is estimated.",
    "Descriptor-based filesystem safeguards were exercised on Linux/POSIX. Native Windows support is not established and is deliberately not claimed.",
]


class EvidenceError(ValueError):
    pass


def need(condition, where, message):
    if not condition:
        raise EvidenceError(f"{where}: {message}")


def shape(value, keys, where):
    need(type(value) is dict, where, "expected an object")
    need(set(value) == set(keys), where, f"missing keys={sorted(set(keys)-set(value))}; unsupported keys={sorted(set(value)-set(keys))}")


def fixed(value, expected, where):
    need(type(value) is type(expected) and value == expected, where, f"expected {expected!r}; received {value!r}")


def integer(value, where, minimum=0):
    need(type(value) is int and value >= minimum, where, f"expected integer >= {minimum}, not a boolean")


def number(value, where, minimum=None):
    need(type(value) in (int, float) and math.isfinite(value), where, "expected a finite numeric value")
    if minimum is not None:
        need(value >= minimum, where, f"expected value >= {minimum}")


def text(value, where):
    need(type(value) is str and bool(value.strip()), where, "expected a nonempty string")


def digest(value, where):
    need(type(value) is str and len(value) == 64 and all(c in "0123456789abcdef" for c in value), where, "expected a lowercase SHA-256 hex digest")


def timestamp(value, where):
    text(value, where)
    try:
        result = datetime.fromisoformat(value)
    except ValueError as exc:
        raise EvidenceError(f"{where}: invalid ISO timestamp") from exc
    need(result.tzinfo is not None and result.utcoffset().total_seconds() == 0, where, "expected an explicit UTC offset")
    return result


def source_path(value, where):
    text(value, where)
    p = PurePosixPath(value)
    need(not p.is_absolute() and ".." not in p.parts and "\\" not in value and ":" not in value and "\x00" not in value, where, "expected a relative source label, not a traversable or external path")
    return p.name


def assessment(value, where, diagnostic):
    shape(value, "samples diagnostic_only success checks_all_true failed_checks".split(), where)
    fixed(value["samples"], 501, where + ".samples")
    fixed(value["diagnostic_only"], diagnostic, where + ".diagnostic_only")
    for field in ("success", "checks_all_true"):
        fixed(value[field], True, where + "." + field)
    fixed(value["failed_checks"], [], where + ".failed_checks")


def layout(value, expected, where):
    fixed(value, expected, where)
    for slot in value:
        need(type(slot) is list and all(type(block) is int for block in slot), where, "layout identifiers must be integers, not booleans")


def validate_configuration(cfg, where, voice):
    if voice:
        expected = {
            "acceleration": 1, "grasp_depth_mm": 0,
            "grasp_depth_is_experimental_wrapper_not_product": False,
            "profile_waypoint_compaction": False, "noslip_iterations": 3,
            "virtual_blended_worker_capability": False,
            "memory_sdk_host_encoder_with_virtual_delivery": True,
            "voice_harness_explicit_runtime_retarget": False,
            "demo_service_default_runtime_retarget": True,
            "quiet_diagnostics_assumed": True,
            "physical_device_or_microphone_used": False,
            "sdk_host_encoder_used_in_memory": True,
        }
        shape(cfg, expected, where)
        for key, value in expected.items():
            fixed(cfg[key], value, where + "." + key)
        return
    expected = {
        "controller_profile": "configs/app.hardware.json", "travel_z_mm": 130,
        "runtime_source_return": True, "mock_grasp_and_nominal_corrections": False,
        "arrival_correction_enabled": True,
        "pregrasp_scope": "experimental runtime-command wrapper; not enabled in the product app",
        "controller_backend_label": "sdk-shaped configuration; virtual worker only",
        "simulated_worker": True, "speed_model_deg_per_sim_s": 12,
        "acceleration": 1, "checked_waypoint_compaction": True,
        "virtual_blended_path": False, "memory_sdk_host_encoder_with_virtual_delivery": True,
        "release_setdown_enabled": True, "noslip_iterations": 3,
        "gripper_report_delay_wall_s": 0.2, "gripper_report_is_not_grasp_evidence": True,
        "warning_and_collision": "assumed quiet; no sensor modeled",
        "matched_start": True,
        "matched_start_method": "virtual physics paused during setup until first student command",
        "real_sdk_stop_equivalence_verified": False, "active_motion_interruption_tested": False,
    }
    shape(cfg, set(expected) | {"experimental_pregrasp_nominal_lowering_mm", "virtual_stop_models"}, where)
    for key, value in expected.items():
        fixed(cfg[key], value, where + "." + key)
    lowering = cfg["experimental_pregrasp_nominal_lowering_mm"]
    shape(lowering, ("level1", "level2"), where + ".lowering")
    for key in lowering:
        fixed(lowering[key], 0, where + ".lowering." + key)
    stops = cfg["virtual_stop_models"]
    shape(stops, ("reset_servo_to_measured", "hold_servo_target"), where + ".virtual_stop_models")
    fixed(stops["reset_servo_to_measured"], "cancel simulated motion and reset servo targets to observed angles", where + ".reset_servo_to_measured")
    fixed(stops["hold_servo_target"], "cancel simulated motion while retaining the last simulated servo targets", where + ".hold_servo_target")


def validate_decisions(case, where):
    integer(case["seed"], where + ".seed")
    fixed(case["termination"], "model_done", where + ".termination")
    fixed(case["virtual_stop_model"], "hold_servo_target", where + ".virtual_stop_model")
    fixed(case["policy_decisions"], 11, where + ".policy_decisions")
    links = case["previous_target_links"]
    shape(links, ("checked", "equal"), where + ".previous_target_links")
    for key in links:
        fixed(links[key], 10, where + ".previous_target_links." + key)
    need(links["equal"] <= links["checked"] == case["policy_decisions"] - 1, where, "reported link counts contradict the policy-decision count")
    decisions = case["first_two_decisions"]
    need(type(decisions) is list and len(decisions) == 2, where, "exactly the first two decision examples must be supplied")
    for index, row in enumerate(decisions):
        loc = f"{where}.first_two_decisions[{index}]"
        shape(row, set(VECTORS) | set("index action result transmitted nominal_arrival_confirmed previous_control_reference_source control_reference_source source_return_lift interrupted_effective_target_deg".split()), loc)
        for key, expected in {"index": index, "action": "move", "result": "command_applied", "transmitted": True, "nominal_arrival_confirmed": True, "source_return_lift": None, "interrupted_effective_target_deg": None, "control_reference_source": "controller_confirmed_move", "previous_control_reference_source": "stationary_observation" if index == 0 else "controller_confirmed_move"}.items():
            fixed(row[key], expected, loc + "." + key)
        for key in VECTORS:
            vector = row[key]
            need(type(vector) is list and len(vector) == 4, loc + "." + key, "expected four joint-angle values")
            for angle in vector:
                number(angle, loc + "." + key)
        need(row["proposed_target_deg"] == row["requested_target_deg"], loc, "proposed/requested targets differ")
        need(row["quantized_target_deg"] == row["student_policy_target_deg"] == row["student_nominal_target_deg"], loc, "SDK quantized and student nominal/policy targets differ")
        need(row["control_reference_deg"] == row["applied_target_deg"], loc, "control reference differs from the applied target")
        need(row["student_nominal_target_deg"] != row["applied_target_deg"], loc, "nominal and applied target separation is absent in the selected example")
        if index == 0:
            need(row["previous_student_target_deg"] == row["previous_control_reference_deg"], loc, "initial stationary references differ")
        else:
            previous = decisions[index - 1]
            need(row["previous_student_target_deg"] == previous["student_nominal_target_deg"], loc, "visible adjacent student link does not retain the prior nominal target")
            need(row["previous_control_reference_deg"] == previous["applied_target_deg"], loc, "visible control-reference link does not retain prior applied target")
    return {
        "reported_policy_decisions": case["policy_decisions"],
        "reported_previous_target_links": dict(links),
        "displayed_decision_examples_checked": len(decisions),
        "visible_adjacent_nominal_links_checked": 1,
        "all_reported_links_independently_recomputed": False,
        "result": "Displayed examples and reported count arithmetic are internally consistent; unshown links are not verified.",
    }


def validate_voice(case, where):
    # The enclosing exact-key schema prohibits manufacturing top-level values.
    execution = case["execution"]
    shape(execution, ("status", "retarget"), where + ".execution")
    fixed(execution["status"], "retargeted_expected", where + ".execution.status")
    retarget = execution["retarget"]
    expected = {"status": "completed_expected", "applied": True, "source_slot": 1, "destination_slot": 1, "activation_decision_index": 4, "physical_success": None}
    shape(retarget, expected, where + ".execution.retarget")
    for key, value in expected.items():
        fixed(retarget[key], value, where + ".execution.retarget." + key)
    fixed(case["retarget_received_during_closed_move"], True, where + ".retarget_received_during_closed_move")
    transfers = case["transfer_results"]
    need(type(transfers) is list and len(transfers) == 1, where + ".transfer_results", "expected the one supplied nested transfer")
    expected = {"termination": "model_done", "model_done": True, "end_confirmed": True, "error": None, "end_error": None, "previous_termination": None}
    shape(transfers[0], expected, where + ".transfer_results[0]")
    for key, value in expected.items():
        fixed(transfers[0][key], value, where + ".transfer_results[0]." + key)
    plan = case["symbolic_plan"]
    expected = {"event": "symbolic_plan", "steps": 1, "planner": "scoped_breadth_first_search_not_learned", "goal_source": "explicit_task", "planned_goal": [[1], [2], [3], [4]], "active_slots": [1, 3]}
    shape(plan, expected, where + ".symbolic_plan")
    for key, value in expected.items():
        fixed(plan[key], value, where + ".symbolic_plan." + key)
    layout(plan["planned_goal"], [[1], [2], [3], [4]], where + ".planned_goal")
    need(all(type(n) is int for n in plan["active_slots"]), where, "active-slot values must be integers")
    summary = case["source_return_summary"]
    expected = {"status": "model_done", "source_slot": 1, "activation_decision_index": 4, "lift_status": "applied", "return_move_confirmed": True, "open_after_switch": True}
    shape(summary, expected, where + ".source_return_summary")
    for key, value in expected.items():
        fixed(summary[key], value, where + ".source_return_summary." + key)
    need(retarget["source_slot"] == summary["source_slot"] and retarget["activation_decision_index"] == summary["activation_decision_index"], where, "nested retarget/source-return summaries disagree")
    return {"completion_location": "execution.retarget, transfer_results[0], source_return_summary", "nested_completion_consistent": True, "top_level_field_presence": {key: "absent_in_excerpt" for key in ("termination", "seed", "policy_decisions", "previous_target_links", "first_two_decisions")}, "voice_device_or_microphone_evidence": "not used, as reported", "planner": plan["planner"]}


def validate(data):
    """Strict closed-world contract for this v1 extract, not a general experiment reader."""
    shape(data, "schema source_id cutoff_utc scope extraction_notes learned_policy_verification latest_completed_cases earlier_diagnostic_counterexample source_text_checks".split(), "root")
    fixed(data["schema"], SCHEMA, "schema")
    fixed(data["source_id"], "P11", "source_id")
    cutoff = timestamp(data["cutoff_utc"], "cutoff_utc")
    text(data["scope"], "scope")
    need("Full original JSON, NPZ and model files are not included." in data["scope"], "scope", "must disclose omitted original artifacts")
    need("No simulation, model loading, device or microphone operation was performed" in data["scope"], "scope", "must disclose non-execution scope")
    notes = data["extraction_notes"]
    need(type(notes) is list and len(notes) >= 7, "extraction_notes", "required interpretation notes are missing")
    for note in notes:
        text(note, "extraction_notes[]")
    for phrase in ("not this derived extract", "read-time summaries", "Missing top-level", "observed null or zero", "no real-world verdict", "never deserialized", "initialized separately", "does not establish a shared continuous world", "No success rate"):
        need(any(phrase in note for note in notes), "extraction_notes", f"missing required limitation: {phrase}")
    policy = data["learned_policy_verification"]
    shape(policy, "selected_policy_sha256 stored_before_after_hash_matches fresh_model_byte_hash_matches model_loaded_during_review".split(), "learned_policy_verification")
    digest(policy["selected_policy_sha256"], "selected_policy_sha256")
    fixed(policy["stored_before_after_hash_matches"], True, "stored_before_after_hash_matches")
    fixed(policy["fresh_model_byte_hash_matches"], True, "fresh_model_byte_hash_matches")
    fixed(policy["model_loaded_during_review"], False, "model_loaded_during_review")
    cases = data["latest_completed_cases"]
    need(type(cases) is list and len(cases) == len(CASE_FILES), "latest_completed_cases", "selected case set is incomplete or expanded beyond this audit contract")
    per_case = []
    for index, case in enumerate(cases):
        where = f"latest_completed_cases[{index}]"
        is_voice = index == 2
        shape(case, COMMON | (VOICE_FIELDS if is_voice else STANDARD), where)
        fixed(source_path(case["source"], where + ".source"), CASE_FILES[index], where + ".source basename")
        integer(case["bytes"], where + ".bytes", 1)
        digest(case["sha256"], where + ".sha256")
        need(timestamp(case["last_write_utc"], where + ".last_write_utc") <= cutoff, where, "source timestamp is after the extract cutoff")
        fixed(case["input_files_unchanged"], True, where + ".input_files_unchanged")
        shape(case["model_sha256"], (POLICY_PATH, MEMORY) if is_voice else (POLICY_PATH,), where + ".model_sha256")
        for path, value in case["model_sha256"].items():
            digest(value, where + ".model_sha256." + path)
        fixed(case["model_sha256"][POLICY_PATH], policy["selected_policy_sha256"], where + ".policy digest agreement")
        shape(case["code_sha256"], (RUNTIME, CONTROLLER, STUDENT, SDK, VOICE, HARNESS) if is_voice else (RUNTIME, CONTROLLER, STUDENT, SDK), where + ".code_sha256")
        for path, value in case["code_sha256"].items():
            digest(value, where + ".code_sha256." + path)
        fixed(case["case"], "single_3_to_1" if index == 0 else "single_1_to_3", where + ".case")
        layout(case["initial_layout"], [[1], [2], [3], [4]] if index == 0 else [[1, 3], [2], [], [4]], where + ".initial_layout")
        fixed(case["initial_layout_source"], "case_default" if index == 0 else "explicit_test_layout", where + ".initial_layout_source")
        for key in ("initial_state_sha256", "policy_initial_state_sha256"):
            digest(case[key], where + "." + key)
        fixed(case["task_success"], True, where + ".task_success")
        fixed(case["physical_success"], None, where + ".physical_success")
        fixed(case["sdk_hardware_connected"], False, where + ".sdk_hardware_connected")
        assessment(case["assessment"], where + ".assessment", False)
        npz = case["npz"]
        shape(npz, ("sha256", "bytes", "matches_reported_hash"), where + ".npz")
        digest(npz["sha256"], where + ".npz.sha256")
        integer(npz["bytes"], where + ".npz.bytes", 1)
        fixed(npz["matches_reported_hash"], True, where + ".npz.matches_reported_hash")
        validate_configuration(case["configuration"], where + ".configuration", is_voice)
        detail = validate_voice(case, where) if is_voice else validate_decisions(case, where)
        per_case.append({"source": case["source"], "reported_task_success": case["task_success"], "diagnostic_only": case["assessment"]["diagnostic_only"], "reported_physical_success": case["physical_success"], "physical_success_interpretation": "no_real_world_verdict", "reported_sdk_hardware_connected": case["sdk_hardware_connected"], "source_fingerprint_recomputed": False, "detail": detail})
    code_comparison = []
    for path in (RUNTIME, CONTROLLER, STUDENT, SDK):
        values = [case["code_sha256"][path] for case in cases]
        shared = len(set(values)) == 1
        expected_shared = path in (RUNTIME, SDK)
        need(shared == expected_shared, "code_sha256", f"unexpected cross-case fingerprint pattern for {path}")
        need(values[0] == values[1], "code_sha256", f"stack/unstack code fingerprints differ for {path}")
        code_comparison.append({"path": path, "reported_sha256_by_case": dict(zip(CASE_FILES, values)), "same_reported_digest_across_cases": shared})
    for field in ("initial_state_sha256", "policy_initial_state_sha256"):
        need(cases[1][field] == cases[2][field] != cases[0][field], field, "unexpected initial-state fingerprint relationship")
    need(cases[0]["seed"] == cases[1]["seed"], "seed", "non-voice selected seeds differ")
    counter = data["earlier_diagnostic_counterexample"]
    shape(counter, "source bytes sha256 last_write_utc termination task_success physical_success assessment sdk_hardware_connected".split(), "earlier_diagnostic_counterexample")
    fixed(source_path(counter["source"], "counterexample.source"), "unstack_memory_sdk_v3.json", "counterexample source basename")
    integer(counter["bytes"], "counterexample.bytes", 1)
    digest(counter["sha256"], "counterexample.sha256")
    earlier_time = timestamp(counter["last_write_utc"], "counterexample.last_write_utc")
    need(earlier_time < timestamp(cases[1]["last_write_utc"], "unstack.last_write_utc") <= cutoff, "counterexample", "counterexample is not earlier than selected unstack")
    for key, value in {"termination": "end_unconfirmed", "task_success": None, "physical_success": None, "sdk_hardware_connected": False}.items():
        fixed(counter[key], value, "counterexample." + key)
    assessment(counter["assessment"], "counterexample.assessment", True)
    sources = data["source_text_checks"]
    shape(sources, (RUNTIME, VOICE, HARNESS), "source_text_checks")
    for path, record in sources.items():
        shape(record, ("sha256", "lines", "finding"), "source_text_checks." + path)
        digest(record["sha256"], "source_text_checks." + path)
        text(record["lines"], "source_text_checks.lines")
        text(record["finding"], "source_text_checks.finding")
        for case in cases:
            if path in case["code_sha256"]:
                fixed(record["sha256"], case["code_sha256"][path], "source_text_checks.digest_agreement")
    need("new CustomSlotsSceneMotionSim" in sources[RUNTIME]["finding"] and "per run" in sources[RUNTIME]["finding"], "source_text_checks", "separate initialization summary is absent")
    need("Synthetic audio" in sources[VOICE]["finding"] and "no real microphone or ASR" in sources[HARNESS]["finding"], "source_text_checks", "voice scope boundary is absent")
    return {
        "per_case_excerpt_consistency": per_case,
        "policy_fingerprint": {"selected_reported_sha256": policy["selected_policy_sha256"], "declared_policy_digests_match": True, "original_policy_bytes_rehashed": False},
        "initialization": {"separate_initialization_reported": True, "source_execution_reverified": False, "equal_unstack_voice_initial_hashes_reported": True, "continuous_world_demonstrated": False},
        "code_fingerprints": code_comparison,
        "single_final_code_revision_bundle": False,
        "code_revision_interpretation": "controller.py and native_physical_student.py have different reported digests between the non-voice and voice cases. sdk_adapter.py and research_runtime_controller_mujoco.py have matching reported digests. This is not a single-final-code-revision execution bundle.",
        "diagnostic_counterexample": {"source": counter["source"], "reported_diagnostic_samples": counter["assessment"]["samples"], "reported_assessment_success": True, "diagnostic_only": True, "reported_task_success": None, "termination": "end_unconfirmed", "eligible_as_task_success": False, "interpretation": "Diagnostic checks being true does not establish task completion."},
    }


def audit(data, excerpt_sha256=None):
    report = {
        "report_schema": "controller-derived-excerpt-audit.v1",
        "overall_status": "not_evaluated",
        "verification_scope": "derived_excerpt_internal_consistency_only",
        "input_excerpt_sha256": excerpt_sha256,
        "original_artifacts_reverified": False,
        "complete_experiment_verification": False,
        "general_success_rate_estimated": False,
        "limitations": list(LIMITATIONS),
        "errors": [],
    }
    try:
        report["checks"] = validate(data)
        report["overall_status"] = "limited_consistency_confirmed"
        report["exit_code"] = 2
    except EvidenceError as exc:
        report["overall_status"] = "invalid_or_out_of_scope_excerpt"
        report["errors"].append(str(exc))
        report["exit_code"] = 1
    return report


def render_markdown(report):
    lines = ["# Controller derived-excerpt audit", "", f"Status: **{report['overall_status']}**", "", "This is a bounded consistency audit, not a replication or original-artifact verification.", "", f"Exit code: {report['exit_code']}. Code 2 means the requested excerpt checks are consistent but complete experimental verification is unavailable. It is not an unqualified success status.", "", f"Input excerpt SHA-256: {report.get('input_excerpt_sha256') or 'unavailable'}", "", "## Limits"]
    lines += ["- " + text for text in report["limitations"]]
    if report["errors"]:
        lines += ["", "## Errors", *["- " + value for value in report["errors"]]]
    if "checks" in report:
        checks = report["checks"]
        lines += ["", "## Findings", "", checks["code_revision_interpretation"], "", "Separate initialization is declared in the extraction notes and source summary. Equal initial hashes are not continuity evidence.", "", "The earlier unstack v3 entry retains diagnostic_only=true, assessment.success=true, samples=501, task_success=null and end_unconfirmed. It is not counted as task success."]
        for case in checks["per_case_excerpt_consistency"]:
            lines += ["", f"### {PurePosixPath(case['source']).name}", "", "Reported task_success=true; diagnostic_only=false; physical_success=null (no real-world verdict); sdk_hardware_connected=false."]
            detail = case["detail"]
            if "reported_policy_decisions" in detail:
                lines += ["- Reported termination is model_done.", "- The first two displayed decisions preserve nominal versus applied-target separation, with one visible adjacent nominal link.", "- The reported checked=10 and equal=10 agree arithmetically with 11 decisions. The remaining links were not independently checked."]
            else:
                lines += ["- Nested execution.retarget, transfer_results[0] and source_return_summary completion fields agree.", "- Top-level termination, seed, policy_decisions, previous_target_links and first_two_decisions are absent in the excerpt. No null or zero observation is substituted.", "- The symbolic plan is explicitly scoped breadth-first search, not a learned planner. Synthetic fixtures do not establish real microphone or ASR performance."]
    return "\n".join(lines) + "\n"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="derived controller evidence JSON only")
    parser.add_argument("--report-name", help="new run identifier inside this tool's reports directory; never a filesystem path")
    args = parser.parse_args(argv)
    root = Path(__file__).absolute().parent
    sha = None
    try:
        raw = read_input(args.input)
        sha = hashlib.sha256(raw).hexdigest()
        data = decode_json(raw)
        report = audit(data, sha)
    except (AuditInputError, OSError) as exc:
        report = {"report_schema": "controller-derived-excerpt-audit.v1", "overall_status": "input_error", "verification_scope": "derived_excerpt_internal_consistency_only", "input_excerpt_sha256": sha, "original_artifacts_reverified": False, "complete_experiment_verification": False, "general_success_rate_estimated": False, "limitations": list(LIMITATIONS), "errors": [str(exc)], "exit_code": 3}
    report["audit_time_utc"] = datetime.now(timezone.utc).isoformat()
    run_name = args.report_name or datetime.now(timezone.utc).strftime("audit_%Y%m%dT%H%M%SZ_") + uuid.uuid4().hex[:8]
    try:
        output = write_reports(root, run_name, report, render_markdown(report))
    except (AuditInputError, OSError) as exc:
        print(f"Report output blocked: {exc}", file=sys.stderr)
        return 3
    print(f"{report['overall_status']}; exit={report['exit_code']}; reports={output}")
    return report["exit_code"]


if __name__ == "__main__":
    sys.exit(main())
