# Controller evidence audit

논문·발표 후속용 **파생 발췌 내부 일관성 검사기**입니다. 표 4 검사기와 별도이며, 표 4 수치 재계산이나 원실험 재현을 하지 않습니다. 표준 라이브러리만 사용합니다.

## 실행

통합 원고 묶음의 루트에서 실행합니다. 아래는 검사기 폴더를 `control_audit/`, 입력 발췌를 `docs/`에 둔 배치입니다.

```sh
python -B -m unittest discover -s control_audit/tests -v
python -B control_audit/controller_evidence_audit.py \
  docs/controller_development_evidence.json --report-name example_new
```

같은 report-name을 재사용하면 기존 결과를 덮어쓰지 않고 거부합니다. 다시 실행할 때 이름을 바꾸거나 --report-name을 생략하면 됩니다. 출력 경로 옵션은 제공하지 않습니다. 실행한 검사기 폴더의 reports/ 아래 새 실행 폴더에 report.json과 report.md만 생성합니다.

입력 경로에는 `..`가 들어갈 수 없습니다. 다른 배치에서는 해당 JSON의 실제 절대 경로 또는 `..`가 없는 상대 경로를 지정하세요. 검사기 폴더 안에서 단위테스트만 실행하려면 `python -B -m unittest discover -s tests -v`를 사용합니다. 최종 코드로 실행한 실제 입력의 감사 결과는 `reports/supplied_excerpt_final_checked/`, 테스트 실행 기록은 `reports/verification_summary_final/`에 있습니다.

### 종료 코드

- **2**: 허용된 발췌 검사에서 내부 모순이 발견되지 않았지만 원본 검증은 불가능함(limited_consistency_confirmed). 완전한 검증을 뜻하는 성공 코드로 처리하지 않습니다.
- **1**: 필수 필드 누락, 스키마 위반, 범위 초과 또는 값·관계 모순. 첫 발견 오류를 표시하고 정상 findings를 만들지 않습니다.
- **3**: 입력 읽기·파싱 또는 안전한 새 보고서 생성 실패. 입력 오류는 가능한 경우 명시적인 오류 보고서로 남깁니다. 출력이 차단되면 stderr로 보고하며 일부 새 결과만 남을 수 있습니다.
- **0**: 이 제한된 증거 계약의 CLI에서는 사용하지 않습니다. unittest 자체의 정상 종료는 일반적인 코드 0입니다.

## 무엇을 검사하는가

- manipulation-controller-development-evidence.v1의 닫힌 스키마와 선택된 사례 구성. 알 수 없는 필드도 통과시키지 않습니다. 새 버전·추가 사례가 들어오면 별도 계약 검토가 필요합니다.
- 저장된 정책 지문의 형식과 선택 정책에 대한 사례 간 일치. 원본 모델의 바이트 지문을 새로 계산하지 않습니다.
- 개별 초기화에 대한 발췌 설명, 초기 배치·초기 상태 지문 관계. 같은 seed나 상태 지문을 연속 환경의 증거로 해석하지 않습니다.
- 비음성 사례의 model_done, 음성 사례의 중첩 transfer_results 및 execution.retarget, source_return_summary.
- task_success, diagnostic_only, physical_success=null, sdk_hardware_connected=false의 구분. 음성의 누락된 최상위 termination/seed/policy_decisions 등을 null이나 0인 관측값으로 채우지 않습니다.
- 과거 unstack v3의 samples=501, diagnostic_only=true, assessment.success=true, task_success=null, end_unconfirmed 반례를 과제 성공으로 취급하지 않습니다.
- SDK 명목 목표와 적용·제어 기준 목표의 분리. 비음성 사례마다 발췌된 첫 두 판단 사이 한 연결만 직접 비교합니다. 보고된 checked=10, equal=10은 policy_decisions=11과의 내부 수치 관계만 검사하며, 보이지 않는 나머지 연결은 검사하지 않습니다.
- controller.py와 native_physical_student.py는 음성/비음성 사례 사이 저장된 지문이 다릅니다. sdk_adapter.py와 research_runtime_controller_mujoco.py의 저장된 지문은 같습니다. 단일 최종 코드판으로 실행한 묶음이 아닙니다.
- 실제/가상 SDK 정지 동등성 미검증, 동작 중 중단 미시험, 파지 증거가 아닌 그리퍼 보고, 센서 미모델링 등 범위 제한을 유지합니다.

## 무엇을 하지 않는가

원본 JSON·NPZ·모델·소스 스크립트 전체는 동봉되어 있지 않습니다. 검사기는 발췌의 원본 경로를 따라가거나 열지 않습니다. 원본의 크기·시간·해시와 hash-match 플래그는 발췌에 저장된 주장으로 취급합니다. 이번에 실제 해시를 계산한 대상은 제공된 **발췌 JSON 자체**뿐입니다.

새 실험, 학습, 시뮬레이션, 모델/NPZ 역직렬화, 공식 프로젝트 코드 import, 모터/마이크 조작, 네트워크, 외부 공개를 하지 않습니다. 일반 성공률·전체 원실험 재검증·연속 실물 결과·독립된 인과 개선 결과를 만들지 않습니다. 음성 경로는 합성 음성/전사 fixture와 비학습 기호 계획 설명을 보존하며 실제 ASR 검증으로 확대하지 않습니다.

## 파일 안전과 플랫폼

- 입력은 크기가 제한된 일반 JSON 파일만 읽기 전용으로 엽니다. 중복 JSON 키·비표준 비유한 상수·잘못된 UTF-8·잘못된 JSON을 거부합니다.
- 경로의 `..`, 입력 및 상위 디렉터리 symlink, 출력 경로 symlink를 거부합니다. 디렉터리 fd와 O_NOFOLLOW로 각 단계에 접근합니다.
- 출력은 고정 reports/ 아래 독점 생성한 새 실행 폴더에만 쓰고 O_EXCL로 기존 파일을 덮어쓰지 않습니다. 원본 폴더를 수정하지 않습니다.
- 이 구현은 descriptor-based POSIX 기능을 요구합니다. 테스트한 환경은 Linux입니다. 네이티브 Windows 지원을 주장하지 않으며 필요한 기능이 없으면 실패하도록 구성했습니다.
- 악의적인 동시 로컬 관리자가 이미 열린 디렉터리를 이동·마운트하거나 검사기 코드를 바꾸는 상황까지 격리하는 보안 샌드박스는 아닙니다.

## 구성

- controller_evidence_audit.py: 발췌 스키마·일관성 검사와 CLI.
- safe_io.py: 제한된 읽기, 안전한 신규 보고서 생성.
- tests/fixtures.py: 실제 관측이 아닌 합성 in-memory fixture.
- tests/test_audit.py: 스키마·의미·누락·범위·경로·덮어쓰기 회귀 테스트.
- reports/: 새로 생성한 JSON/Markdown 결과.

테스트 통과는 검사기 동작에 관한 것이며 로봇 실험 성능이 아닙니다.
