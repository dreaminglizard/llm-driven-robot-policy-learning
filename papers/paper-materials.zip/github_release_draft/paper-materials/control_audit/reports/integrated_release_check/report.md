# Controller derived-excerpt audit

Status: **limited_consistency_confirmed**

This is a bounded consistency audit, not a replication or original-artifact verification.

Exit code: 2. Code 2 means the requested excerpt checks are consistent but complete experimental verification is unavailable. It is not an unqualified success status.

Input excerpt SHA-256: 7c3fe2c2aef1aee77b6e2af8cddc3b0b48974c1e58577a075bbb0c75e7ef8c07

## Limits
- Only the derived excerpt's schema, field relationships and reported fingerprints are checked. Full original JSON, NPZ, model and source-script bytes are not bundled or re-read.
- Reported original-file SHA-256 values and before/after or fresh-hash-match flags are declarations in the excerpt, not hashes recomputed by this audit. Only the supplied excerpt bytes are hashed here.
- The first two displayed decisions provide one visible adjacent nominal-target link per non-voice case. Reported checked=10 and equal=10 are checked only for arithmetic consistency with 11 policy decisions; the other links are unavailable.
- Voice completion is checked only at its nested execution, transfer_results and source_return_summary fields. Absent top-level termination, seed and decision/link fields remain absent, not observed null or zero.
- Separate initialization is a reported extraction/source-summary claim. Equal seeds or initial-state hashes do not demonstrate a continuous world or a sequential physical run.
- Diagnostic sample outcomes are not task outcomes. physical_success=null means no real-world verdict, not measured hardware failure. Hardware is reported disconnected.
- The selected configuration labels gripper reports as non-evidence of grasp, assumes quiet diagnostics without modeled sensors, and reports real/virtual SDK stop equivalence and active-motion interruption as unverified. SDK-shaped virtual delivery is not physical SDK behavior validation.
- No new experiment, training, simulation, model loading, official-project import, motor/microphone operation, network request or publication is performed. No aggregate/general success rate, causal improvement, held-out result or continuous real-world result is estimated.
- Descriptor-based filesystem safeguards were exercised on Linux/POSIX. Native Windows support is not established and is deliberately not claimed.

## Findings

controller.py and native_physical_student.py have different reported digests between the non-voice and voice cases. sdk_adapter.py and research_runtime_controller_mujoco.py have matching reported digests. This is not a single-final-code-revision execution bundle.

Separate initialization is declared in the extraction notes and source summary. Equal initial hashes are not continuity evidence.

The earlier unstack v3 entry retains diagnostic_only=true, assessment.success=true, samples=501, task_success=null and end_unconfirmed. It is not counted as task success.

### stack_memory_sdk_v5.json

Reported task_success=true; diagnostic_only=false; physical_success=null (no real-world verdict); sdk_hardware_connected=false.
- Reported termination is model_done.
- The first two displayed decisions preserve nominal versus applied-target separation, with one visible adjacent nominal link.
- The reported checked=10 and equal=10 agree arithmetically with 11 decisions. The remaining links were not independently checked.

### unstack_memory_sdk_v5.json

Reported task_success=true; diagnostic_only=false; physical_success=null (no real-world verdict); sdk_hardware_connected=false.
- Reported termination is model_done.
- The first two displayed decisions preserve nominal versus applied-target separation, with one visible adjacent nominal link.
- The reported checked=10 and equal=10 agree arithmetically with 11 decisions. The remaining links were not independently checked.

### voice_return_memory_sdk_v3.json

Reported task_success=true; diagnostic_only=false; physical_success=null (no real-world verdict); sdk_hardware_connected=false.
- Nested execution.retarget, transfer_results[0] and source_return_summary completion fields agree.
- Top-level termination, seed, policy_decisions, previous_target_links and first_two_decisions are absent in the excerpt. No null or zero observation is substituted.
- The symbolic plan is explicitly scoped breadth-first search, not a learned planner. Synthetic fixtures do not establish real microphone or ASR performance.
