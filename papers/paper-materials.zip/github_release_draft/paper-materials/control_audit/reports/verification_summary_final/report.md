# Controller audit verification

- Python 3.12.14, Linux/POSIX. Native Windows not tested.
- 60 fixture test methods passed; zero failures and zero errors. These are software tests, not robot trials.
- Final Python sources parsed successfully.
- The supplied excerpt audit returned limited_consistency_confirmed, exit code 2.
- The source excerpt digest was unchanged before and after execution.
- No original JSON/NPZ/model/source-script bytes were reverified.
- Input excerpt SHA-256: 7c3fe2c2aef1aee77b6e2af8cddc3b0b48974c1e58577a075bbb0c75e7ef8c07
- Actual final report: reports/supplied_excerpt_final_checked/report.json

## Reproduction in the integrated paper package

python -B -m unittest discover -s control_audit/tests -v
python -B control_audit/controller_evidence_audit.py docs/controller_development_evidence.json --report-name example_new

Unit tests use exit code 0; a consistent but incomplete excerpt audit uses exit code 2.
