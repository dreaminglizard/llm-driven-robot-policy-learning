"""Synthetic temporary fixtures only; no original project or experiment code."""

import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import verify_source_bundle as verifier


class VerifierTests(unittest.TestCase):
    def setUp(self):
        verifier.require_safe_open_support()
        self.temp = tempfile.TemporaryDirectory(prefix="verify-fixture-", dir=Path(__file__).resolve().parent)
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.source = self.base / "source"
        self.overlay = self.base / "overlay"
        self.reports = self.base / "reports"
        for path in (self.source, self.overlay, self.reports):
            path.mkdir()
        self.entries = []
        for number in range(258):
            content = self.content(number)
            self.entries.append({
                "path": "scripts/file_%03d.py" % number,
                "recorded_sha256": hashlib.sha256(content).hexdigest(),
                # Deliberately wrong: this historical observation must never be a target.
                "observed_sha256": "f" * 64,
            })
        self.audit = self.base / "audit.json"
        self.save_audit()

    @staticmethod
    def content(number):
        # Invalid Python so accidental source import/execution would fail loudly.
        return ("fixture %d: not executable Python\n" % number).encode()

    def save_audit(self):
        self.audit.write_text(json.dumps({"schema": verifier.AUDIT_SCHEMA,
                                         "count": len(self.entries), "files": self.entries}))

    def populate(self, root, numbers=range(258)):
        for number in numbers:
            path = root / self.entries[number]["path"]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(self.content(number))

    def check(self, overlay=False):
        pins, digest = verifier.load_audit(self.audit)
        with verifier.LocalRoot(self.source) as source:
            if overlay:
                with verifier.LocalRoot(self.overlay) as extra:
                    return verifier.check_bundle(pins, digest, source, extra)
            return verifier.check_bundle(pins, digest, source)

    def test_clean_258(self):
        self.populate(self.source)
        report = self.check()
        self.assertEqual(report["counts"], dict(matched=258, missing=0, mismatched=0, error=0))
        self.assertTrue(report["complete_recorded_pin_set_verified"])
        self.assertTrue(report["single_source_root_verified"])
        self.assertFalse(report["full_repository_snapshot_verified"])
        self.assertTrue(all(row["origin"] == "source" for row in report["files"]))

    def test_incomplete(self):
        self.populate(self.source, range(251))
        report = self.check()
        self.assertEqual(report["counts"]["matched"], 251)
        self.assertEqual(report["counts"]["missing"], 7)
        self.assertEqual(len(report["files"]), 258)
        self.assertFalse(report["complete_recorded_pin_set_verified"])

    def test_mismatch(self):
        self.populate(self.source)
        changed = self.source / self.entries[3]["path"]
        changed.write_bytes(b"different bytes\n")
        report = self.check()
        self.assertEqual(report["counts"]["mismatched"], 1)
        self.assertEqual(report["files"][3]["status"], "mismatched")
        self.assertFalse(report["complete_recorded_pin_set_verified"])
        self.assertEqual(changed.read_bytes(), b"different bytes\n")

    def test_overlay_completes_pins_but_not_single_snapshot(self):
        self.populate(self.source)
        self.populate(self.overlay, range(7))
        for number in range(7):
            (self.source / self.entries[number]["path"]).write_bytes(b"newer source\n")
        report = self.check(overlay=True)
        self.assertTrue(report["complete_recorded_pin_set_verified"])
        self.assertFalse(report["single_source_root_verified"])
        self.assertFalse(report["full_repository_snapshot_verified"])
        self.assertEqual(report["matched_from_source"], 251)
        self.assertEqual(report["matched_from_overlay"], 7)
        self.assertEqual(report["files"][0]["origin"], "overlay")
        self.assertEqual(report["files"][7]["origin"], "source")

    def test_seven_overlay_files_are_not_258_snapshot(self):
        self.populate(self.overlay, range(7))
        report = self.check(overlay=True)
        self.assertEqual(report["counts"]["matched"], 7)
        self.assertEqual(report["counts"]["missing"], 251)
        self.assertFalse(report["complete_recorded_pin_set_verified"])

    def test_bad_overlay_does_not_fall_back_to_good_source(self):
        self.populate(self.source)
        self.populate(self.overlay, range(1))
        (self.overlay / self.entries[0]["path"]).write_bytes(b"bad overlay")
        report = self.check(overlay=True)
        self.assertEqual(report["files"][0]["status"], "mismatched")
        self.assertEqual(report["files"][0]["origin"], "overlay")
        self.assertEqual(report["files"][0]["attempted_origins"], ["overlay"])

    def test_unsafe_paths(self):
        for path in ("../escape.py", "/tmp/file.py", "a/../../file.py", "C:/file.py",
                     "a\\file.py", "a//file.py", "a/./file.py", "a/file.py/", "",
                     "a/\0file.py", "a/CON", "a/file.py."):
            with self.subTest(path=path), self.assertRaises(verifier.VerificationError):
                verifier.relative_parts(path)

    def test_partial_manifest_rejected(self):
        self.entries = self.entries[:7]
        self.save_audit()
        with self.assertRaisesRegex(verifier.VerificationError, "all 258"):
            verifier.load_audit(self.audit)

    def test_invalid_manifest_fields(self):
        for replacement in ("../outside.py", self.entries[1]["path"].upper()):
            with self.subTest(path=replacement):
                old = self.entries[0]["path"]
                self.entries[0]["path"] = replacement
                self.save_audit()
                with self.assertRaises(verifier.VerificationError):
                    verifier.load_audit(self.audit)
                self.entries[0]["path"] = old
        self.entries[0]["recorded_sha256"] = "invalid"
        self.save_audit()
        with self.assertRaises(verifier.VerificationError):
            verifier.load_audit(self.audit)

    def test_file_and_directory_symlinks_blocked(self):
        outside = self.base / "outside"
        self.populate(outside, range(1))
        (self.source / "scripts").symlink_to(outside / "scripts", target_is_directory=True)
        report = self.check()
        self.assertEqual(report["counts"]["error"], 258)
        (self.source / "scripts").unlink()
        (self.source / "scripts").mkdir()
        (self.source / self.entries[0]["path"]).symlink_to(outside / self.entries[0]["path"])
        report = self.check()
        self.assertEqual(report["counts"]["error"], 1)
        self.assertIsNone(report["files"][0]["actual_sha256"])

    def test_unsafe_overlay_not_masked(self):
        self.populate(self.source)
        (self.overlay / "scripts").symlink_to(self.source / "scripts", target_is_directory=True)
        report = self.check(overlay=True)
        self.assertEqual(report["counts"]["error"], 258)
        self.assertEqual(report["files"][0]["origin"], "overlay")

    def test_fifo_not_read(self):
        (self.source / "scripts").mkdir()
        os.mkfifo(self.source / self.entries[0]["path"])
        report = self.check()
        self.assertEqual(report["counts"]["error"], 1)
        self.assertEqual(report["counts"]["missing"], 257)

    def test_cli_and_report_overwrite(self):
        self.populate(self.source)
        args = ["--source-root", str(self.source), "--audit", str(self.audit),
                "--report", "result.json"]
        with patch.object(verifier, "WORK_DIR", self.reports), contextlib.redirect_stdout(io.StringIO()), \
                contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(verifier.main(args), 0)
            old = (self.reports / "result.json").read_bytes()
            self.assertEqual(verifier.main(args), 2)
            self.assertEqual((self.reports / "result.json").read_bytes(), old)
            self.assertEqual(verifier.main(args + ["--overwrite"]), 0)
            (self.source / self.entries[0]["path"]).unlink()
            self.assertEqual(verifier.main(args + ["--overwrite"]), 1)
        report = json.loads((self.reports / "result.json").read_text())
        self.assertEqual(report["counts"]["missing"], 1)
        self.assertEqual(sorted(path.name for path in self.reports.iterdir()), ["result.json"])

    def test_report_cannot_escape_or_write_into_source(self):
        outside = self.base / "untouched.json"
        outside.write_bytes(b"unchanged")
        (self.reports / "link.json").symlink_to(outside)
        (self.reports / "linked-dir").symlink_to(self.base, target_is_directory=True)
        with patch.object(verifier, "WORK_DIR", self.reports), verifier.LocalRoot(self.source) as source:
            for name in ("../escape.json", "/tmp/escape.json", "link.json", "linked-dir/result.json"):
                with self.subTest(path=name), self.assertRaises((OSError, ValueError)):
                    verifier.write_report({}, name, [source], self.audit, overwrite=True)
        self.assertEqual(outside.read_bytes(), b"unchanged")
        with patch.object(verifier, "WORK_DIR", self.source), verifier.LocalRoot(self.source) as source:
            with self.assertRaises(verifier.VerificationError):
                verifier.write_report({}, "result.json", [source], self.audit)

    def test_overwrite_does_not_change_hardlinked_file(self):
        target = self.base / "keep.json"
        target.write_bytes(b"keep original")
        os.link(target, self.reports / "result.json")
        with patch.object(verifier, "WORK_DIR", self.reports), verifier.LocalRoot(self.source) as source:
            verifier.write_report({"test": True}, "result.json", [source], self.audit, overwrite=True)
        self.assertEqual(target.read_bytes(), b"keep original")
        self.assertEqual(json.loads((self.reports / "result.json").read_text()), {"test": True})

    def test_report_cannot_replace_audit_or_non_json_file(self):
        audit_inside = self.reports / "audit.json"
        audit_inside.write_bytes(self.audit.read_bytes())
        original = audit_inside.read_bytes()
        with patch.object(verifier, "WORK_DIR", self.reports), verifier.LocalRoot(self.source) as source:
            with self.assertRaises(verifier.VerificationError):
                verifier.write_report({}, "audit.json", [source], audit_inside, overwrite=True)
            with self.assertRaises(verifier.VerificationError):
                verifier.write_report({}, "script.py", [source], self.audit, overwrite=True)
        self.assertEqual(audit_inside.read_bytes(), original)

    def test_unsupported_secure_open_fails_closed(self):
        with patch.object(os, "supports_dir_fd", set()):
            with self.assertRaisesRegex(verifier.VerificationError, "WSL"):
                verifier.LocalRoot(self.source)


if __name__ == "__main__":
    unittest.main()
