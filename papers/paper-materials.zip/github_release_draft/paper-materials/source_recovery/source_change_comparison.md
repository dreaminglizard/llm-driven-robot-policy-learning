# 복원된 과거 소스와 현재 소스의 정적 비교

검토일: 2026-11-11. 아래의 ‘과거’는 manifest의 과거 SHA-256과 일치하는 복원본, ‘현재’는 같은 manifest에 수록된 현재 캡처본을 뜻한다. 행 번호는 각 버전의 파일 기준이다.

## 핵심 결론

- 과거 소스 3개는 지정된 과거 해시와 바이트 단위로 일치한다. 현재 소스 7개도 각각 캡처 manifest의 해시·크기와 일치하지만, 기록된 과거 해시와는 모두 다르다.
- 확인된 변화는 **관측 인코더의 의존성 교체**, **가상 동작의 선택적 보간·경로·취소 처리 추가**, **일부 과거 스냅샷에 대한 코드 해시 검사 완화**다. 추가 확보한 인코더 소스에서는 관측 14필드의 이름·순서·수치식·관측 검증 분기가 정적으로 일치하지만, 기존 호출의 task 검증은 새 인코더에 없다. 세 파일 전체를 단순한 비동작 변경으로 취급할 수 없다.
- 해시 일치는 소스 복원의 증거이지 실험 재현의 증거가 아니다. 7개 해시 차이도 과거 실행이 그 7개를 모두 import하거나 사용했다는 뜻은 아니다. 실행 경로, 실제 설정, 의존성, 모델·데이터·물리 상태 및 결과 일치 여부는 별도 확인이 필요하다.

## 1. 검증 범위와 결과

제공된 manifest, 소스 복사본 및 추가 제공된 두 인코더 의존성 사본만 읽었다. 원시 바이트의 SHA-256과 크기를 다시 계산하고 텍스트 차이를 비교했다. 프로젝트 모듈의 import·실행, 입력 실행 테스트, 시뮬레이션·학습, 하드웨어·네트워크 접근 및 원본 변경은 하지 않았다. 원래 assignment 파일 자체는 이번 범위에 포함되지 않아, 해시 대조 기준은 manifest와 추가로 전달된 pin 정보다.

| 복원된 과거 파일 | 바이트 수 | 재계산 SHA-256 | 판정 |
|---|---:|---|---|
| `raccoon_memory/scene_features.py` | 4,530 | `0be50dc0aebda5d461ebfbcc23d5bf3e19a206387fd17f31e86d2338186aaf53` | 과거 pin과 일치 |
| `raccoon_memory/scene_ramped_motion_sim.py` | 4,101 | `c5301dfa214940067e18e8f8351c057d63b585ee6ecb85480750d8a4ffcd6768` | 과거 pin과 일치 |
| `raccoon_memory/scene_custom_slots_sim.py` | 7,149 | `5e5a1166bbad73f2f61a0d35b827db597044fbc0023bf4627ae96f52d48d81c0` | 과거 pin과 일치 |

현재 7개와 과거 3개의 검증값은 동봉한 `hash_verification.json`에 모두 기록했다. 비교 대상 세 파일의 unified diff도 동봉했다.

추가 인코더 사본의 재계산값도 전달된 해시와 일치했다. `raccoon_memory/motion_policy.py`는 `73e6897d0d9fa8d940136748714e872e73f0f41d40f23e4167bca5555410cd26`이며 제공된 과거 assignment pin과 같다. `raccoon_memory/robot_observation_features.py`는 `3ad73782e5a7f129b4173b35b387c20a50a91c750309c28595fd8a03d4ac2033`이며 당시 assignment에 없던 새 의존성으로 제공되었다. 후자의 과거 버전을 복원했다는 뜻은 아니다.

## 2. 확인된 변경과 해석

### A. `raccoon_memory/scene_features.py`: 입력 인코더 의존성 교체

**코드에서 확인한 사실**

- `motion_policy` 대신 `robot_observation_features`를 import한다. 특징 이름도 `motion_policy.FEATURE_NAMES[:14]` 대신 새 모듈의 전체 `FEATURE_NAMES`를 사용한다. 과거·현재 10–16행.
- `encode_scene_features()`의 초기 벡터가 `motion_policy.encode_features(observation, goal)[:14]`에서 `robot_observation_features.encode(observation)`로 바뀐다. 과거·현재 46–50행.
- 뒤에 붙이는 목표 one-hot, 등록 장면, 활성 객체, 명목 슬롯 좌표와 유한성·길이 검사, `history_window()` 및 스키마 문자열은 변하지 않았다. 과거·현재 17–27, 51–86행.

**추가 의존성 비교: 첫 14필드의 정적 일치**

`motion_policy.py` 24–35, 122–128행과 `robot_observation_features.py` 7–13, 60–66행을 대조하면 다음 이름·순서·수치식이 일치한다. 새 모듈의 `FEATURE_NAMES` 전체가 정확히 기존 첫 14개다.

| 위치(1부터) | 내용 | 양쪽 수치식 |
|---|---|---|
| 1–4 | `joint_1_deg/180` … `joint_4_deg/180` | 각 관절을 float로 변환한 뒤 180.0으로 나눔 |
| 5–6 | `sensor_valid`, `moving` | 각 bool을 float로 변환 |
| 7–9 | `gripper_command_none/open/closed` | `(None, "open", "closed")` 순서의 비교 결과를 float로 변환 |
| 10–12 | `gripper_reported_none/open/closed` | 같은 순서의 보고 상태 one-hot |
| 13–14 | `gripper_reported_valid`, `gripper_feedback_fresh` | 각 bool을 float로 변환 |

관측 검증도 동일한 조건을 사용한다. observation이 dict인지, 스키마가 `PolicyObservation.phase1`인지, 관절이 길이 4의 list/tuple인지 확인한다. 관절 원소는 정확히 int/float 타입이어야 하며 bool을 허용하지 않는다. float 변환의 overflow/value 오류와 비유한 값을 거부한다. 네 상태 플래그는 정확히 bool이어야 하고 `sensor_valid`는 참이어야 한다. 명령/보고 상태는 None·open·closed만 허용한다. 유효한 보고는 fresh여야 하고 상태가 있어야 하며, 무효 보고는 상태가 None이어야 한다. 각 필수 키의 누락도 거부한다. 해당 관측 검사 순서와 오류 문구는 일치한다. 근거: `motion_policy.py`의 `_mapping`, `_required`, `_finite_number`, `_vector`, `_flag`, `encode_features()` 44–65, 79–113행; `robot_observation_features.py`의 `_required`, `_flag`, `encode()` 16–59행.

**남는 차이: task 검증 및 의존성 로딩**

- 기존 `encode_features()`는 observation 검사 도중 task가 dict인지도 먼저 확인한다(99–101행). 관측 검사 후에는 source/destination slot·level 네 필드를 필수 양의 정수로 검증하고 float 변환·4로 나누기를 수행하며, source와 destination이 같으면 거부한다(114–121행). 최종 길이·유한성 검사는 task까지 포함한 18개 값에 적용된다(122–130행). 호출자가 나중에 `[:14]`로 자르더라도 이 task 검증은 실행 경로에 남는다.
- 새 `encode()`는 task 인자·검증이 없으며 14개 관측 값만 길이·유한성 검사한다(`robot_observation_features.py` 29–67행). 따라서 두 독립 함수의 허용 입력 영역이나 오류 우선순위까지 같다고 할 수 없다.
- scene 호출에서는 두 버전 모두 먼저 같은 `transfer_task()`로 `goal`을 만든다(`scene_features.py` 30–50행). 목표 one-hot은 현재도 유지되므로 task 조건부 입력 자체가 사라진 것은 아니다. 다만 기존 추가 task 검증이 모든 장면 입력에서 중복이었다고 입증하려면 `task_catalog`까지 검토해야 한다. 이번에는 그 구현과 입력 실행 테스트를 확인하지 않았다.
- 기존 의존성은 모듈 최상단에서 torch를 import한다(`motion_policy.py` 16–19행). 새 의존성은 math만 import한다(`robot_observation_features.py` 1–4행). 따라서 이 직접 의존 경로에서 학습 프레임워크를 분리한 변경은 코드로 확인된다. 전체 프로세스의 다른 경로까지 torch를 로드하지 않는다는 뜻은 아니다.

**판정:** 정상적인 일반 자료형 입력에 대해 양쪽 검증을 통과한다는 조건 아래, 첫 14개 관측 특징의 구성과 수치식은 정적으로 일치한다. 그대로 유지된 장면 특징과 합하면 특징 차원은 82개다. 이는 주석에만 근거한 추정보다 강한 소스 수준 확인이지만, 입력 실행 테스트·모델 추론·전체 동작 동등성이나 실험 재현 검증은 아니다.

### B. `raccoon_memory/scene_ramped_motion_sim.py`: 가상 동작 선택지와 취소 처리 확대

**코드에서 확인한 사실**

- `RampedSceneMotionSim.__init__()`에 `finger_open_profile`과 `closed_move_profile`이 추가되고 `reset()`이 이를 유지한다. 기본 손가락 동작은 `instant`, 기본 닫힌 MOVE 곡선은 기존 `ramp_shape`를 따른다. 현재 20–72행; 과거 23–40행.
- 선택적 `minimum_jerk_0p5s` 프로필은 목표 개구량이 정확히 0.04 m이고 기존 개구량보다 커지는 경우, 1초 명령에서 처음 0.5초 동안 최소 저크 곡선으로 손가락 목표를 증가시킨다. 해당 조건에서는 좌우 목표의 유효성·대칭성을 검사한다. 과거에는 손가락 목표를 루프 전에 즉시 설정했다. 현재 `command()` 123–153행; 과거 63–64행.
- 닫힌 MOVE 전용 곡선을 적용할 수 있다. 판별은 목표 개구량과 기존 손가락 **제어 목표**가 모두 0인지, 그리고 `duration == ramp == 2`인지에 따른다. 또는 `_demo_one_second_move`가 참이고 명령이 1초·램프가 0.5초인 분기도 있다. 선택지에는 최소 저크와 smoothstep이 포함된다. 실제 손가락 위치·접촉에 의한 ‘닫힘 확인’은 이 조건에 없다. 현재 100–103, 122, 140–148행.
- `_checked_straight_descent`가 부착된 경우 타입, 닫힌 MOVE 조건, timestep, tick 수, 시작·종료 관절 목표를 확인한 뒤 일반 보간 대신 제공된 tick별 `targets_rad`를 사용한다. 현재 107–116, 146–148행. 경로 생성·안전 검사의 구현은 이번 비교 범위에 없다.
- `command(..., cancel=None)`과 경로별 취소 신호가 추가됐다. 동작 전·루프 중·물리 스텝 직전·동작 후·결과 반환 전 취소를 검사하며, 예외는 기존 예외 처리 경로를 통해 layout을 `uncertain`으로 표시한다. 움직임 전 취소도 해당될 수 있다. 현재 75–83, 118–120, 132–165행; 과거 42–76행.

**정적 해석과 한계**

새 프로필·경로·취소 분기가 활성화되면 손가락과 팔의 목표 시간열, 종료 시점 또는 오류 상태가 달라질 수 있다. 선택적 기능을 사용하지 않고 동일한 의존성·설정을 쓴다면 기존 보간을 유지하도록 작성된 부분이 보이지만, 실제 과거 실행의 분기 선택이나 동일 궤적·성공률은 확인하지 않았다. 두 버전 모두 이 램프가 검증된 속도·가속도·충돌·실기 안전 한계를 부여하지 않는다고 명시한다(1–7행). 새 경로 수용 코드를 곧 안전성 검증이나 실기 검증으로 표현하면 안 된다.

### C. `raccoon_memory/scene_custom_slots_sim.py`: 프로필 전달과 과거 상태 수용 범위 변경

**코드에서 확인한 사실**

- 생성자와 `reset()`이 새 손가락/닫힌 MOVE 프로필을 부모 시뮬레이터에 전달한다. 현재 66–98행; 과거 61–90행.
- 현재 `_COMPATIBLE_PHYSICAL_STATE_SOURCES`에는 두 개의 과거 코드 해시가 들어 있다. 그중 하나가 이번에 복원된 과거 파일의 해시다. 현재 55–60행. 다른 해시의 소스는 이번에 비교하지 않았다.
- 과거 `load_state()`는 자체 현재 코드 해시가 포함된 설정과 일치해야 했다. 현재는 저장 상태의 producer 해시가 허용 목록에 있으면 기대 해시를 그 값으로 바꾼다. 슬롯 좌표, 램프 시간·형태·임계값, 설정 digest, reset 좌표 검사는 그대로 남아 있으며, 이후 부모의 `load_state()`를 호출한다. 현재 132–150행; 과거 124–138행. 따라서 이 수정만으로 실제 로드 성공이 보장되지는 않는다.
- 슬롯 등록 검증, 초기 위치 이동 및 0.012 m XY 평가 임계값은 변하지 않았다. 현재 24–52, 73–84, 100–113행; 과거 24–52, 66–77, 92–105행.

**정적 해석과 한계**

이 변경은 제한된 과거 producer의 상태가 현재 코드의 **해당 설정 검사**를 통과할 수 있게 한다. 과거 정책·컨트롤러 전체를 복원하거나 이후 궤적의 동등성을 보장하는 변경은 아니다. 특히 이 클래스가 직접 기록·비교하는 `custom_slot_configuration`에는 새 `finger_open_profile`과 `closed_move_profile`이 포함되지 않는다(현재 `save_state()` 115–125행, `load_state()` 135–147행). 이 설정 검사만으로 새 프로필의 일치까지 확인할 수 없다. 부모 클래스가 별도로 무엇을 기록·검사하는지는 이번 입력에 없어 판단하지 않았다.

## 3. 미복원 부분과 논문 서술 경계

과거 버전이 없는 네 파일은 다음과 같다. 현재 해시의 차이만 확인했으며, 과거 기능·변경 내용·실험 영향은 추정하지 않았다.

- `raccoon_memory/scene_model_session.py`
- `raccoon_memory/scene_program_coordinator.py`
- `raccoon_memory/task_program.py`
- `raccoon_memory/task_program_v2.py`

논문에는 다음 범위까지 서술할 수 있다.

> 기록된 과거 소스 해시와 일치하는 세 모듈을 복원하고 현재 소스와 정적으로 비교하였다. 관측 인코더 의존성, 선택적 가상 동작 처리 및 상태 호환성 검사에서 변경을 확인하였다. 이 검토는 실행 동등성이나 실험 재현을 검증한 것이 아니며, 미복원 네 모듈과 실제 실행 의존성·설정의 확인이 남아 있다.

재현성을 주장하려면 과거 실행이 실제 사용한 소스와 의존성, 설정·모델·데이터·초기 상태를 먼저 특정한 뒤, 허가된 별도 실행에서 입력 인코딩, 제어 목표 시간열, 상태 복원 및 평가 결과의 일치 여부를 검증해야 한다. 이번 작업에서는 그 실행을 수행하지 않았다.
