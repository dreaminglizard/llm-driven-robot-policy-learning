# 과거 소스 회수·정적 비교 보완자료

## 결과

과거 평가가 기록한 파일 지문과 현재 파일 사이의 7개 차이 중, **3개는 기존 보존 실행 폴더에서 기대 SHA-256과 정확히 같은 과거 바이트를 회수했습니다.** 나머지 4개의 일치본은 이번에 확인한 프로젝트 소스·백업·실행 사본과 ZIP 범위에서 찾지 못했습니다. 다른 곳에도 없다는 뜻은 아닙니다.

회수한 파일:

- `scene_features.py`
- `scene_ramped_motion_sim.py`
- `scene_custom_slots_sim.py`

미회수 파일:

- `scene_model_session.py`
- `scene_program_coordinator.py`
- `task_program.py`
- `task_program_v2.py`

기존 프로젝트를 덮어쓰거나 과거판으로 되돌리지 않았습니다. 소스 파일을 읽고 해시·텍스트 차이만 확인했습니다. 새 학습·시뮬레이션·실물 실행 결과는 없습니다.

## 확인한 변화

첫 14개 로봇 관측 특징은 소스상 이름·순서·수치식·관측 검증 조건이 같지만, 기존 함수의 추가 task 검증은 새 관측 전용 함수에 없습니다. 이 확인을 전체 호출이나 실행의 동등성으로 확대하지 않습니다.

현재 코드에는 선택적인 손가락·닫힌 이동 보간, 취소와 경로 처리, 과거 상태 파일을 일부 허용하는 검사가 추가되어 있습니다. 과거 상태를 읽을 수 있다는 사실만으로 같은 제어 목표 시간열이나 같은 과제 결과가 재현된다고 볼 수 없습니다. 세부 근거는 `source_change_comparison.md`에 있습니다.

## 파일 구성

- `historical/`: 과거 pin과 일치한 소스 3개.
- `current/`: 비교 시점의 현재 소스 7개.
- `dependencies/`: 관측 특징의 정적 비교에 사용한 의존 소스 2개.
- `recovery_manifest.json`, `dependency_manifest.json`: 바이트 지문·출처·캡처 시각과 회수 범위.
- `hash_verification.json`: 제공된 소스 사본의 재계산 결과.
- `search_scope_summary.json`: 이번 탐색 범위와 미회수 항목.
- `source_change_comparison.md`, `*.diff`: 정적 비교 설명과 텍스트 차이.
- `code_version_audit.json`: 원 평가의 전체 258개 pin과 이전 현재판 대조.
- `verify_source_bundle.py`, `README.ko.md`: 읽기 전용 해시 검사 도구와 실행 설명.
- `test_verify_source_bundle.py`, `test_results.txt`: 가상 파일을 사용하는 단위 테스트 17개.
- `partial_source_verification_20261111.json`: 부분 사본에 대한 실제 바이트 검사 결과.

## 검사 결과의 의미

동봉된 현재 7개와 과거 3개를 함께 검사하면 **3개 일치, 4개 불일치, 251개 미제공**입니다. 251개는 이 부분 묶음에 넣지 않은 파일이며, 원 프로젝트에서 사라졌다는 뜻이 아닙니다. 이전 전체 지문 대조에서 그 251개는 일치한 것으로 기록되어 있으나, 이 부분 묶음만으로 전체 258개를 다시 검증할 수는 없습니다.

검사기는 Python 3.9 이상의 Linux/macOS/WSL에서 표준 라이브러리만 사용합니다. 안전한 경로 검사 기능이 없는 **네이티브 Windows에서는 중단**합니다. Windows에서 실행 가능하다고 검증한 도구가 아닙니다. 검증기는 프로젝트 코드를 import하거나 실행하지 않으며, 모델 파일을 로딩하지 않습니다.

이 폴더에서 다음과 같이 동봉 자료만 검사할 수 있습니다.

```sh
python3 -B verify_source_bundle.py --source-root current --overlay-root historical --report my_check.json
python3 -B -m unittest -v test_verify_source_bundle.py
```

첫 명령의 종료 코드 1은 이번 부분 묶음의 누락·불일치가 보고되었다는 뜻입니다. 보고서 저장에 성공했다고 완전한 재현 환경으로 해석하면 안 됩니다. 보고서 이름은 기존 파일과 다르게 지정하세요.

## 남은 작업

미회수 네 소스의 정확한 과거판, 실제 사용한 의존성·설정, 원 시연·모델·초기 상태를 별도 검증해야 합니다. 소스 pin 258개가 모두 일치하더라도 전체 저장소·운영 환경·실험 결과의 재현과 같지는 않습니다. 변경된 현재 파일에서 과거 내용을 추정해 만들지 않았습니다.

이 자료는 검토용 부분 사본입니다. 저자·소속·라이선스·코드 공개 범위는 결정하지 않았으며 외부 공개를 수행하지 않았습니다. 현재 프로젝트 위에 이 사본을 덮어쓰거나, 포함된 로봇 소스를 그대로 실행하지 마세요.
