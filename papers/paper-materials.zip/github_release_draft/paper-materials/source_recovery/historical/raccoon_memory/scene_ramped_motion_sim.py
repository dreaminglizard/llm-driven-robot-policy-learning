"""Opt-in, simulation-only interpolation of arm servo targets.

The policy and the one-second command contract do not change.  This profile
ramps each arm target from the last applied control to the new target, then
holds it for the remainder of the command.  It does not impose a validated
joint velocity, acceleration, collision, or real-device safety limit.
The default ramp is linear; minimum jerk is an explicit alternative.
"""
from __future__ import annotations

import math

import mujoco

from raccoon_control.kinematics import check_joints
from .motion_sim import MAX_OPENING_M, _finite_number
from .scene_motion_sim import SceneMotionSim


class RampedSceneMotionSim(SceneMotionSim):
    """A virtual scene using the same policy with an arm target ramp."""

    def __init__(self, layout, seed=0, randomize=False, *, ramp_seconds=0.05, threshold_degrees=0.0,
                 ramp_shape="linear"):
        self.ramp_seconds = _finite_number(ramp_seconds, "ramp_seconds", minimum=0)
        self.threshold_degrees = _finite_number(threshold_degrees, "threshold_degrees", minimum=0)
        if self.ramp_seconds <= 0:
            raise ValueError("ramp_seconds must be positive")
        if not isinstance(ramp_shape, str) or ramp_shape not in ("linear", "minimum_jerk"):
            raise ValueError("ramp_shape must be 'linear' or 'minimum_jerk'")
        self.ramp_shape = ramp_shape
        super().__init__(layout, seed=seed, randomize=randomize)

    def reset(self, layout=None, seed=None, randomize=None):
        layout = self._reset_info["initial_layout"] if layout is None else layout
        seed = self._reset_info["seed"] if seed is None else seed
        randomize = self._reset_info["randomize"] if randomize is None else randomize
        self.__init__(layout, seed=seed, randomize=randomize, ramp_seconds=self.ramp_seconds,
                      threshold_degrees=self.threshold_degrees, ramp_shape=self.ramp_shape)
        return self.observation()

    def command(self, joints_deg, gripper_opening_m, seconds=0.5):
        if self.layout_status == "uncertain":
            raise RuntimeError("layout is uncertain; explicit reset is required")
        if self.layout_status == "registered":
            self.layout_status = "in_progress"
            self._pending_transfer = None
        try:
            joints = check_joints(joints_deg)
            opening = _finite_number(gripper_opening_m, "gripper_opening_m", minimum=0, maximum=MAX_OPENING_M)
            duration = _finite_number(seconds, "seconds", minimum=0)
            if duration <= 0:
                raise ValueError("seconds must be positive")
            previous = [float(self.data.ctrl[i]) for i in self._arm_actuators]
            check_joints([math.degrees(value) for value in previous])
            target = [math.radians(value) for value in joints]
            difference = max(abs(math.degrees(end - start)) for start, end in zip(previous, target))
            dt = float(self.model.opt.timestep)
            if not math.isfinite(dt) or dt <= 0:
                raise ValueError("invalid physics timestep")
            steps = max(1, math.ceil(duration / dt - 1e-12))
            ramp = min(self.ramp_seconds, duration)
            for actuator in self._finger_actuators:
                self.data.ctrl[actuator] = opening / 2
            for step in range(steps):
                alpha = (min((step + 1) * dt / ramp, 1.0) if difference > self.threshold_degrees else 1.0)
                if self.ramp_shape == "minimum_jerk" and alpha < 1.0:
                    alpha = 10 * alpha**3 - 15 * alpha**4 + 6 * alpha**5
                for actuator, start, end in zip(self._arm_actuators, previous, target):
                    self.data.ctrl[actuator] = end if alpha == 1.0 else start + (end - start) * alpha
                mujoco.mj_step(self.model, self.data)
            mujoco.mj_forward(self.model, self.data)
            return self.observation()
        except Exception as exc:
            self.mark_layout_uncertain(f"simulation_command_error: {type(exc).__name__}: {exc}")
            raise
