# 과거 실험 소스 해시 검증기

이 도구는 지정한 로컬 소스 폴더의 파일을 읽고, 실험 당시 기록된 **258개 SHA-256**과 비교합니다. 원본 파일을 수정·복사·실행하지 않습니다. 프로젝트 import, 모델/pickle 로딩, 압축 해제, 네트워크 호출, 로봇 동작은 없습니다.

## 실행 환경

- Python 3.9 이상, 표준 라이브러리만 사용합니다.
- Linux/macOS 또는 WSL에서 실행합니다. 디렉터리 파일 디스크립터와 `O_NOFOLLOW`를 이용해 심볼릭 링크를 따라가지 않습니다. 이 기능이 없는 네이티브 Windows에서는 안전하게 중단합니다. Windows 파일은 WSL에서 `/mnt/c/...` 등의 로컬 경로로 지정할 수 있습니다.
- 읽는 동안 소스와 overlay를 변경하지 마세요. 각 파일의 읽기 전후 메타데이터를 비교하지만, 여러 파일의 동시점 스냅샷을 생성하는 도구는 아닙니다.

## 기본 사용

ZIP을 풀고 이 README가 있는 폴더에서 실행합니다. `<...>`는 실제 경로로 바꾸세요. 기본 감사 파일은 함께 포함되어 있으므로 상위 원고 폴더가 없어도 실행할 수 있습니다.

```bash
python3 -B verify_source_bundle.py \
  --source-root /absolute/path/to/local/project \
  --report verification_01.json
```

기본 입력은 스크립트 옆의 `code_version_audit.json`입니다. 이 파일은 v0.2 원고의 감사 입력을 바이트 변경 없이 복사한 것입니다. 별도의 감사 파일을 명시하려면 아래처럼 실행하세요.

```bash
python3 -B verify_source_bundle.py \
  --source-root /absolute/path/to/local/project \
  --audit /absolute/path/to/code_version_audit.json \
  --report verification_explicit_audit_01.json
```

감사 파일은 전체 258개 항목을 포함해야 합니다. 이 도구는 `recorded_sha256`만 기준으로 삼으며, 과거 확인 시점의 `observed_sha256`를 정답으로 사용하지 않습니다.

기준 감사 파일의 SHA-256:

```text
347699a8bbb954501cc1841f4918edcc8efe421c2bfac06b53dd120e567674a9
```

보고서의 `audit_sha256`가 이 값이면 제공된 감사 파일과 바이트 단위로 같습니다. 다른 감사 파일을 지정할 수 있지만, 도구가 그 파일의 출처나 역사적 정당성을 인증하지는 않습니다.

## 복구 파일 overlay 사용

복구된 파일은 별도 폴더 안에 원래의 프로젝트 상대 경로로 두세요. 예를 들어 `raccoon_memory/scene_features.py`는 `<overlay>/raccoon_memory/scene_features.py`에 있어야 합니다.

```bash
python3 -B verify_source_bundle.py \
  --source-root /absolute/path/to/local/project \
  --overlay-root /absolute/path/to/recovered/files \
  --report verification_with_overlay_01.json
```

- overlay에 해당 파일이 있으면 그것을 먼저 검증합니다. overlay 파일이 잘못되었거나 접근이 안전하지 않으면 원본으로 몰래 대체하지 않습니다.
- overlay에 해당 경로가 없을 때만 source를 읽습니다.
- 보고서의 각 항목은 `origin`에 `source`, `overlay`, 또는 찾지 못한 경우 `null`을 기록합니다. `attempted_origins`로 시도 순서를 확인할 수 있습니다.
- 복구한 3개 또는 7개만 있어도 검사 대상은 항상 258개입니다. 나머지는 `missing`으로 남습니다. **7개 일치, 251개 누락은 전체 검증 성공이 아닙니다.**
- 원본 251개와 overlay 7개가 모두 일치하면 두 폴더를 합쳐 258개 기록과 일치했다는 뜻입니다. 하나의 완성된 과거 소스 폴더를 만들었다는 뜻은 아닙니다.

## 결과 해석

보고서 JSON에는 다음이 포함됩니다.

- `counts`: `matched`, `missing`, `mismatched`, `error` 수. 네 합은 항상 258입니다.
- `files`: 모든 상대 경로, 기준 해시, 실제 해시, 출처, 상태.
- `complete_recorded_pin_set_verified`: 258개 모두 일치할 때만 `true`.
- `single_source_root_verified`: 258개 모두 source에서 일치할 때만 `true`.
- `full_repository_snapshot_verified`: 항상 `false`. 기록에 없는 파일, 의존성, Git 이력, 데이터, 모델, 실험 결과는 검증하지 않습니다.

종료 코드: `0`은 전체 258개 일치, `1`은 누락/불일치/경로 오류가 있는 보고서 생성 완료, `2`는 잘못된 입력·지원되지 않는 환경·보고서 쓰기 실패입니다. 보고서 생성 자체가 실패하면 전체 검증 성공으로 취급하지 마세요.

이 도구의 기본 감사 입력은 258개 중 251개가 이전 확인 시점에 일치하고 7개가 바뀐 것으로 기록되어 있습니다. 이것은 새 실행 결과가 아닙니다. 복구 파일과 현재 소스를 실제로 지정해 실행하기 전에는 새로운 258개 검증 결과가 없습니다.

### 2026-11-11 실제 부분 검사

`partial_source_verification_20261111.json`은 제공된 current 사본과 historical overlay를 클라우드에서 읽기 전용으로 검사한 결과입니다. **258개 중 3개 일치, 4개 불일치, 251개 미제공, 경로/읽기 오류 0개**입니다. 일치한 3개는 모두 historical overlay에서 읽었으며, 전체 검증 성공 플래그는 모두 `false`입니다. 이 결과는 완성된 역사적 소스 번들이나 실험 재실행 결과가 아닙니다. 사용자 프로젝트의 네이티브 Windows 환경에서는 이 검증기를 지원하지 않습니다.

## 경로와 출력 제한

- 감사 파일의 프로젝트 경로와 `--report`는 정규화된 상대 경로만 받습니다. 절대 경로, `..`, `.`, 빈 경로 조각, 역슬래시, 드라이브/ADS 콜론, 제어 문자, Windows 예약 이름을 거부합니다. `--source-root`, `--overlay-root`, `--audit`에는 로컬 절대 경로를 사용할 수 있습니다.
- source/overlay의 하위 심볼릭 링크는 내부 목적지여도 모두 거부합니다. 일반 파일만 해시하며 FIFO 등 특수 파일은 읽지 않습니다. 직접 지정한 root 자체도 심볼릭 링크이면 거부합니다.
- 보고서는 이 스크립트가 있는 작업 폴더 아래의 `.json` 파일로만 씁니다. 하위 폴더를 쓰려면 미리 만들어 두어야 합니다. 디렉터리를 자동 생성하지 않습니다. 보고서가 source/overlay 안에 들어가거나 감사 입력 자체를 덮어쓰는 경우도 거부합니다.
- 같은 보고서 이름이 이미 있으면 중단합니다. 의도적으로 교체할 때만 `--overwrite`를 추가하세요. 이 옵션도 심볼릭 링크 보고서를 허용하지 않습니다.
- 원본 경로를 보존하는 복사, 아카이브 생성, Git 작업은 하지 않습니다. 보고서에는 소스의 절대 경로를 넣지 않습니다.

## 테스트

```bash
python3 -B -m unittest -v test_verify_source_bundle.py
```

테스트는 임시 폴더의 가상 258개 파일만 사용합니다. 실제 프로젝트 코드나 모델은 실행하지 않습니다. 전체 일치, 누락, 불일치, overlay 우선순위, 부분 복구, 경로 traversal, 심볼릭 링크, FIFO, 덮어쓰기 제한을 검사합니다.

함께 포함된 `test_results.txt`는 이 전달본으로 수행한 17개 테스트의 실행 로그입니다. 실제 부분검사 결과는 위의 별도 JSON 보고서에 있습니다.

저자·라이선스·논문 공개 여부를 판단하는 도구가 아닙니다. 해시 일치는 해당 바이트의 일치를 보여줄 뿐, 실험 재현 성공이나 실행 결과의 진위를 입증하지 않습니다.
