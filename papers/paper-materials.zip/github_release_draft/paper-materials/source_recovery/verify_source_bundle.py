#!/usr/bin/env python3
"""Read-only SHA-256 verification of the 258 historical experiment pins."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import uuid


WORK_DIR = Path(__file__).resolve().parent
DEFAULT_AUDIT = WORK_DIR / "code_version_audit.json"
EXPECTED_COUNT = 258
AUDIT_SCHEMA = "paper-code-version-audit.v1"
SHA256 = re.compile(r"[0-9a-fA-F]{64}\Z")


class VerificationError(ValueError):
    """An unsafe or invalid input; not a source hash mismatch."""


def relative_parts(value):
    """Require canonical, portable project-relative names, never normalize '..'."""
    if not isinstance(value, str) or not value or "\\" in value or ":" in value:
        raise VerificationError("Paths must be nonempty forward-slash relative paths.")
    parts = value.split("/")
    reserved = {"CON", "PRN", "AUX", "NUL"}
    reserved.update("%s%d" % (prefix, n) for prefix in ("COM", "LPT") for n in range(1, 10))
    if any(part in ("", ".", "..") or part.endswith((" ", "."))
           or any(ord(char) < 32 or ord(char) == 127 for char in part)
           or part.split(".")[0].upper() in reserved for part in parts):
        raise VerificationError("Unsafe or noncanonical relative path: %r" % value)
    return tuple(parts)


def require_safe_open_support():
    # Fail closed rather than silently using race-prone path traversal on Windows.
    required = ("O_DIRECTORY", "O_NOFOLLOW", "O_NONBLOCK")
    if any(not hasattr(os, name) for name in required) or any(
            fn not in os.supports_dir_fd for fn in (os.open, os.stat, os.unlink, os.rename)):
        raise VerificationError("Secure directory-relative I/O is unavailable; use Linux/macOS or WSL.")


class LocalRoot:
    """Directory-fd traversal: refuse symlinks at every child component."""

    def __init__(self, path):
        require_safe_open_support()
        requested = Path(path).absolute()
        if requested.is_symlink():
            raise VerificationError("A root must be a real directory, not a symlink.")
        self.path = requested.resolve(strict=True)
        self.fd = os.open(self.path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)

    def __enter__(self):
        return self

    def __exit__(self, *unused):
        os.close(self.fd)

    def parent_fd(self, parts):
        fd = os.dup(self.fd)
        try:
            for name in parts[:-1]:
                next_fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                  dir_fd=fd)
                os.close(fd)
                fd = next_fd
            return fd
        except BaseException:
            os.close(fd)
            raise

    def hash_file(self, parts):
        parent = self.parent_fd(parts)
        try:
            fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
        finally:
            os.close(parent)
        with os.fdopen(fd, "rb") as handle:
            before = os.fstat(handle.fileno())
            if not stat.S_ISREG(before.st_mode):
                raise VerificationError("Not a regular file; no content read.")
            digest = hashlib.sha256()
            while True:
                block = handle.read(1024 * 1024)
                if not block:
                    break
                digest.update(block)
            after = os.fstat(handle.fileno())
            fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
            if any(getattr(before, key) != getattr(after, key) for key in fields):
                raise VerificationError("File changed while hashing; no match claimed.")
            return digest.hexdigest()


def load_audit(path):
    raw = Path(path).read_bytes()
    audit = json.loads(raw)
    if not isinstance(audit, dict) or audit.get("schema") != AUDIT_SCHEMA:
        raise VerificationError("Unsupported audit schema.")
    files = audit.get("files")
    if (not isinstance(files, list) or len(files) != EXPECTED_COUNT
            or type(audit.get("count")) is not int or audit["count"] != EXPECTED_COUNT):
        raise VerificationError("The audit must contain all 258 pins; partial manifests are rejected.")
    pins, seen = [], set()
    for item in files:
        if not isinstance(item, dict):
            raise VerificationError("Each audit entry must be an object.")
        path = item.get("path")
        relative_parts(path)
        if path.casefold() in seen:
            raise VerificationError("Duplicate or case-colliding manifest path: %r" % path)
        seen.add(path.casefold())
        expected = item.get("recorded_sha256")
        if not isinstance(expected, str) or not SHA256.fullmatch(expected):
            raise VerificationError("Invalid recorded SHA-256 for %r" % path)
        pins.append({"path": path, "recorded_sha256": expected.lower()})
    return pins, hashlib.sha256(raw).hexdigest()


def check_bundle(pins, audit_sha256, source, overlay=None):
    if len(pins) != EXPECTED_COUNT:
        raise VerificationError("Verification requires all 258 recorded pins.")
    counts = {name: 0 for name in ("matched", "missing", "mismatched", "error")}
    rows = []
    for pin in pins:
        parts = relative_parts(pin["path"])
        row = {**pin, "actual_sha256": None, "origin": None, "status": "missing"}
        attempts = [("overlay", overlay), ("source", source)] if overlay else [("source", source)]
        row["attempted_origins"] = []
        for origin, root in attempts:
            row["attempted_origins"].append(origin)
            try:
                actual = root.hash_file(parts)
            except FileNotFoundError:
                continue
            except (OSError, VerificationError) as exc:
                row.update(origin=origin, status="error")
                # Avoid disclosing machine-specific absolute paths in OS exceptions.
                row["error"] = ("Unsafe, unreadable, or non-regular path (errno %s)." % exc.errno
                                if isinstance(exc, OSError) else str(exc))
            else:
                row.update(origin=origin, actual_sha256=actual,
                           status="matched" if actual == pin["recorded_sha256"] else "mismatched")
            break  # Explicit overlay wins, even if incorrect or unsafe. Never mask its failure.
        counts[row["status"]] += 1
        rows.append(row)
    complete = counts["matched"] == EXPECTED_COUNT
    overlay_matches = sum(row["origin"] == "overlay" and row["status"] == "matched" for row in rows)
    return {
        "schema": "historical-source-bundle-verification.v1",
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "audit_sha256": audit_sha256,
        "expected_pins": EXPECTED_COUNT,
        "checked_pins": len(rows),
        "counts": counts,
        "overlay_supplied": overlay is not None,
        "matched_from_source": counts["matched"] - overlay_matches,
        "matched_from_overlay": overlay_matches,
        "complete_recorded_pin_set_verified": complete,
        "single_source_root_verified": complete and overlay_matches == 0,
        "full_repository_snapshot_verified": False,
        "scope": "All 258 manifest entries, using recorded_sha256 only. Unlisted files, dependencies, "
                 "history, data, model artifacts, and experiment results are not verified. "
                 "A complete pin set across two roots is not a materialized historical snapshot.",
        "files": rows,
    }


def write_report(report, relative_name, roots, audit_path, overwrite=False):
    parts = relative_parts(relative_name)
    if not parts[-1].endswith(".json"):
        raise VerificationError("Report filename must end in .json.")
    candidate = WORK_DIR.joinpath(*parts)
    for root in roots:
        if candidate.is_relative_to(root.path):
            raise VerificationError("Report destination must not be inside a source or overlay root.")
    if candidate == Path(audit_path).resolve():
        raise VerificationError("Report destination must not overwrite the input audit.")
    with LocalRoot(WORK_DIR) as work:
        parent = work.parent_fd(parts)  # Parent directories must already exist and be nonsymlinks.
        temp_name = None
        try:
            try:
                existing = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
            except FileNotFoundError:
                existing = None
            if existing is not None:
                if not overwrite:
                    raise FileExistsError("Report exists; choose a new name or use --overwrite.")
                if not stat.S_ISREG(existing.st_mode):
                    raise VerificationError("Existing report must be a regular file, never a symlink.")
            payload = (json.dumps(report, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
            if not overwrite:
                fd = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                             0o600, dir_fd=parent)
            else:
                # Atomic replacement does not truncate any other name hard-linked to an old report.
                temp_name = ".verify-report-%s.tmp" % uuid.uuid4().hex
                fd = os.open(temp_name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                             0o600, dir_fd=parent)
            with os.fdopen(fd, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            if temp_name is not None:
                os.rename(temp_name, parts[-1], src_dir_fd=parent, dst_dir_fd=parent)
                temp_name = None
        finally:
            if temp_name is not None:
                os.unlink(temp_name, dir_fd=parent)
            os.close(parent)
    return candidate


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", required=True, help="Existing local project directory; read only.")
    parser.add_argument("--overlay-root", help="Optional historical-file directory with the same relative paths.")
    parser.add_argument("--audit", type=Path, default=DEFAULT_AUDIT, help="Complete 258-entry audit JSON.")
    parser.add_argument("--report", required=True, help="New relative JSON report path under this script's folder.")
    parser.add_argument("--overwrite", action="store_true", help="Explicitly replace an existing report.")
    args = parser.parse_args(argv)
    try:
        relative_parts(args.report)
        pins, audit_sha256 = load_audit(args.audit)
        with LocalRoot(args.source_root) as source:
            if args.overlay_root:
                with LocalRoot(args.overlay_root) as overlay:
                    report = check_bundle(pins, audit_sha256, source, overlay)
                    path = write_report(report, args.report, [source, overlay], args.audit, args.overwrite)
            else:
                report = check_bundle(pins, audit_sha256, source)
                path = write_report(report, args.report, [source], args.audit, args.overwrite)
        counts = report["counts"]
        print("258 pins: matched={matched}, missing={missing}, mismatched={mismatched}, error={error}".format(**counts))
        print("All 258 recorded pins verified: %s" % report["complete_recorded_pin_set_verified"])
        print("Report: %s" % path.relative_to(WORK_DIR))
        return 0 if report["complete_recorded_pin_set_verified"] else 1
    except (OSError, ValueError, TypeError, RecursionError) as exc:
        print("Verification/report failed: %s" % exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
