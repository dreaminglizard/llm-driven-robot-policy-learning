"""Tests of document-scope rules, not tests of any robot or model."""
import copy
import json
import unittest
from check_retarget_scope import ROOT, validate, validate_later


class ScopeTests(unittest.TestCase):
    def setUp(self):
        self.case = json.loads((ROOT / 'docs/retarget_mock_followup_20261112.json').read_text())

    def changed(self, section, key, value):
        record = copy.deepcopy(self.case)
        record[section][key] = value
        self.assertTrue(validate(record))

    def test_valid_snapshot(self):
        self.assertEqual(validate(self.case), [])

    def test_reject_physical_success(self):
        self.changed('reported_fields', 'physical_success', True)

    def test_reject_missing_physical_success(self):
        del self.case['reported_fields']['physical_success']
        self.assertTrue(validate(self.case))

    def test_reject_inflight(self):
        self.changed('reported_fields', 'request_in_flight', True)

    def test_reject_object_physics_claim(self):
        self.changed('reported_fields', 'object_physics_assessed', True)

    def test_reject_expected_as_measured(self):
        self.changed('interpretation', 'expected_scene_is_measured_object_state', True)

    def test_reject_independent_evaluation(self):
        self.changed('interpretation', 'independent_final_evaluation_established', True)

    def test_reject_real_voice_validation(self):
        self.changed('interpretation', 'real_microphone_or_gemma_correction_established', True)

    def test_reject_app_deployment_claim(self):
        self.changed('interpretation', 'deployed_app_completion_established', True)

    def test_reject_command_count_as_trial_count(self):
        self.changed('interpretation', 'record_count', 14)

    def test_reject_source_hash_reverified_claim(self):
        self.changed('source', 'hash_recomputed_by_this_update', True)

    def test_reject_dropped_fourth_slot(self):
        self.changed('reported_fields', 'final_expected_scene', [[1], [2, 3], []])


class LaterScopeTests(unittest.TestCase):
    def setUp(self):
        self.case = json.loads((ROOT / 'docs/inflight_and_memory_mock_followup_20261112.json').read_text())

    def test_valid_later_snapshot(self):
        self.assertEqual(validate_later(self.case), [])

    def test_reject_later_real_success(self):
        self.case['inflight_selected_student']['physical_success'] = True
        self.assertTrue(validate_later(self.case))

    def test_preserve_ideal_mock_advance(self):
        self.case['inflight_selected_student']['scope']['selected_student_inflight_completion_in_ideal_mock'] = False
        self.assertTrue(validate_later(self.case))

    def test_reject_combined_inflight_counts(self):
        self.case['inflight_selected_student']['reported_counts']['applied_command_count'] = 14
        self.assertTrue(validate_later(self.case))

    def test_reject_continuous_AB_claim(self):
        self.case['memory_ab']['one_continuous_AB_session'] = True
        self.assertTrue(validate_later(self.case))

    def test_reject_physical_memory_success(self):
        self.case['memory_ab']['physical_success'] = True
        self.assertTrue(validate_later(self.case))


if __name__ == '__main__':
    unittest.main()
