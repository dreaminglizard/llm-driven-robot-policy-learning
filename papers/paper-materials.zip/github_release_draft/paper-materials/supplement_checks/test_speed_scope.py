"""Tests of reporting rules only, not robot or model regression tests."""
import copy
import json
import unittest
from check_speed_scope import ROOT, validate, check_units


class SpeedScopeTests(unittest.TestCase):
    def setUp(self):
        self.record = json.loads((ROOT/'docs/speed_and_integration_scope_20261112.json').read_text())

    def changed(self, section, key, value):
        r = copy.deepcopy(self.record)
        r[section][key] = value
        self.assertTrue(validate(r))

    def test_valid_report(self): self.assertEqual(validate(self.record), [])
    def test_units(self): self.assertTrue(all(check_units().values()))
    def test_no_new_measured_speed(self): self.changed('speed_plan','new_physical_time_measured',True)
    def test_no_wrong_physical_denominator(self): self.changed('speed_plan','planned_path_seconds_before',147.250623)
    def test_no_invented_slip(self): self.changed('speed_plan','observed_slippage_from_speed_increase',True)
    def test_no_unmeasured_no_slip_claim(self): self.changed('speed_plan','observed_slippage_from_speed_increase',False)
    def test_no_all_twelve_completed(self): self.changed('speed_mock','completed_move_commands',12)
    def test_no_mock_physical_success(self): self.changed('speed_mock','physical_success',True)
    def test_no_audio_physical_success(self): self.changed('audio_integration','physical_success',True)
    def test_no_real_gemma_accuracy(self): self.changed('audio_integration','real_asr_or_gemma_quality_evaluated',True)
    def test_no_voice_latency(self): self.changed('audio_integration','reported_test_runtime_is_end_to_end_voice_latency',True)
    def test_no_four_independent_tests(self): self.changed('audio_integration','reported_tests_total',4)
    def test_no_original_bytes_rehash_claim(self): self.changed('provenance','source_hashes_recomputed_in_this_update',True)


if __name__ == '__main__': unittest.main()
