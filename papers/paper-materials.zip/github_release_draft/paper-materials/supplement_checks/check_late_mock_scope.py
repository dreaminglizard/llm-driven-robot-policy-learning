"""Check normalized document claims only; no experiment or device interface."""
from pathlib import Path
import json
import re
ROOT = Path(__file__).resolve().parents[1]

def validate(d):
    errors=[]
    def check(ok,msg):
        if not ok: errors.append(msg)
    check(d.get('schema')=='late-mock-integration-report.v1','schema')
    p=d.get('provenance',{})
    for k in ('original_bytes_included','source_hashes_recomputed_in_this_update','new_experiment_performed'):
        check(p.get(k) is False,k)
    r=d.get('retarget_integration',{})
    check(r.get('reported_tests_passed')==r.get('reported_tests_total')==1,'one reported regression')
    check(r.get('synthetic_waveforms')==2 and r.get('gemma_responses_fixed') is True,'synthetic inputs and fixed Gemma')
    check(r.get('selected_student_seed')==20261030,'selected student')
    check(r.get('memory_model_loaded') is True and r.get('memory_inference_exercised') is False,'loaded memory model, no memory inference')
    check(r.get('expected_scene_updates')==1 and r.get('fake_stop_resume') is True,'fake response and expected update')
    check(r.get('followup_voice_injected_after_prompt_end') is True,'non-overlap prompt timing')
    for k in ('real_model_audio_interpretation_verified','real_microphone_verified','object_physics_verified','real_sdk_verified','overlapping_barge_in_evaluated','independent_generalization'):
        check(r.get(k) is False,k)
    f=d.get('forecast',{})
    for k,v in {'poll_interval_ms':25,'first_conditional_segment_computed_seconds':0.2800,'first_conditional_segment_state_observed_seconds':0.2899,'seven_segments_computed_seconds':0.473,'seven_segments_state_observed_seconds':0.4955,'conditional_segments':7,'fake_attempt_count':1,'real_attempt_count':0}.items():
        check(f.get(k)==v,k)
    check(f.get('single_cylinder_transfer_only') is True,'one transfer forecast')
    check(f.get('execution_status')=='uncertain' and f.get('intentional_cancellation') is True,'canceled uncertain outcome')
    for k in ('whole_program_forecast','actual_screen_render_latency_measured','object_accuracy_measured','physical_speed_measured'):
        check(f.get(k) is False,k)
    for x,k in ((r,'reported_source_sha256'),(f,'reported_sha256')):
        check(bool(re.fullmatch(r'[0-9a-f]{64}',x.get(k,''))),'reported source hash format')
    check(d.get('new_physical_or_real_gemma_quality_result') is False,'no new real performance')
    check(d.get('not_merged_into_success_rates') is True and d.get('main_paper_and_irc_unchanged') is True,'separate supplementary evidence')
    return errors

if __name__=='__main__':
    errors=validate(json.loads((ROOT/'docs/late_mock_integration_20261112.json').read_text()))
    print(json.dumps({'passed':not errors,'errors':errors,'scope':'Normalized reporting snapshot only','new_experiments':0},indent=2))
    raise SystemExit(bool(errors))
