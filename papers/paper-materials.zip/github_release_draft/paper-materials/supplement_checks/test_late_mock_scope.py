import copy,json,unittest
from check_late_mock_scope import ROOT,validate
class LateScopeTests(unittest.TestCase):
    def setUp(self): self.d=json.loads((ROOT/'docs/late_mock_integration_20261112.json').read_text())
    def changed(self,section,key,value):
        d=copy.deepcopy(self.d);d[section][key]=value;self.assertTrue(validate(d))
    def test_valid(self): self.assertEqual(validate(self.d),[])
    def test_no_memory_inference(self): self.changed('retarget_integration','memory_inference_exercised',True)
    def test_no_barge_in_result(self): self.changed('retarget_integration','overlapping_barge_in_evaluated',True)
    def test_no_real_sdk(self): self.changed('retarget_integration','real_sdk_verified',True)
    def test_no_real_audio_quality(self): self.changed('retarget_integration','real_model_audio_interpretation_verified',True)
    def test_no_measured_screen_latency(self): self.changed('forecast','actual_screen_render_latency_measured',True)
    def test_no_completed_forecast_episode(self): self.changed('forecast','execution_status','completed')
    def test_no_whole_program(self): self.changed('forecast','whole_program_forecast',True)
if __name__=='__main__':unittest.main()
