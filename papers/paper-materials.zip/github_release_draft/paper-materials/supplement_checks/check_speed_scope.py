"""Document-snapshot consistency only. No device/model/simulator/network access."""
from pathlib import Path
import json
import math
import re

ROOT = Path(__file__).resolve().parents[1]


def validate(record):
    errors = []
    def require(ok, message):
        if not ok:
            errors.append(message)
    require(record.get('schema') == 'speed-and-integration-reporting-scope.v1', 'schema')
    p = record.get('provenance', {})
    for key in ('original_bytes_included', 'source_hashes_recomputed_in_this_update',
                'new_robot_model_or_voice_experiment'):
        require(p.get(key) is False, key)
    s = record.get('speed_plan', {})
    before, after = s.get('planned_path_seconds_before'), s.get('planned_path_seconds_after')
    require(before == 77.2 and after == 69.18, 'same seven-path plan times')
    require(s.get('same_saved_paths') == 7, 'seven paths, not seven trials')
    require(s.get('planned_seconds_saved') == 8.02, 'planned delta')
    if isinstance(before, (int, float)) and isinstance(after, (int, float)) and before > 0:
        require(math.isclose(before-after, s.get('planned_seconds_saved', -1), abs_tol=1e-9), 'delta arithmetic')
        require(round(100*(before-after)/before, 1) == s.get('planned_reduction_percent_rounded'), 'rounded plan-only percentage')
    require(s.get('historical_physical_episode_seconds_excluding_voice') == 147.250623, 'historical episode duration separate')
    require(s.get('speed_percent_before') == 25 and s.get('speed_percent_after') == 30, 'historical speed settings')
    require(s.get('continuous_limit_deg_s_before') == 12 and s.get('continuous_limit_deg_s_after') == 14.4, 'historical continuous limits')
    for key in ('new_physical_time_measured', 'new_tracking_or_object_success_assessed', 'slippage_assessed'):
        require(s.get(key) is False, key)
    require('observed_slippage_from_speed_increase' in s and s['observed_slippage_from_speed_increase'] is None, 'slippage remains unmeasured')
    m = record.get('speed_mock', {})
    require(m.get('move_commands') == 12 and m.get('completed_move_commands') == 11 and m.get('interrupted_move_commands') == 1, '12 MOVE commands with 11 complete / 1 interrupted')
    require(m.get('close_commands') == m.get('open_commands') == 1, 'separate gripper commands')
    require(m.get('all_move_speed_percent') == 30 and m.get('all_move_continuous_limit_deg_s') == 14.4, 'mock applied speed settings')
    require(m.get('quantized_endpoints_match') is True, 'reported nominal endpoints')
    require('physical_success' in m and m['physical_success'] is None, 'mock physical result null')
    require(m.get('new_independent_evaluation') is False, 'not independent evaluation')
    a = record.get('audio_integration', {})
    require(a.get('existing_korean_tts_inputs') == 4, 'four existing synthetic inputs')
    require(a.get('gemma_responses_fixed') is True, 'Gemma test double')
    require(a.get('reported_tests_passed') == a.get('reported_tests_total') == 1, 'one integration regression, not four trials')
    require(a.get('reported_test_runtime_seconds') == 16.899, 'reported whole-test runtime')
    for key in ('reported_test_runtime_is_end_to_end_voice_latency', 'real_asr_or_gemma_quality_evaluated', 'microphone_evaluated'):
        require(a.get(key) is False, key)
    require(a.get('expected_scene_only') is True, 'expected-only scene')
    require('physical_success' in a and a['physical_success'] is None, 'integration physical result null')
    for source, key in ((s, 'reported_sha256'), (m, 'reported_sha256'), (m, 'fixture_reported_sha256'), (a, 'reported_source_sha256')):
        require(bool(re.fullmatch(r'[0-9a-f]{64}', source.get(key, ''))), 'reported hash format')
    for key in ('not_merged_into_existing_quantitative_results', 'irc_15_slide_delivery_unchanged', 'paper_v06_main_files_unchanged'):
        require(record.get(key) is True, key)
    return errors


def check_units():
    d = json.loads((ROOT/'analysis_reproduction/inputs/three_seed_verification.sanitized.json').read_text())
    r = d['seed_results']['20261030']
    checks = {
        'forward_episode_count_1000': d['actual_forward_transfers'] == 1000,
        'reverse_derived_episode_count_770': d['actual_reverse_success_transfers'] == 770,
        'fixed_program_success_252': r['before_vs_after_fixed252']['after']['programs']['unique252']['success'] == 252,
        'fixed_move_success_270': r['before_vs_after_fixed252']['after']['moves']['success'] == 270,
        'close24_after_programs': sum(r['before_vs_after_close24']['after']['program'].values()) == 24,
        'close24_after_moves': sum(r['before_vs_after_close24']['after']['moves'].values()) == 144,
        'factor24_after_programs': sum(r['before_vs_after_mass_pad24']['after']['program'].values()) == 24,
        'factor24_after_moves': sum(r['before_vs_after_mass_pad24']['after']['moves'].values()) == 180,
    }
    return checks


if __name__ == '__main__':
    record = json.loads((ROOT/'docs/speed_and_integration_scope_20261112.json').read_text())
    errors, units = validate(record), check_units()
    result = {'scope': 'Document snapshot consistency, not original experiment revalidation.',
              'passed': not errors and all(units.values()), 'errors': errors,
              'units': units, 'new_experiments': 0}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(not result['passed'])
