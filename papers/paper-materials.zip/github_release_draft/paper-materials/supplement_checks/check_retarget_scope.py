"""Read-only checks of normalized reporting facts, not raw experiment verification.

Standard library only. No imports from robot/model code and no device, network,
subprocess, simulator, or microphone access. Results describe the supplied
document snapshot only, not the current product.
"""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]


def validate(record):
    """Reject scope inflation and malformed facts in this particular supplement."""
    errors = []
    def require(condition, message):
        if not condition:
            errors.append(message)

    require(record.get('schema') == 'selected-student-retarget-mock-evidence.v1', 'schema')
    source = record.get('source', {})
    require(bool(re.fullmatch(r'[0-9a-f]{64}', source.get('reported_sha256', ''))), 'reported hash format')
    require(source.get('original_bytes_included') is False, 'original bytes not bundled')
    require(source.get('hash_recomputed_by_this_update') is False, 'source hash was reported, not recomputed here')
    f = record.get('reported_fields', {})
    require(f.get('request_in_flight') is False, 'between-command case, not in-flight')
    require(f.get('applied_command_count') == 14, '14 commands, not 14 trials')
    require(f.get('execution_status') == 'retargeted_expected', 'expected execution status')
    require(f.get('retarget_status') == 'completed_expected', 'expected completion status')
    require(f.get('model_done') is True and f.get('end_confirmed') is True, 'mock model end fields')
    require(f.get('object_physics_assessed') is False, 'object physics not assessed')
    require('physical_success' in f and f['physical_success'] is None, 'physical success stays null')
    require(f.get('final_expected_scene') == [[1], [2, 3], [], [4]], 'all four expected slots')
    scope = record.get('interpretation', {})
    require(scope.get('fixture') == 'ideal joint-response mock', 'ideal joint fixture')
    require(scope.get('record_count') == 1, 'one saved development case')
    for key in ('expected_scene_is_measured_object_state', 'independent_final_evaluation_established',
                'selected_student_in_flight_preemption_established', 'real_hardware_success_established',
                'real_microphone_or_gemma_correction_established', 'deployed_app_completion_established'):
        require(scope.get(key) is False, key)
    require(record.get('new_experiment_performed') is False, 'document work performed no new experiment')
    require(record.get('not_merged_into_table4_or_physical_case') is True, 'separate evidence units')
    return errors


def validate_later(record):
    """Check the later ideal-mock claims separately from the earlier case."""
    errors = []
    def require(condition, message):
        if not condition:
            errors.append(message)
    require(record.get('schema') == 'selected-student-inflight-memory-mock-evidence.v1', 'later schema')
    f = record.get('inflight_selected_student', {})
    require(f.get('reported_status_transition') == ['queued_after_interrupt', 'completed_expected'], 'inflight mock status')
    c = f.get('reported_counts', {})
    require(c.get('applied_command_count') == 13 and c.get('interrupted_command_count') == 1, 'separate 13 applied / 1 interrupted')
    require(c.get('close_commands') == c.get('open_commands') == 1 and c.get('corrections') == 0, 'gripper and correction counts')
    require(f.get('object_physics_assessed') is False and 'physical_success' in f and f['physical_success'] is None, 'inflight physical outcome not established')
    require(f.get('final_expected_scene') == [[1], [2, 3], [], [4]], 'inflight expected slots')
    scope = f.get('scope', {})
    require(scope.get('selected_student_inflight_completion_in_ideal_mock') is True, 'later ideal-mock advance acknowledged')
    for k in ('real_hardware_inflight_completion_established', 'real_voice_input_established', 'independent_generalization_established'):
        require(scope.get(k) is False, k)
    m = record.get('memory_ab', {})
    require(m.get('reported_test_count') == 1 and m.get('reported_branch_count') == 2, 'one test with two branches')
    require(m.get('independent_sessions_between_branches') is True and m.get('one_continuous_AB_session') is False, 'separate A/B sessions')
    require(m.get('common_expected_scene_before_recall') == [[1], [2], [3], [4]], 'common expected scene')
    require(m.get('recall_source') == 'decoded_gru_hidden_state', 'GRU recall source')
    require(m.get('expected_only') is True and 'physical_success' in m and m['physical_success'] is None, 'memory expected-only scope')
    require(m.get('voice_test') is False and m.get('new_generalization_test') is False, 'memory not voice/generalization trial')
    branches = m.get('branches', [])
    require([x.get('student_commands_by_stage') for x in branches] == [[8, 10, 8], [9, 9, 10]], 'separate branch stage counts')
    require([x.get('remembered_expected_scene') for x in branches] == [[[], [2], [3, 1], [4]], [[1, 3], [2], [], [4]]], 'distinct remembered scenes')
    require(record.get('original_bytes_included') is False and record.get('source_hashes_recomputed_by_this_update') is False, 'reported rather than independently retrieved sources')
    require(record.get('new_experiment_performed') is False, 'no new document-work experiment')
    return errors


def run():
    record = json.loads((ROOT / 'docs/retarget_mock_followup_20261112.json').read_text())
    errors = validate(record)
    later = json.loads((ROOT / 'docs/inflight_and_memory_mock_followup_20261112.json').read_text())
    errors += validate_later(later)
    recorded = json.loads((ROOT / 'docs/recorded_audio_product_mock_20261112.json').read_text())
    physical = json.loads((ROOT / 'docs/physical_user_confirmed_case_20261112.json').read_text())
    # These are distinct saved records, not one concatenated trajectory.
    counts = {
        'recorded_audio_mock_commands': recorded['reported_fields']['controller_commands'],
        'physical_sdk_commands': physical['episode']['command_counts']['results'],
        'between_command_retarget_mock_commands': record['reported_fields']['applied_command_count'],
        'inflight_retarget_mock_applied_commands': later['inflight_selected_student']['reported_counts']['applied_command_count'],
    }
    if list(counts.values()) != [9, 10, 14, 13]:
        errors.append('distinct command counts must stay 9 / 10 / 14 / 13')
    print(json.dumps({'scope': 'Normalized reporting facts only; no original log/model/device validation.',
                      'passed': not errors, 'errors': errors, 'distinct_command_counts': counts,
                      'counts_are_not_success_rates': True,
                      'new_experiment_performed': False}, ensure_ascii=False, indent=2))
    return bool(errors)


if __name__ == '__main__':
    raise SystemExit(run())
