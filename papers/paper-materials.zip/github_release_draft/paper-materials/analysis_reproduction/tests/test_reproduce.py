import ast
import copy
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import reproduce as r


class ReportingTests(unittest.TestCase):
    def setUp(self):
        self.summary = r.load_json(r.ROOT / "inputs/results.json")
        self.manifest = r.load_json(r.ROOT / "inputs/sources.json")
        self.rl = r.load_json(r.ROOT / "inputs/rl_evidence.json")
        self.temp = tempfile.TemporaryDirectory(prefix="test_", dir=r.ROOT)
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)

    def invalid(self, change):
        change(self.summary)
        with self.assertRaises(r.ValidationError):
            r.validate_summary(self.summary)

    def test_snapshot_schema_and_counts(self):
        r.validate_summary(self.summary)
        r.validate_manifest(self.manifest, self.summary)
        self.assertEqual(len(r.table4_records(self.summary)), 18)

    def test_malformed_json(self):
        path = self.directory / "bad.json"
        path.write_text('{"broken":', encoding="utf-8")
        with self.assertRaises(r.ValidationError):
            r.load_json(path)

    def test_duplicate_keys_rejected(self):
        path = self.directory / "bad.json"
        path.write_text('{"success":1,"success":2}', encoding="utf-8")
        with self.assertRaises(r.ValidationError):
            r.load_json(path)

    def test_nonfinite_json_rejected(self):
        path = self.directory / "bad.json"
        path.write_text('{"success":NaN}', encoding="utf-8")
        with self.assertRaises(r.ValidationError):
            r.load_json(path)

    def test_wrong_schema(self):
        self.invalid(lambda s: s.update(schema="raw-simulator-data"))

    def test_negative_success(self):
        self.invalid(lambda s: s["table4"]["rows"][0]["fixed252"].__setitem__(0, -1))

    def test_success_exceeds_denominator(self):
        self.invalid(lambda s: s["table4"]["rows"][0]["fixed252"].__setitem__(0, 253))

    def test_invalid_denominator(self):
        self.invalid(lambda s: s["table4"]["cohorts"]["close24"].update(denominator=144))

    def test_zero_denominator(self):
        self.invalid(lambda s: s["table4"]["cohorts"]["close24"].update(denominator=0))

    def test_bool_not_integer(self):
        self.invalid(lambda s: s["table4"]["rows"][0]["fixed252"].__setitem__(0, True))

    def test_float_not_integer(self):
        self.invalid(lambda s: s["table4"]["rows"][0]["fixed252"].__setitem__(0, 251.0))

    def test_physical_seed_not_policy_seed(self):
        self.invalid(lambda s: s["table4"]["rows"][0].update(policy_initialization_seed=1500))

    def test_ambiguous_seed_field_rejected(self):
        self.invalid(lambda s: s["table4"]["rows"][0].update(seed=20261101))

    def test_duplicate_policy_seed(self):
        self.invalid(lambda s: s["table4"]["rows"][1].update(policy_initialization_seed=20261101))

    def test_selected_policy_seed_not_rl_seed(self):
        self.invalid(lambda s: s["rl_comparison"].update(policy_initialization_seed=20261030))

    def test_hardware_claim_rejected(self):
        self.invalid(lambda s: s["table4"].update(real_hardware=True))

    def test_holdout_claim_rejected(self):
        self.invalid(lambda s: s["table4"].update(sealed_holdout=True))

    def test_missing_interpretation_limits(self):
        self.invalid(lambda s: s["table4"].update(caveats=[]))

    def test_missing_provenance(self):
        del self.manifest["three_seed_development"]
        with self.assertRaises(r.ValidationError):
            r.validate_manifest(self.manifest, self.summary)

    def test_historical_recovery_reference_is_metadata_only(self):
        self.manifest["historical_source_recovery"]["source"] = "absent/recovery_manifest.json"
        with patch.object(Path, "open", side_effect=AssertionError("metadata must not open files")):
            r.validate_manifest(self.manifest, self.summary)
        del self.manifest["historical_source_recovery"]
        r.validate_manifest(self.manifest, self.summary)

    def test_historical_recovery_invalid_number_types_rejected(self):
        for name in ("historical_files_recovered", "historical_files_unrecovered_in_checked_scope",
                     "candidate_files_checked", "zip_archives_checked"):
            for value in (True, 3.0, -1, "3", None):
                with self.subTest(name=name, value=value):
                    manifest = copy.deepcopy(self.manifest)
                    manifest["historical_source_recovery"][name] = value
                    with self.assertRaises(r.ValidationError):
                        r.validate_manifest(manifest, self.summary)
        for name in ("matched", "mismatched", "missing_from_bundle"):
            for value in (False, 3.0, -1, "3", None, 259):
                with self.subTest(name=name, value=value):
                    manifest = copy.deepcopy(self.manifest)
                    manifest["historical_source_recovery"]["partial_bundle_check"][name] = value
                    with self.assertRaises(r.ValidationError):
                        r.validate_manifest(manifest, self.summary)

    def test_historical_recovery_inconsistent_counts_rejected(self):
        changes = [
            {"historical_files_recovered": 4},
            {"historical_files_unrecovered_in_checked_scope": 3},
            {"candidate_files_checked": 6},
            {"partial_bundle_check": {"matched": 3, "mismatched": 4, "missing_from_bundle": 250}},
            {"partial_bundle_check": {"matched": 4, "mismatched": 3, "missing_from_bundle": 251}},
        ]
        for change in changes:
            with self.subTest(change=change):
                manifest = copy.deepcopy(self.manifest)
                manifest["historical_source_recovery"].update(change)
                with self.assertRaises(r.ValidationError):
                    r.validate_manifest(manifest, self.summary)

    def test_historical_recovery_unsafe_paths_rejected(self):
        for path in ("", "/absolute.json", "../outside.json", "x/../outside.json", "./file.json",
                     "x//file.json", "x/./file.json", "x/", "C:/file.json", "x\\file.json",
                     "x/line\nfile.json", "x/\x7ffile.json", None, 123):
            with self.subTest(path=path):
                manifest = copy.deepcopy(self.manifest)
                manifest["historical_source_recovery"]["source"] = path
                with self.assertRaises(r.ValidationError):
                    r.validate_manifest(manifest, self.summary)

    def test_historical_recovery_malformed_metadata_rejected(self):
        changes = [
            {"source_assignment_sha256": "not-a-hash"},
            {"scope": ""},
            {"scope": False},
            {"partial_bundle_check": []},
            {"partial_bundle_check": {"matched": 3, "mismatched": 4}},
            {"unexpected_field": True},
        ]
        for change in changes:
            with self.subTest(change=change):
                manifest = copy.deepcopy(self.manifest)
                manifest["historical_source_recovery"].update(change)
                with self.assertRaises(r.ValidationError):
                    r.validate_manifest(manifest, self.summary)
        for value in (None, [], "historical"):
            with self.subTest(value=value):
                manifest = copy.deepcopy(self.manifest)
                manifest["historical_source_recovery"] = value
                with self.assertRaises(r.ValidationError):
                    r.validate_manifest(manifest, self.summary)

    def test_historical_recovery_metadata_not_promoted_to_byte_verification(self):
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(r.main(["--output", str(self.directory / "recovery_metadata")]), 0)
        report = r.load_json(self.directory / "recovery_metadata/provenance.json")
        self.assertEqual(report["checks"]["historical_source_recovery_reference_metadata"],
                         "syntax_and_internal_counts_checked_only; not_a_new_source_bundle_check")
        self.assertTrue(all(item["status"] == "not_supplied_not_verified"
                            for item in report["original_source_verification"].values()))
        self.assertFalse(report["all_original_sources_hash_verified"])
        self.assertFalse(report["new_runs_performed"])
        self.assertFalse(report["independent_validation_performed"])

    def test_missing_provenance_hash(self):
        del self.manifest["selected_checkpoint"]["sha256"]
        with self.assertRaises(r.ValidationError):
            r.validate_manifest(self.manifest, self.summary)

    def test_provenance_path_traversal(self):
        self.manifest["selected_checkpoint"]["path"] = "../seed_20261030/candidate.pt"
        with self.assertRaises(r.ValidationError):
            r.validate_manifest(self.manifest, self.summary)

    def test_rl_parent_not_selected_checkpoint(self):
        self.manifest["rl_comparison"]["starting_checkpoint_sha256"] = self.manifest["selected_checkpoint"]["sha256"]
        with self.assertRaises(r.ValidationError):
            r.validate_manifest(self.manifest, self.summary)

    def test_exact_manuscript_table(self):
        result = r.check_manuscript((r.ROOT / "inputs/manuscript.md").read_text(), self.summary)
        self.assertEqual(result["status"], "exact_markdown_table_match")

    def test_manuscript_count_mismatch(self):
        text = (r.ROOT / "inputs/manuscript.md").read_text().replace("251 → 251", "251 → 250")
        with self.assertRaises(r.ValidationError):
            r.check_manuscript(text, self.summary)

    def test_curated_extract_is_not_raw_data(self):
        result = r.check_result_extract((r.ROOT / "inputs/result_evidence.txt").read_text(), self.summary)
        self.assertTrue(result["not_raw_trial_data"])
        self.assertTrue(result["absent_status_fields_not_presented_as_explicit_observations"])

    def test_malformed_curated_extract(self):
        with self.assertRaises(r.ValidationError):
            r.check_result_extract('{"seed":', self.summary)

    def test_negative_failure_count_rejected(self):
        self.rl["arms"]["bc"]["failure"] = -1
        with self.assertRaises(r.ValidationError):
            r.check_rl_extract(self.rl, self.summary, self.manifest)

    def test_rl_failure_denominator_consistency(self):
        self.rl["arms"]["bc"]["failure"] = 5
        with self.assertRaises(r.ValidationError):
            r.check_rl_extract(self.rl, self.summary, self.manifest)

    def test_rl_extracted_parent_hash(self):
        self.rl["bindings"]["start"]["sha256"] = "0" * 64
        with self.assertRaises(r.ValidationError):
            r.check_rl_extract(self.rl, self.summary, self.manifest)

    def test_cross_cohort_aggregation_avoided(self):
        records = r.table4_records(self.summary)
        self.assertEqual({x["cohort"] for x in records}, {"fixed252", "close24", "factor24"})
        self.assertEqual(len(records), 18)
        self.assertNotIn(300, {x["denominator"] for x in records})
        self.assertFalse(any("total" in key or "pooled" in key for row in records for key in row))
        self.assertEqual(len(r.rl_records(self.summary, self.rl, self.manifest)), 3)

    def test_missing_original_sources_remain_unverified(self):
        report = r.verify_sources(r.source_targets(self.manifest, self.rl), {})
        self.assertTrue(all(item["status"] == "not_supplied_not_verified" for item in report.values()))
        self.assertTrue(all(item["historical_hash_checked_flag_reused"] is False for item in report.values()))

    def test_missing_file_is_not_hash_match(self):
        report = r.verify_sources(r.source_targets(self.manifest, self.rl), {"selected_checkpoint": self.directory / "absent.pt"})
        self.assertEqual(report["selected_checkpoint"]["status"], "supplied_file_missing_not_verified")

    def test_hash_mismatch(self):
        path = self.directory / "wrong.bin"
        path.write_bytes(b"not a model; only byte hashing")
        report = r.verify_sources(r.source_targets(self.manifest, self.rl), {"selected_checkpoint": path})
        self.assertEqual(report["selected_checkpoint"]["status"], "hash_mismatch")

    def test_hash_match_with_known_fixture(self):
        path = self.directory / "known.bin"
        path.write_bytes(b"known")
        target = {"known": {"expected_sha256": r.sha256_file(path), "declared_source_path": "known.bin"}}
        self.assertEqual(r.verify_sources(target, {"known": path})["known"]["status"], "hash_match")

    def test_rl_starting_hash_not_summary_hash(self):
        path = self.directory / "summary.json"
        path.write_text("{}")
        report = r.verify_sources(r.source_targets(self.manifest, self.rl), {"rl_comparison": path})
        self.assertEqual(report["rl_comparison"]["status"], "no_expected_hash_not_verified")
        self.assertIsNone(report["rl_comparison"]["expected_sha256"])

    def test_original_pointer_mapping_partial_is_honest(self):
        path = self.directory / "original.json"
        path.write_text('{"count":251}')
        config = {"schema": "explicit-original-json-bindings.v1", "sources": [
            {"source_id": "rl_comparison", "file": "original.json", "bindings": [
                {"source_pointer": "/count", "summary_pointer": "/rl_comparison/success/start"}]}]}
        report = r.compare_original_bindings(config, self.directory / "map.json", self.summary, r.source_targets(self.manifest, self.rl))
        self.assertFalse(report["all_count_and_seed_fields_mapped"])
        self.assertTrue(report["unmapped_expected_fields"])
        self.assertFalse(report["independent_validation"])
        self.assertEqual(report["sources"][0]["comparisons"][0]["status"], "match")

    def test_pointer_missing_field(self):
        with self.assertRaises(r.ValidationError):
            r.json_pointer({}, "/guessed/source/schema")

    def test_pointer_rejects_negative_index(self):
        with self.assertRaises(r.ValidationError):
            r.json_pointer([1], "/-1")

    def test_pointer_escape(self):
        self.assertEqual(r.json_pointer({"a/b": {"~": 7}}, "/a~1b/~0"), 7)

    def test_output_cannot_leave_supplement(self):
        with self.assertRaises(r.ValidationError):
            r.output_dir("../outside")

    def test_output_cannot_overwrite_inputs(self):
        with self.assertRaises(r.ValidationError):
            r.output_dir("inputs")

    def test_output_symlink_rejected(self):
        target = self.directory / "original.txt"
        target.write_text("untouched")
        output = self.directory / "output"
        output.mkdir()
        (output / "table4.md").symlink_to(target)
        with self.assertRaises(r.ValidationError):
            r.write_outputs(output, {"table4.md": "changed"})
        self.assertEqual(target.read_text(), "untouched")

    def test_default_import_surface_is_stdlib_and_offline(self):
        parsed = ast.parse((r.ROOT / "reproduce.py").read_text())
        allowed = {"argparse", "csv", "hashlib", "io", "json", "re", "sys", "pathlib"}
        imports = set()
        for node in ast.walk(parsed):
            if isinstance(node, ast.Import):
                imports.update(x.name for x in node.names)
            if isinstance(node, ast.ImportFrom):
                imports.add(node.module)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                self.assertNotIn(node.func.id, {"exec", "eval", "__import__", "compile"})
        self.assertLessEqual(imports, allowed)

    def test_default_end_to_end_and_determinism(self):
        argv = ["--output", str(self.directory / "generated")]
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(r.main(argv), 0)
            first = {p.name: p.read_bytes() for p in (self.directory / "generated").iterdir()}
            self.assertEqual(r.main(argv), 0)
            second = {p.name: p.read_bytes() for p in (self.directory / "generated").iterdir()}
        self.assertEqual(first, second)
        report = json.loads(first["provenance.json"])
        self.assertFalse(report["all_original_sources_hash_verified"])
        self.assertFalse(report["new_runs_performed"])
        self.assertFalse(report["independent_validation_performed"])
        self.assertEqual(report["three_seed_saved_aggregate_comparison"]["status"], "not_supplied_not_checked")

    def test_hash_mismatch_exit_code_and_report(self):
        path = self.directory / "not_original.json"
        path.write_text("{}")
        with contextlib.redirect_stdout(io.StringIO()):
            code = r.main(["--output", str(self.directory / "failed"), "--source-root", str(self.directory), "--verify-file", "three_seed_development=not_original.json"])
        self.assertEqual(code, 2)
        report = r.load_json(self.directory / "failed/provenance.json")
        self.assertEqual(report["validation_status"], "failed_source_comparison")

    def test_source_root_absolute_reference_rejected(self):
        with self.assertRaises(r.ValidationError):
            r.resolve_under_root(self.directory, "/etc/passwd")

    def test_source_root_parent_traversal_rejected(self):
        with self.assertRaises(r.ValidationError):
            r.resolve_under_root(self.directory, "../outside.json")

    def test_source_root_symlink_escape_rejected(self):
        (self.directory / "outside").symlink_to(r.ROOT)
        with self.assertRaises(r.ValidationError):
            r.resolve_under_root(self.directory, "outside/inputs/results.json")

    def test_three_seed_derivative_counts_and_reuse(self):
        original = r.load_json(r.ROOT / "inputs/three_seed_verification.sanitized.json")
        report = r.check_three_seed_json(original, self.summary, self.manifest)
        self.assertEqual(len(report["matched_fields"]), 18)
        self.assertEqual(report["new_replica_fits"], 2)
        self.assertTrue(report["exact_primary_reuse"])
        self.assertFalse(report["seed20261101_replica_result_json_assumed"])

    def test_three_seed_wrong_program_unit_rejected(self):
        original = r.load_json(r.ROOT / "inputs/three_seed_verification.sanitized.json")
        original["seed_results"]["20261101"]["before_vs_after_fixed252"]["before"]["programs"]["unique252"]["success"] = 269
        with self.assertRaises(r.ValidationError):
            r.check_three_seed_json(original, self.summary, self.manifest)

    def test_three_seed_three_new_fits_claim_rejected(self):
        original = r.load_json(r.ROOT / "inputs/three_seed_verification.sanitized.json")
        original["new_replica_fits"] = 3
        with self.assertRaises(r.ValidationError):
            r.check_three_seed_json(original, self.summary, self.manifest)

    def test_sanitized_derivative_never_hash_verifies_original(self):
        with contextlib.redirect_stdout(io.StringIO()):
            code = r.main(["--output", str(self.directory / "derivative"), "--three-seed-json",
                           str(r.ROOT / "inputs/three_seed_verification.sanitized.json"), "--three-seed-kind", "sanitized_derivative"])
        self.assertEqual(code, 0)
        report = r.load_json(self.directory / "derivative/provenance.json")
        self.assertEqual(report["original_source_verification"]["three_seed_development"]["status"], "not_supplied_not_verified")
        self.assertEqual(report["three_seed_saved_aggregate_comparison"]["source_bytes_kind"], "sanitized_derivative")


if __name__ == "__main__":
    unittest.main()
