#!/usr/bin/env python3
"""Offline, standard-library-only reporting from saved summaries. No experiment execution."""
import argparse
import csv
import hashlib
import io
import json
import re
import sys
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
VERSION = "1.0.1"
SEEDS = (20261101, 20261030, 20261031)
COHORTS = {
    "fixed252": (252, "unique starting case"),
    "close24": (24, "12 programs x 2 conditions"),
    "factor24": (24, "6 programs x 4 conditions"),
}
ARMS = {"start": "start", "additional_bc": "bc", "bc_plus_rl": "rl"}
LIMITS = [
    "This reproduces reporting from saved summaries, NOT learning, evaluation, hardware execution, or independent validation.",
    "Analyst extracts and normalized summary JSON are not raw simulator trajectories or trial logs.",
    "All reported cohorts are simulation development cohorts, not sealed holdout or real hardware results.",
    "The same public development cohorts were reused across policy initialization seeds; seeds are not independent physical trial counts.",
    "Cohorts overlap. No pooled total, independent-trial estimate, confidence interval, significance test, or cross-cohort aggregate is produced.",
    "Table 4 compares source-approach policies against combined distance/CLOSE corrections, not initial BC against final policies or a factorial ablation.",
    "The RL comparison uses a separate seed 20261101 source-approach checkpoint; it is not RL applied to the selected seed 20261030 model.",
    "File hash agreement identifies supplied bytes only. It does not establish data truth, source authenticity, checkpoint behavior, or experimental reproducibility.",
    "Missing original files or missing expected hashes remain explicitly unverified, even if historical metadata says file_hash_checked=true.",
    "The output does not establish exact physical-start overlap from the reported public structural-group overlap.",
    "The three policy initializations include two new replica fits and exact reuse of the primary seed 20261101 result; they are not three newly rerun fits.",
    "Current project code may differ from saved run fingerprints. This supplement does not assert that current code can rerun the experiments.",
]


class ValidationError(ValueError):
    """An input violates the documented reporting contract."""


def require(condition, message):
    if not condition:
        raise ValidationError(message)


def keys(obj, required, optional=(), label="object"):
    require(isinstance(obj, dict), f"{label}: expected an object")
    missing = set(required) - obj.keys()
    extra = obj.keys() - set(required) - set(optional)
    require(not missing, f"{label}: missing fields {sorted(missing)}")
    require(not extra, f"{label}: unsupported fields {sorted(extra)}")


def integer(value, label, minimum=0, maximum=None):
    require(type(value) is int, f"{label}: must be an integer, not a boolean or float")
    require(value >= minimum, f"{label}: must be >= {minimum}")
    if maximum is not None:
        require(value <= maximum, f"{label}: exceeds denominator {maximum}")
    return value


def nonempty(value, label):
    require(isinstance(value, str) and bool(value.strip()), f"{label}: required nonempty string")


def digest(value, label):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-fA-F]{64}", value), f"{label}: invalid SHA-256")
    return value.lower()


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON key: {key}")
        result[key] = value
    return result


def reject_constant(value):
    raise ValidationError(f"non-finite JSON number: {value}")


DECODER = json.JSONDecoder(object_pairs_hook=no_duplicates, parse_constant=reject_constant)


def load_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"),
                          object_pairs_hook=no_duplicates, parse_constant=reject_constant)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValidationError(f"Cannot read JSON {Path(path).name}: {exc}") from exc


def sha256_file(path):
    """Only stream bytes; never deserialize/import/execute the source, including .pt files."""
    require(Path(path).is_file(), f"not a regular file: {path}")
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def validate_summary(data):
    keys(data, ("schema", "data_cutoff", "evidence_type", "new_runs_performed", "table4", "rl_comparison"), label="summary")
    require(data["schema"] == "manipulation-paper-results-summary.v1", "unsupported summary schema")
    require(data["data_cutoff"] == "2026-11-11", "this supplement targets the 2026-11-11 snapshot")
    require(data["evidence_type"] == "analysis_of_saved_results", "summary must describe saved results")
    require(data["new_runs_performed"] is False, "new-runs claim is outside this supplement")
    table = data["table4"]
    keys(table, ("evaluation", "comparison", "sealed_holdout", "real_hardware", "cohorts", "rows", "caveats"), label="table4")
    require(table["evaluation"] == "simulation_development", "table4 must be simulation development")
    require(table["sealed_holdout"] is False and table["real_hardware"] is False, "unsupported holdout/hardware claim")
    require(table["comparison"] == "source-approach policy before versus distance/CLOSE combined correction after", "changed comparison semantics")
    keys(table["cohorts"], COHORTS, label="cohorts")
    for cohort, (denominator, unit) in COHORTS.items():
        item = table["cohorts"][cohort]
        keys(item, ("denominator", "unit"), label=cohort)
        integer(item["denominator"], f"{cohort}.denominator", minimum=1)
        require(item["denominator"] == denominator, f"{cohort}: incorrect success denominator")
        require(item["unit"] == unit, f"{cohort}: incorrect experimental unit")
    require(isinstance(table["rows"], list) and len(table["rows"]) == 3, "table4 requires three policy-initialization seed rows")
    for row, expected_seed in zip(table["rows"], SEEDS):
        keys(row, ("policy_initialization_seed", *COHORTS), ("selected",), label="table4 row")
        integer(row["policy_initialization_seed"], "policy_initialization_seed", minimum=1)
        require(row["policy_initialization_seed"] == expected_seed, "policy initialization seeds/order changed; physical seeds must not be substituted")
        require(type(row.get("selected", False)) is bool, "selected must be a boolean")
        require(row.get("selected", False) == (expected_seed == 20261030), "selected lineage must be seed 20261030")
        for cohort, (denominator, _) in COHORTS.items():
            values = row[cohort]
            require(isinstance(values, list) and len(values) == 2, f"{cohort}: expected [before, after]")
            for stage, value in zip(("before", "after"), values):
                integer(value, f"{expected_seed}.{cohort}.{stage}", maximum=denominator)
    caveats = table["caveats"]
    require(isinstance(caveats, list) and len(caveats) >= 4, "missing interpretation limits")
    for value in caveats:
        nonempty(value, "caveat")
    for phrase in ("reused", "overlap", "not initial BC", "physical-start"):
        require(any(phrase in value for value in caveats), f"missing caveat: {phrase}")
    rl = data["rl_comparison"]
    keys(rl, ("policy_initialization_seed", "parent", "denominator", "unit", "success", "unconfirmed", "method", "selected_for_deployment", "not_selected_seed20261030_checkpoint"), label="rl_comparison")
    require(type(rl["policy_initialization_seed"]) is int and rl["policy_initialization_seed"] == 20261101, "RL policy seed must remain 20261101")
    require(rl["parent"] == "separate source-approach checkpoint", "RL parent lineage is missing or conflated")
    integer(rl["denominator"], "RL denominator", minimum=1)
    require(rl["denominator"] == 252, "RL requires 252 development starting cases")
    require(rl["unit"] == "unique development starting case", "RL unit changed")
    require(rl["method"] == "BC plus on-policy REINFORCE", "RL method must not be relabeled PPO")
    require(rl["selected_for_deployment"] is False and rl["not_selected_seed20261030_checkpoint"] is True, "RL selected-checkpoint confusion")
    keys(rl["success"], ARMS, label="RL success")
    keys(rl["unconfirmed"], ARMS, label="RL unconfirmed")
    for arm in ARMS:
        success = integer(rl["success"][arm], f"{arm}.success", maximum=252)
        unconfirmed = integer(rl["unconfirmed"][arm], f"{arm}.unconfirmed", maximum=252)
        require(success + unconfirmed <= 252, f"{arm}: count exceeds denominator")
        require(unconfirmed == 0, f"{arm}: snapshot reports zero unconfirmed")
    return data


def validate_manifest(data, summary):
    keys(data, ("schema", "data_cutoff", "public_release_status", "source_paths_are_project_relative", "selected_checkpoint", "technical_specification", "three_seed_development", "rl_comparison", "scope", "references"),
         ("training_provenance_documents", "evaluation_specification", "collector_and_range_rule", "historical_source_recovery"), label="manifest")
    require(data["schema"] == "manipulation-paper-source-manifest.v1", "unsupported manifest schema")
    require(data["data_cutoff"] == summary["data_cutoff"], "manifest/summary cutoff mismatch")
    require(data["source_paths_are_project_relative"] is True, "manifest paths must be project-relative")
    require(data["public_release_status"] == "not_published", "release-status changes require a new reviewed snapshot")
    nonempty(data["scope"], "manifest scope")
    require(isinstance(data["references"], list) and data["references"], "missing references")
    for key in ("selected_checkpoint", "technical_specification", "three_seed_development", "rl_comparison"):
        item = data[key]
        require(isinstance(item, dict) and "path" in item, f"missing provenance: {key}")
        nonempty(item["path"], f"{key}.path")
        path = PurePosixPath(item["path"])
        require(not path.is_absolute() and ".." not in path.parts and "\\" not in item["path"] and ":" not in item["path"], f"{key}: invalid project-relative path")
        hash_key = "starting_checkpoint_sha256" if key == "rl_comparison" else "sha256"
        digest(item.get(hash_key), f"{key}.{hash_key}")
    selected = data["selected_checkpoint"]
    require("seed_20261030/" in selected["path"], "selected source path has wrong policy seed")
    require(selected.get("format") == "terra-native-source-distance-close-evidence.v1", "selected checkpoint format mismatch")
    require(digest(selected["sha256"], "selected hash") != digest(data["rl_comparison"]["starting_checkpoint_sha256"], "RL parent hash"), "RL start must differ from selected checkpoint")
    require("three_seed_verification.json" == PurePosixPath(data["three_seed_development"]["path"]).name, "unexpected three-seed provenance")
    # v0.2/v0.3 reference metadata is checked syntactically, never opened or executed.
    # Its historical verification flags are not this run's source-byte checks.
    extra_paths = []
    if "training_provenance_documents" in data:
        item = data["training_provenance_documents"]
        keys(item, ("demonstration_selection", "weight_lineage", "independently_compared_original_sessions", "remaining_originals_check_scope"), label="training provenance references")
        extra_paths.extend((item["demonstration_selection"], item["weight_lineage"]))
        integer(item["independently_compared_original_sessions"], "reported compared sessions")
        nonempty(item["remaining_originals_check_scope"], "remaining originals scope")
    if "evaluation_specification" in data:
        item = data["evaluation_specification"]
        keys(item, ("path", "sections", "sha256", "last_write_utc", "distinct_from_learning_specification_snapshot"), label="evaluation specification")
        extra_paths.append(item["path"])
        digest(item["sha256"], "evaluation specification hash")
        require(isinstance(item["sections"], list) and item["sections"], "evaluation sections required")
        for section in item["sections"]:
            nonempty(section, "evaluation section")
        require(item["distinct_from_learning_specification_snapshot"] is True, "distinct specification snapshots must not be conflated")
    if "collector_and_range_rule" in data:
        collection = data["collector_and_range_rule"]
        require(isinstance(collection, dict) and collection, "collector references must be a nonempty object")
        for path, item in collection.items():
            extra_paths.append(path)
            keys(item, ("sha256", "last_write_utc", "captured_file_hash_verified"), label="collector reference")
            digest(item["sha256"], "collector reference hash")
            require(type(item["captured_file_hash_verified"]) is bool, "historical verification flag must be boolean")
    if "historical_source_recovery" in data:
        item = data["historical_source_recovery"]
        keys(item, ("source", "source_assignment_sha256", "historical_files_recovered",
                    "historical_files_unrecovered_in_checked_scope", "candidate_files_checked",
                    "zip_archives_checked", "partial_bundle_check", "scope"), label="historical source recovery reference")
        nonempty(item["source"], "historical source recovery reference path")
        path = item["source"]
        require(not PurePosixPath(path).is_absolute() and "\\" not in path and ":" not in path
                and all(part not in ("", ".", "..") for part in path.split("/"))
                and not any(ord(char) < 32 or ord(char) == 127 for char in path),
                "historical source recovery reference must be a canonical relative path")
        digest(item["source_assignment_sha256"], "historical source assignment hash")
        for name in ("historical_files_recovered", "historical_files_unrecovered_in_checked_scope",
                     "candidate_files_checked", "zip_archives_checked"):
            integer(item[name], "historical source recovery." + name)
        counts = item["partial_bundle_check"]
        keys(counts, ("matched", "mismatched", "missing_from_bundle"), label="historical partial bundle counts")
        for name, value in counts.items():
            integer(value, "historical partial bundle." + name, maximum=258)
        require(sum(counts.values()) == 258, "historical partial bundle counts must sum to 258 pins")
        require(item["historical_files_recovered"] == counts["matched"]
                and item["historical_files_unrecovered_in_checked_scope"] == counts["mismatched"],
                "historical recovery counts disagree with reported partial bundle")
        require(item["candidate_files_checked"] >= counts["matched"] + counts["mismatched"],
                "historical candidate count is smaller than the reported recovery scope")
        nonempty(item["scope"], "historical source recovery scope")
        # These are historical claims only. The separate source-bundle verifier owns
        # byte checks; this reporting tool does not open the recovery path or sources.
    for path in extra_paths:
        nonempty(path, "additional project-relative source path")
        require(not PurePosixPath(path).is_absolute() and ".." not in PurePosixPath(path).parts and "\\" not in path and ":" not in path,
                "additional source reference must be project-relative without traversal")
    return data


def table4_markdown(summary):
    lines = ["| 학습 시드 | 고유 시작 252개 | 5~7단계 24조건 | 7~8단계 24조건 |", "|---|---|---|---|"]
    for row in summary["table4"]["rows"]:
        label = str(row["policy_initialization_seed"]) + (", 채택 계열" if row.get("selected") else "")
        cells = [f"{row[c][0]} → {row[c][1]}" for c in COHORTS]
        lines.append("| " + " | ".join([label, *cells]) + " |")
    return "\n".join(lines) + "\n"


def check_manuscript(text, summary):
    header = "| 학습 시드 | 고유 시작 252개 | 5~7단계 24조건 | 7~8단계 24조건 |"
    lines = text.splitlines()
    starts = [i for i, line in enumerate(lines) if line == header]
    require(len(starts) == 1, "manuscript must contain exactly one Table 4 header")
    block = []
    for line in lines[starts[0]:]:
        if not line.startswith("|"):
            break
        block.append(line)
    require("\n".join(block) + "\n" == table4_markdown(summary), "generated Table 4 differs from manuscript")
    return {"status": "exact_markdown_table_match", "line_ending_normalization": True}


def check_result_extract(text, summary):
    """Read only the three leading JSON objects in the mixed curated transcript."""
    pos = 0
    records = []
    for i in range(3):
        while pos < len(text) and text[pos].isspace():
            pos += 1
        try:
            record, pos = DECODER.raw_decode(text, pos)
        except json.JSONDecodeError as exc:
            raise ValidationError(f"malformed leading result extract object {i + 1}") from exc
        records.append(record)
    absent = []
    for record, row in zip(records, summary["table4"]["rows"]):
        fields = [f"{prefix}_{stage}" for prefix in ("fixed", "close", "factor") for stage in ("before", "after")]
        keys(record, ("seed", *fields), label="result extract")
        require(record["seed"] == str(row["policy_initialization_seed"]), "curated extract policy seed mismatch")
        for cohort, prefix in zip(COHORTS, ("fixed", "close", "factor")):
            denominator = COHORTS[cohort][0]
            for index, stage in enumerate(("before", "after")):
                count = record[f"{prefix}_{stage}"]
                keys(count, ("success",), ("failure", "unconfirmed"), label=f"{cohort}.{stage}")
                for name, value in count.items():
                    integer(value, f"extract.{name}", maximum=denominator)
                require(count["success"] == row[cohort][index], "extract success does not match saved summary")
                require(sum(count.values()) == denominator, "extract recorded counts do not exhaust cohort denominator")
                if cohort == "fixed252":
                    require(count.get("unconfirmed") == 0, "fixed252 extract must state zero unconfirmed")
                for name in ("failure", "unconfirmed"):
                    if name not in count:
                        absent.append(f"{record['seed']}.{cohort}.{stage}.{name}")
    return {"status": "three_leading_curated_summary_records_match", "records_checked": 3,
            "not_raw_trial_data": True, "absent_status_fields_not_presented_as_explicit_observations": absent,
            "remaining_mixed_transcript": "not parsed or used as experimental data"}


def check_rl_extract(evidence, summary, manifest):
    keys(evidence, ("source", "arms", "bindings", "development_only", "final_holdout_used", "actual_hardware"), label="RL extract")
    require(evidence["source"] == manifest["rl_comparison"]["path"], "RL source mismatch")
    require(evidence["development_only"] is True and evidence["final_holdout_used"] is False and evidence["actual_hardware"] is False, "RL evaluation scope mismatch")
    keys(evidence["arms"], ARMS.values(), label="RL extracted arms")
    for arm, evidence_arm in ARMS.items():
        item = evidence["arms"][evidence_arm]
        keys(item, ("success", "failure", "unconfirmed"), label=f"RL {arm}")
        for key, value in item.items():
            integer(value, f"RL extract {arm}.{key}", maximum=252)
        require(sum(item.values()) == 252, f"RL {arm}: counts do not sum to denominator")
        require(item["success"] == summary["rl_comparison"]["success"][arm], "RL success mismatch")
        require(item["unconfirmed"] == summary["rl_comparison"]["unconfirmed"][arm], "RL unconfirmed mismatch")
    bindings = evidence["bindings"]
    require(isinstance(bindings, dict) and isinstance(bindings.get("start"), dict) and isinstance(bindings.get("models"), dict), "missing RL source bindings")
    expected = digest(manifest["rl_comparison"]["starting_checkpoint_sha256"], "RL manifest start")
    require(digest(bindings["start"].get("sha256"), "RL start binding") == expected, "RL starting checkpoint mismatch")
    require(isinstance(bindings["models"].get("start"), dict), "missing RL start-model binding")
    require(digest(bindings["models"]["start"].get("sha256"), "RL start model") == expected, "RL start-model hash mismatch")
    return {"status": "curated_summary_counts_and_parent_hash_match", "not_raw_trial_data": True,
            "policy_seed_independently_established_from_this_extract": False}


def check_method_extract(text, manifest):
    for value in (manifest["technical_specification"]["sha256"], manifest["selected_checkpoint"]["sha256"], manifest["selected_checkpoint"]["format"], "20261030"):
        require(value.lower() in text.lower(), "method excerpt lacks selected-model/specification identity")
    return {"status": "excerpt_contains_declared_identifiers", "full_original_document_verified": False}


def source_targets(manifest, rl_evidence):
    targets = {}
    for name in ("selected_checkpoint", "technical_specification", "three_seed_development"):
        item = manifest[name]
        targets[name] = {"declared_source_path": item["path"], "expected_sha256": item["sha256"].lower()}
    targets["rl_comparison"] = {"declared_source_path": manifest["rl_comparison"]["path"], "expected_sha256": None}
    targets["rl_start_checkpoint"] = {"declared_source_path": rl_evidence["bindings"]["start"].get("path"),
                                      "expected_sha256": manifest["rl_comparison"]["starting_checkpoint_sha256"].lower()}
    return targets


def verify_sources(targets, supplied):
    require(not set(supplied) - set(targets), "unknown source ID in --verify-file")
    report = {}
    for source_id, target in targets.items():
        item = dict(target)
        item["historical_hash_checked_flag_reused"] = False
        if source_id not in supplied:
            item["status"] = "not_supplied_not_verified"
        else:
            path = Path(supplied[source_id])
            item["supplied_filename"] = path.name
            if not path.is_file():
                item["status"] = "supplied_file_missing_not_verified"
            else:
                item["observed_sha256"] = sha256_file(path)
                if target["expected_sha256"] is None:
                    item["status"] = "no_expected_hash_not_verified"
                else:
                    item["status"] = "hash_match" if item["observed_sha256"] == target["expected_sha256"] else "hash_mismatch"
        report[source_id] = item
    return report


def resolve_under_root(root, relative):
    """Only an explicitly supplied root plus a non-traversing relative reference."""
    nonempty(relative, "source relative path")
    parsed = PurePosixPath(relative)
    require(not parsed.is_absolute() and ".." not in parsed.parts and "\\" not in relative and ":" not in relative,
            "source reference must be a forward-slash relative path without traversal")
    root = Path(root).resolve()
    path = (root / relative).resolve()
    require(root in path.parents, "source path or symlink escapes source root")
    return path


def json_pointer(document, pointer):
    require(isinstance(pointer, str) and (pointer == "" or pointer.startswith("/")), "invalid JSON pointer")
    value = document
    for encoded in pointer.split("/")[1:]:
        require(not re.search(r"~(?![01])", encoded), "invalid JSON pointer escape")
        token = encoded.replace("~1", "/").replace("~0", "~")
        if isinstance(value, list):
            require(bool(re.fullmatch(r"0|[1-9][0-9]*", token)), "invalid JSON pointer array index")
            require(int(token) < len(value), f"JSON pointer index missing: {pointer}")
            value = value[int(token)]
        else:
            require(isinstance(value, dict) and token in value, f"JSON pointer field missing: {pointer}")
            value = value[token]
    return value


def expected_mapping_targets():
    result = {f"/table4/rows/{i}/policy_initialization_seed" for i in range(3)}
    result |= {f"/table4/rows/{i}/{cohort}/{stage}" for i in range(3) for cohort in COHORTS for stage in range(2)}
    result |= {f"/rl_comparison/{kind}/{arm}" for kind in ("success", "unconfirmed") for arm in ARMS}
    return result


def compare_original_bindings(config, config_path, summary, targets):
    """Declarative JSON-pointer comparison; original schemas are never guessed or executed."""
    keys(config, ("schema", "sources"), label="original bindings")
    require(config["schema"] == "explicit-original-json-bindings.v1", "unsupported binding schema")
    require(isinstance(config["sources"], list) and config["sources"], "binding sources must be nonempty")
    rows, coverage, source_seen = [], set(), set()
    for source in config["sources"]:
        keys(source, ("source_id", "file", "bindings"), label="binding source")
        source_id = source["source_id"]
        require(source_id in targets, "unknown original source ID")
        require(source_id not in source_seen, "duplicate original source ID")
        source_seen.add(source_id)
        nonempty(source["file"], "binding file")
        path = resolve_under_root(Path(config_path).resolve().parent, source["file"])
        original = load_json(path)
        require(isinstance(source["bindings"], list) and source["bindings"], "bindings must be nonempty")
        comparisons = []
        for binding in source["bindings"]:
            keys(binding, ("source_pointer", "summary_pointer"), label="binding")
            pointer = binding["summary_pointer"]
            require(pointer in expected_mapping_targets(), "binding must target a declared count or policy seed")
            require(pointer not in coverage, "duplicate summary-pointer binding")
            coverage.add(pointer)
            expected = json_pointer(summary, pointer)
            observed = json_pointer(original, binding["source_pointer"])
            comparisons.append({**binding, "status": "match" if type(observed) is type(expected) and observed == expected else "mismatch", "expected": expected, "observed": observed})
        verification = verify_sources({source_id: targets[source_id]}, {source_id: path})[source_id]
        rows.append({"source_id": source_id, "hash_verification": verification, "comparisons": comparisons})
    missing = sorted(expected_mapping_targets() - coverage)
    return {"status": "explicit_field_comparisons_only", "sources": rows,
            "unmapped_expected_fields": missing, "all_count_and_seed_fields_mapped": not missing,
            "independent_validation": False,
            "scope": "User-authored pointer mapping is an interpretation aid, not an invented original schema or proof of experiment execution."}


def check_three_seed_json(original, summary, manifest):
    """Adapter for the structure actually observed in the supplied three-seed artifact.

    This is still a saved aggregate JSON, NOT raw simulator trajectories.
    Other keys are retained as source metadata but not reinterpreted.
    """
    require(isinstance(original, dict), "three-seed JSON must be an object")
    for key, expected in (("independent_BC_initializations", 3), ("distinct_original_BC_batch_orders", 3),
                          ("new_replica_fits", 2), ("exact_primary_reuse", True),
                          ("sealed_final_holdout_used", False), ("real_hardware", False)):
        require(key in original and type(original[key]) is type(expected) and original[key] == expected, f"three-seed scope/reuse mismatch: {key}")
    seed_results = original.get("seed_results")
    keys(seed_results, tuple(map(str, SEEDS)), label="three-seed policy initialization keys")
    matched = []
    for row in summary["table4"]["rows"]:
        seed = str(row["policy_initialization_seed"])
        for cohort, source_key, inner in (("fixed252", "before_vs_after_fixed252", "/programs/unique252"),
                                          ("close24", "before_vs_after_close24", "/program"),
                                          ("factor24", "before_vs_after_mass_pad24", "/program")):
            for index, stage in enumerate(("before", "after")):
                pointer = f"/seed_results/{seed}/{source_key}/{stage}{inner}"
                counts = json_pointer(original, pointer)
                keys(counts, ("success",), ("failure", "unconfirmed"), label=pointer)
                for status, count in counts.items():
                    integer(count, f"{pointer}/{status}", maximum=COHORTS[cohort][0])
                require(sum(counts.values()) == COHORTS[cohort][0], f"three-seed denominator mismatch: {pointer}")
                require(counts["success"] == row[cohort][index], f"three-seed success mismatch: {pointer}")
                if cohort == "fixed252":
                    require(counts.get("unconfirmed") == 0, f"three-seed missing zero unconfirmed: {pointer}")
                matched.append({"policy_initialization_seed": int(seed), "cohort": cohort, "stage": stage,
                                "source_pointer": pointer + "/success", "success": counts["success"], "denominator": COHORTS[cohort][0]})
    selected = json_pointer(original, "/seed_results/20261030/models/after/sha256")
    parent = json_pointer(original, "/seed_results/20261101/models/before/sha256")
    require(selected == manifest["selected_checkpoint"]["sha256"], "three-seed selected checkpoint mismatch")
    require(parent == manifest["rl_comparison"]["starting_checkpoint_sha256"], "three-seed/RL source-approach parent mismatch")
    return {"status": "18_success_counts_and_policy_seed_keys_match", "matched_fields": matched,
            "new_replica_fits": 2, "exact_primary_reuse": True,
            "seed20261101_replica_result_json_assumed": False,
            "source_is_saved_aggregate_not_raw_trial_data": True, "independent_validation": False}


def table4_records(summary):
    records = []
    for row in summary["table4"]["rows"]:
        for cohort, (denominator, unit) in COHORTS.items():
            for stage, success in zip(("before", "after"), row[cohort]):
                records.append({"policy_initialization_seed": row["policy_initialization_seed"], "selected_lineage": row.get("selected", False), "cohort": cohort,
                                "unit": unit, "stage": stage, "success": success, "denominator": denominator,
                                "success_rate": format(success / denominator, ".9f"), "evaluation": "simulation_development"})
    return records


def rl_records(summary, evidence, manifest):
    result = []
    for arm, raw_arm in ARMS.items():
        counts = evidence["arms"][raw_arm]
        result.append({"policy_initialization_seed": summary["rl_comparison"]["policy_initialization_seed"], "arm": arm,
                       **counts, "denominator": 252, "success_rate": format(counts["success"] / 252, ".9f"),
                       "starting_checkpoint_sha256": manifest["rl_comparison"]["starting_checkpoint_sha256"],
                       "selected_for_deployment": False, "evaluation": "simulation_development"})
    return result


def csv_text(records):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(records[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    return stream.getvalue()


def output_dir(value):
    path = Path(value)
    path = path if path.is_absolute() else ROOT / path
    path = path.resolve()
    require(path != ROOT and ROOT in path.parents, "output directory must be inside this supplement, not its root")
    require(path != ROOT / "inputs" and ROOT / "inputs" not in path.parents, "must not overwrite input snapshots")
    require(path != ROOT / "tests" and ROOT / "tests" not in path.parents, "must not overwrite tests")
    return path


def write_outputs(directory, files):
    directory.mkdir(parents=True, exist_ok=True)
    # Check every final filename before any write, including symlink escape attempts.
    for name in files:
        path = directory / name
        require(path.resolve().parent == directory.resolve(), f"output target escapes directory: {name}")
        require(not path.is_symlink(), f"will not overwrite symlink: {name}")
    for name, content in files.items():
        (directory / name).write_text(content, encoding="utf-8")


def run(args):
    summary = validate_summary(load_json(args.results))
    manifest = validate_manifest(load_json(args.sources), summary)
    rl_evidence = load_json(args.rl_evidence)
    checks = {
        "summary_schema_counts_seeds_and_limits": "passed",
        "source_manifest_and_lineage": "passed",
        "additional_manifest_reference_metadata": "syntax_checked_only; historical source-verification flags are not reused as current checks",
        "historical_source_recovery_reference_metadata": (
            "syntax_and_internal_counts_checked_only; not_a_new_source_bundle_check"
            if "historical_source_recovery" in manifest else "not_supplied"),
        "manuscript_table4": check_manuscript(Path(args.manuscript).read_text(encoding="utf-8-sig"), summary),
        "curated_result_extract": check_result_extract(Path(args.result_evidence).read_text(encoding="utf-8-sig"), summary),
        "curated_rl_extract": check_rl_extract(rl_evidence, summary, manifest),
        "curated_method_extract": check_method_extract(Path(args.method_evidence).read_text(encoding="utf-8-sig"), manifest),
    }
    input_files = {name: Path(getattr(args, name)) for name in ("results", "sources", "manuscript", "result_evidence", "rl_evidence", "method_evidence")}
    targets = source_targets(manifest, rl_evidence)
    supplied = {}
    for item in args.verify_file:
        require("=" in item, "--verify-file must be SOURCE_ID=LOCAL_FILE")
        name, path = item.split("=", 1)
        require(name and path and name not in supplied, "duplicate or empty --verify-file argument")
        require(args.source_root is not None, "--verify-file requires explicit --source-root")
        supplied[name] = resolve_under_root(args.source_root, path)
    source_verification = verify_sources(targets, supplied)
    three_seed = {"status": "not_supplied_not_checked"}
    if args.three_seed_json:
        three_seed = check_three_seed_json(load_json(args.three_seed_json), summary, manifest)
        input_files["three_seed_json"] = Path(args.three_seed_json)
        observed_hash = sha256_file(args.three_seed_json)
        three_seed["source_bytes_kind"] = args.three_seed_kind
        three_seed["supplied_sha256"] = observed_hash
        three_seed["original_expected_sha256"] = targets["three_seed_development"]["expected_sha256"]
        if args.three_seed_kind == "original":
            source_verification["three_seed_development"] = verify_sources(
                {"three_seed_development": targets["three_seed_development"]},
                {"three_seed_development": args.three_seed_json})["three_seed_development"]
        else:
            three_seed["hash_scope"] = "sanitized derivative hash only; does not verify original bytes"
    originals = {"status": "not_requested", "independent_validation": False}
    if args.original_bindings:
        config = load_json(args.original_bindings)
        originals = compare_original_bindings(config, args.original_bindings, summary, targets)
        input_files["original_bindings"] = Path(args.original_bindings)
    mismatch = any(x["status"] == "hash_mismatch" for x in source_verification.values())
    for source in originals.get("sources", []):
        mismatch |= source["hash_verification"]["status"] == "hash_mismatch"
        mismatch |= any(x["status"] == "mismatch" for x in source["comparisons"])
    report = {"schema": "manipulation-report-reproduction-provenance.v1", "tool_version": VERSION,
              "scope": "reporting_from_saved_summaries_only", "validation_status": "failed_source_comparison" if mismatch else "summary_checks_passed",
              "new_runs_performed": False, "independent_validation_performed": False, "network_or_hardware_access": False,
              "inputs": {key: {"filename": path.name, "sha256": sha256_file(path)} for key, path in input_files.items()},
              "checks": checks, "original_source_verification": source_verification, "explicit_original_json_comparison": originals,
              "three_seed_saved_aggregate_comparison": three_seed,
              "limits": LIMITS, "counts": {"table4_rows": 3, "table4_long_records": 18, "rl_arms": 3},
              "all_original_sources_hash_verified": all(x["status"] == "hash_match" for x in source_verification.values())}
    # The starting-checkpoint hash is NOT a hash of RL summary.json; missing expected hash remains visible.
    table_rows = table4_records(summary)
    rl_rows = rl_records(summary, rl_evidence, manifest)
    rl_md = "| 조건 | 성공 | 실패 | 미판정 | 분모 |\n|---|---:|---:|---:|---:|\n"
    for row, name in zip(rl_rows, ("출발", "추가 BC", "BC+RL")):
        rl_md += f"| {name} | {row['success']} | {row['failure']} | {row['unconfirmed']} | 252 |\n"
    rl_md += "\n별도 policy initialization seed 20261101의 source-approach 출발 체크포인트. 표 4의 채택 seed 20261030 최종 모델과 다르며, RL 후보는 채택되지 않았다. 모든 값은 가상 개발 결과이다.\n"
    provenance_md = "# Reporting provenance\n\nStatus: " + report["validation_status"] + ".\n\n"
    provenance_md += "The Markdown Table 4 exactly matches the saved manuscript table (line endings normalized).\n\n"
    provenance_md += "## Source-byte checks\n\n"
    provenance_md += "\n".join(f"- {name}: {item['status']}" for name, item in source_verification.items()) + "\n\n"
    provenance_md += "## Interpretation limits\n\n" + "\n".join("- " + line for line in LIMITS) + "\n"
    if originals["status"] != "not_requested":
        provenance_md += "\nExplicit original JSON field comparisons are recorded in provenance.json; unmapped fields and per-source hash status remain visible.\n"
    files = {"table4.md": table4_markdown(summary), "table4.csv": csv_text(table_rows),
             "rl_results.md": rl_md, "rl_results.csv": csv_text(rl_rows),
             "provenance.json": json.dumps(report, ensure_ascii=False, indent=2) + "\n", "provenance.md": provenance_md}
    write_outputs(output_dir(args.output), files)
    print(f"{report['validation_status']}: Table 4 (3 rows / 18 records), RL (3 separate arms).")
    print(f"Outputs: {output_dir(args.output)}")
    print("Reporting only; no learning/evaluation/hardware execution or independent validation.")
    return 2 if mismatch else 0


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    for name, filename in (("results", "results.json"), ("sources", "sources.json"), ("manuscript", "manuscript.md"),
                           ("result_evidence", "result_evidence.txt"), ("rl_evidence", "rl_evidence.json"), ("method_evidence", "method_evidence.txt")):
        result.add_argument("--" + name.replace("_", "-"), type=Path, default=ROOT / "inputs" / filename)
    result.add_argument("--output", default="generated", help="Directory under this supplement only")
    result.add_argument("--verify-file", action="append", default=[], metavar="SOURCE_ID=LOCAL_FILE", help="Optional byte-only SHA-256 check; never deserialize or execute")
    result.add_argument("--source-root", type=Path, help="Explicit local root for --verify-file relative paths; never inferred from the manifest")
    result.add_argument("--original-bindings", type=Path, help="Explicit, reviewed JSON-pointer map for supplied original JSON")
    result.add_argument("--three-seed-json", type=Path, help="Optional supplied three_seed_verification JSON, read only")
    result.add_argument("--three-seed-kind", choices=("original", "sanitized_derivative"), default="original", help="Never compare a redacted derivative hash as if it were original bytes")
    return result


def main(argv=None):
    try:
        return run(parser().parse_args(argv))
    except (ValidationError, OSError, UnicodeError, RecursionError) as exc:
        print(f"Validation error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
