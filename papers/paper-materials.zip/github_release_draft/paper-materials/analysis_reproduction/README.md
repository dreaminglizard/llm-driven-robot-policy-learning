# 저장 결과의 표·보고서 재생성 보충자료

이 보충자료는 **저장된 요약으로부터 논문 표 4와 별도 RL 결과를 다시 작성**합니다. 학습, 시뮬레이션 평가, 실물 실행 또는 독립 검증을 재현하는 패키지가 아닙니다. 새 실험은 수행하지 않습니다. Python 표준 라이브러리만 사용하며 패키지 설치가 필요하지 않습니다.

## 실행

이 README가 있는 폴더에서 실행합니다. Python 3.8 이상을 권장합니다. `-B`는 바이트코드 캐시 생성을 막습니다.

```sh
python -B reproduce.py
python -B -m unittest discover -s tests -v
```

첫 명령은 `inputs/`에 포함된 요약과 발췌본만 읽고 `generated/`에 다음 파일을 만듭니다.

- `table4.md`: 원고 표 4와 일치하는 Markdown 표. 줄바꿈 형식만 정규화하여 비교합니다.
- `table4.csv`: 학습 초기화 시드 × 평가 묶음 × before/after의 18개 행. 성공 수, 분모, 단위와 성공 비율을 각각 표시합니다.
- `rl_results.md`, `rl_results.csv`: 별도 RL 출발 모델에 대한 start·추가 BC·BC+RL 3조건. 표 4와 합산하지 않습니다.
- `provenance.json`, `provenance.md`: 입력 파일 지문, 확인한 항목, 원본 파일 검증 상태와 해석 한계.

CSV 성공 비율은 성공 수/각 행의 분모를 소수점 아래 9자리로 표시한 보고용 값입니다. 원고 표에는 성공 수만 표시합니다. 출력은 결정적이며 동일한 입력·옵션으로 다시 실행하면 같은 바이트를 생성합니다. 출력 경로는 이 보충자료 폴더 아래로 제한되며 `inputs/`와 `tests/`를 덮어쓸 수 없습니다.

## 원래 집계 JSON 구조와 대조

포함된 `three_seed_verification.sanitized.json`은 [P3]의 저장 집계 구조를 보존하되 개인 Windows 프로젝트 루트를 제거하고 JSON을 다시 직렬화한 **파생본**입니다. 원본 파일과 바이트가 같다는 뜻이 아닙니다.

```sh
python -B reproduce.py --three-seed-json inputs/three_seed_verification.sanitized.json --three-seed-kind sanitized_derivative --output generated_from_aggregate
```

관찰된 실제 구조에 맞춰 다음 경로의 성공 수 18개와 각 상태 수의 합을 검사합니다. `<seed>`는 20261101, 20261030, 20261031이며 `<stage>`는 before, after입니다.

- `/seed_results/<seed>/before_vs_after_fixed252/<stage>/programs/unique252/success`
- `/seed_results/<seed>/before_vs_after_close24/<stage>/program/success`
- `/seed_results/<seed>/before_vs_after_mass_pad24/<stage>/program/success`

프로그램 성공을 `moves`와 혼동하거나 `broad216`, `connected18`, `small50`을 합해 고유 시작 수를 만들지 않습니다. 정책 초기화 키 3개, `new_replica_fits=2`, `exact_primary_reuse=true`, 채택 및 RL 출발 체크포인트 지문도 검사합니다. seed 20261101의 별도 replica `result.json`을 가정하지 않습니다. 이 입력도 개별 시뮬레이터 궤적이 아닌 **저장된 집계**입니다.

실제 원본 JSON 파일을 별도로 보유한 경우 명시적 경로를 전달할 수 있습니다. `PATH_TO_ORIGINAL_JSON`은 실제 파일 경로로 바꿉니다.

```sh
python -B reproduce.py --three-seed-json PATH_TO_ORIGINAL_JSON --three-seed-kind original --output generated_original_check
```

원본 옵션은 [P3]에 기록된 원본 SHA-256과 공급한 파일의 실제 바이트 지문을 비교합니다. 텍스트에서 다시 만든 JSON을 원본으로 지정하면 해시가 다를 수 있습니다. 이때 검증 성공으로 숨기지 않고 불일치 및 종료 코드 2를 보고합니다. 파생본을 대조한 성공과 원본 바이트 검증은 별개입니다.

**기존 v0.4 준비 시 확인(이번 v0.5에서 원본 모드를 재실행하지 않음):** 별도로 공급된 [P3] 원본의 SHA-256이 `adf5c04fcabb0902f77f173793027c7362cc3dc5e55de75e4edd74b692371f3a`와 일치했고, 어댑터가 성공 수 18개·분모·시드 키·모델 계보를 확인했습니다. 이 결과는 `generated_verified_original/provenance.json`에 보존했습니다. 포함된 파생본도 해당 원본에 문서화된 경로 정리만 적용한 구조와 일치했습니다. 개인 경로를 포함하는 원본 파일 자체는 이 패키지에 넣지 않았으므로 **기본 명령의 재실행은 원본 바이트를 다시 검증하지 않습니다.** 다른 원본 파일 및 실험 실행은 검증하지 않았습니다.

v0.5에서는 포함된 요약·경로 정리 파생본만 다시 검사했습니다. `generated_verified_original/`은 v0.4의 원본 확인 기록을 보존한 것이며, 이번에 새로 생성한 원본 검사 결과가 아닙니다. 원본은 이 묶음에 없습니다.

## 선택적 원본 파일 지문 검사

기본 실행은 원본 프로젝트, 사용자 컴퓨터 또는 체크포인트에 접근하지 않습니다. 원본을 이미 로컬에 보유한 경우에만 별도로 지정합니다. 아래의 `LOCAL_SOURCE_ROOT`는 실제 로컬 프로젝트 루트로 바꿉니다.

```sh
python -B reproduce.py --source-root LOCAL_SOURCE_ROOT --verify-file three_seed_development=artifacts/architecture_research/astra_close_reproduction_three_seeds_20261106_v1/three_seed_verification.json --output generated_hash_check
```

`--verify-file SOURCE_ID=relative/path`는 반복할 수 있습니다. 경로는 지정한 `--source-root` 아래의 순방향 슬래시 상대 경로여야 합니다. 절대 경로, `..` 경로 이동, 루트 밖을 가리키는 심볼릭 링크를 거절합니다. 패키지 manifest의 경로를 자동 순회하지 않습니다.

지원하는 SOURCE_ID는 `selected_checkpoint`, `technical_specification`, `three_seed_development`, `rl_comparison`, `rl_start_checkpoint`입니다. 체크포인트를 명시한 경우에도 바이트를 스트리밍하여 SHA-256만 계산합니다. pickle, PyTorch, 모델 상태 또는 프로젝트 코드를 역직렬화·임포트·실행하지 않습니다.

`sources.json`에는 RL `summary.json` 자체의 기대 지문이 없습니다. `starting_checkpoint_sha256`를 summary 파일의 지문으로 사용하지 않습니다. 따라서 RL summary 파일을 공급해도 `no_expected_hash_not_verified`로 기록합니다. 과거의 `file_hash_checked=true`는 이 도구의 검증 결과로 승격하지 않습니다. 파일 미제공·누락·기대 지문 부재는 각각 미검증으로 남습니다.

## 다른 원본 JSON에 대한 명시적 필드 대조

원본 구조가 알려지지 않은 자료는 추측해서 파싱하지 않습니다. 별도 JSON-pointer 대조가 필요하면 `--original-bindings MAP_JSON`을 사용할 수 있습니다. 아래는 형식 설명일 뿐 실제 RL 원본 구조를 주장하지 않습니다. `<검토한 실제 JSON 경로>`는 원본을 직접 확인한 뒤 바꿔야 합니다.

```json
{
  "schema": "explicit-original-json-bindings.v1",
  "sources": [{
    "source_id": "rl_comparison",
    "file": "original_summary.json",
    "bindings": [{
      "source_pointer": "/<검토한 실제 JSON 경로>",
      "summary_pointer": "/rl_comparison/success/start"
    }]
  }]
}
```

`file`은 MAP_JSON이 있는 폴더 아래의 상대 경로이며 절대 경로·상위 이동·루트 밖 심볼릭 링크를 거절합니다. 비교하지 않은 필드는 `unmapped_expected_fields`에 표시합니다. 일부 필드 일치, 모든 지정 필드 일치, 원본 해시 일치, 실험의 독립 검증은 서로 다릅니다. 이 기능은 원본 스키마를 생성하거나 새 실험을 수행하지 않습니다.

## 입력과 출처

- `inputs/results.json`: 원고 작성에 사용한 정규화된 저장 결과 요약. 원시 실험 자료가 아닙니다.
- `inputs/sources.json`: v0.5 원고의 [P1/P3/P5] 등 출처 식별자와 기록된 지문. 실제 원본은 포함하지 않습니다. 추가된 시연 출처·평가 명세·수집기 참조는 형식과 상대 경로만 검사하며, 과거의 검증 표시를 이번 실행의 원본 파일 검증으로 사용하지 않습니다. `historical_source_recovery`도 타입·정수 범위·258개 합계와 내부 수치 관계·상대 경로 형식만 검사합니다. 기록된 3개 일치·4개 불일치·251개 미제공은 이 분석 도구가 새로 실행한 지문 검사 결과가 아닙니다. 참조한 회수 파일을 열거나 실행하지 않으며, 실제 사본의 바이트 검사는 별도 `source_recovery/verify_source_bundle.py`의 관할입니다.
- `inputs/manuscript.md`: 표 일치 검사에 사용하는 v0.5 원고 사본. 편집은 별도 원고에서 수행해야 합니다.
- `inputs/method_evidence.txt`: [P1]의 출처 식별과 채택 모델 설명 부분만 발췌.
- `inputs/result_evidence.txt`: [P3]의 세 정책 초기화별 성공·실패 집계 발췌. 일부 24조건 집계에는 `unconfirmed` 또는 `failure` 키가 없으며 이를 명시적 관측값으로 둔갑시키지 않습니다.
- `inputs/rl_evidence.json`: [P5]의 요약·계보 발췌. 개인 Windows 루트는 프로젝트 상대 경로로 치환했습니다.
- `inputs/three_seed_verification.sanitized.json`: [P3] 집계 JSON의 경로 정리 파생본.
- `inputs/derivations.json`: 발췌·경로 정리 방법, 원본 출처가 보고한 지문, 파생본의 로컬 지문을 구분한 기록.

원고 원본과 현재 표를 비교하려면 `--manuscript PATH_TO_MANUSCRIPT`를 지정합니다. 다른 요약 판본을 사용하려면 `--results`와 `--sources` 등 옵션을 명시해야 합니다. 본 버전은 2026-11-11의 v1 스키마, 분모, 단위, 시드·계보·개발 평가 한계를 엄격히 검사합니다. 새로운 실험이나 다른 스키마에 자동 적응한다고 주장하지 않습니다.

## 해석 및 검증 한계

1. 학습 초기화 시드는 물리 시드 수가 아닙니다. 공개 개발 묶음이 정책 시드 사이에 재사용되었습니다.
2. fixed252, close24, factor24에는 시작 상태의 중복이 있습니다. 분모를 합산하거나 독립 표본으로 취급하지 않습니다. 표 4와 RL도 합치지 않습니다.
3. 표 4는 기존 source-approach 정책과 거리·CLOSE 결합 보정 비교입니다. 초기 BC부터 최종 정책까지의 전체 개선이나 보정 항목별 독립 효과가 아닙니다.
4. 세 초기화의 보고는 세 번의 새로운 실행이 아닙니다. 두 replica의 새 피팅과 최초 seed 20261101의 정확한 결과 재사용을 구분합니다.
5. RL의 251/252, 248/252, 247/252는 별도 seed 20261101 출발 체크포인트의 개발 비교이며, 채택 seed 20261030 최종 모델의 RL 결과가 아닙니다.
6. 봉인된 최종 평가, 실물 성공률, 통계적 유의성, 인과 효과 또는 일반화를 새로 검증하지 않습니다. 신뢰구간·유의성 검정·묶음 간 합계는 생성하지 않습니다.
7. 저장 실행의 코드 지문과 현재 코드가 다를 수 있습니다. 원본 학습 데이터, 당시 실행 코드·환경, 전체 시뮬레이션 로그, 하드웨어가 완비되었다고 주장하지 않습니다.
8. 해시 일치는 해당 파일 바이트의 식별에 한정됩니다. 자료의 진실성, 모델 동작 또는 실험의 독립 재현을 증명하지 않습니다.

기본 실행에는 네트워크, 로봇, 사용자 데스크톱 연결, 모델 로딩 또는 프로젝트 코드 실행 경로가 없습니다. 테스트도 이 폴더 안에서만 임시 파일을 만들고 정리합니다. 라이선스·저자 결정, 외부 업로드 또는 공개를 수행하지 않습니다.

## 테스트와 종료 상태

`test_results.txt`는 제공 시점의 테스트 기록입니다. Python 3.12.14에서 58개 테스트가 통과했습니다. 기존 52개는 잘못된 JSON/중복 키/NaN, 음수와 분모 초과, 시드 혼동, 출처 누락, 중복 묶음 합산 방지, 해시 불일치, 불완전한 검증의 정직한 표시, 파생본과 원본 구분, 상대 경로·심볼릭 링크 제한과 결정적 출력을 확인합니다. v0.3의 추가 6개는 회수 메타데이터의 잘못된 타입·수치·경로·필드 거부, 참조 파일을 열지 않는 동작과 기록을 새 바이트 검증으로 승격하지 않는 보고를 확인합니다.

- 종료 코드 0: 요청한 요약 검사 통과. 원본 전체 검증이나 실험 재현 성공을 의미하지 않습니다.
- 종료 코드 2: 입력 검증 실패 또는 명시적으로 비교한 해시·필드 불일치. 해시·명시적 필드 비교 불일치는 provenance에도 남깁니다. 스키마 실패 시에는 결과 파일을 새로 생성하지 않습니다. 이전 생성물이 이미 있으면 자동 삭제하지 않으므로 종료 코드를 반드시 확인합니다.
