# Reporting provenance

Status: summary_checks_passed.

The Markdown Table 4 exactly matches the saved manuscript table (line endings normalized).

## Source-byte checks

- selected_checkpoint: not_supplied_not_verified
- technical_specification: not_supplied_not_verified
- three_seed_development: not_supplied_not_verified
- rl_comparison: not_supplied_not_verified
- rl_start_checkpoint: not_supplied_not_verified

## Interpretation limits

- This reproduces reporting from saved summaries, NOT learning, evaluation, hardware execution, or independent validation.
- Analyst extracts and normalized summary JSON are not raw simulator trajectories or trial logs.
- All reported cohorts are simulation development cohorts, not sealed holdout or real hardware results.
- The same public development cohorts were reused across policy initialization seeds; seeds are not independent physical trial counts.
- Cohorts overlap. No pooled total, independent-trial estimate, confidence interval, significance test, or cross-cohort aggregate is produced.
- Table 4 compares source-approach policies against combined distance/CLOSE corrections, not initial BC against final policies or a factorial ablation.
- The RL comparison uses a separate seed 20261101 source-approach checkpoint; it is not RL applied to the selected seed 20261030 model.
- File hash agreement identifies supplied bytes only. It does not establish data truth, source authenticity, checkpoint behavior, or experimental reproducibility.
- Missing original files or missing expected hashes remain explicitly unverified, even if historical metadata says file_hash_checked=true.
- The output does not establish exact physical-start overlap from the reported public structural-group overlap.
- The three policy initializations include two new replica fits and exact reuse of the primary seed 20261101 result; they are not three newly rerun fits.
- Current project code may differ from saved run fingerprints. This supplement does not assert that current code can rerun the experiments.
